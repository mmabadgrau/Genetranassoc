/* File: ficheros.h */


#ifndef __ficheros_h__
#define __ficheros_h__



using namespace std;

namespace BIOS
{

//////////////////////////////////////
class Fichero_entrada: public ifstream//
{//
 char *texto, ref[63], carac, dirdats[50];//
 unsigned int patron, posicion, total_atributos;//
 public://
 void abrir(char[63]);//
 unsigned int taman(void);//
 void ir(unsigned int, unsigned int);//
 void fin_de_linea(void);//
 unsigned short int existefichero (char[63]);//
 ~Fichero_entrada(){};
};//

////////////////////
class Fichero_salida: public ofstream//
{//
 char ref[63];//
  public://
 void abrir(char[63]);//
 void abrir_truncando(char[63]);//
 void anadir(char[63]);//
~Fichero_salida(){};
};//


}
#endif

//#include "ficheros.cpp"
