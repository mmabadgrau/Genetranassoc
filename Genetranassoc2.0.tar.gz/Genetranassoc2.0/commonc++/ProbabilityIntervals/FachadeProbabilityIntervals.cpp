#ifndef __FachadeProbabilityIntervals_cpp__ 
#define __FachadeProbabilityIntervals_cpp__ 


#include "ProbabilityInterval.cpp"

#include "ProbabilityIntervals.cpp"

#endif
