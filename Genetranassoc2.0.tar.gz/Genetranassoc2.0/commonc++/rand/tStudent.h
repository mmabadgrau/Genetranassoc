#include <iostream>
//#include <ostream>
//#include <fstream>
#include <string>
#include <math.h>


#ifndef __tStudent_h__
#define __tStudent_h__

/*********************************************************************
   Returns the tStudent distribution
   From "NUmerical recipes in c"        
*********************************************************************/
namespace BIOS {


double tStudent(double x, int df, int way=0);


}
#endif
