double cdfSumOfHalfNormal(const double x);


double getPValSumOfHalfNormal(const double x);


