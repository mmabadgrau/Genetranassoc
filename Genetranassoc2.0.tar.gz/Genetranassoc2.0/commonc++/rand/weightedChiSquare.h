
#ifndef __WeightedChiSquared_h__
#define __WeightedChiSquared_h__

namespace BIOS
{

/*_______________________________________________________________*/

double pdfWeightedChiSquared(double x, int df);

/*_______________________________________________________________*/

double pdfTestWeightedChiSquare(double x, doubleList* weights, int df); 

/*_______________________________________________________________*/

double pdfTestWeightedChiSquareTDT(double x, doubleList* weights, int df); 

/*_______________________________________________________________*/

double pdfTestWeightedChiSquare2(double x, doubleList* weights);


/*_______________________________________________________________*/

double cdfWeightedChiSquared(double x, int df);

//****************************************************************************80

double hiTest (double* observed, double*expected, int df);
}
#endif
