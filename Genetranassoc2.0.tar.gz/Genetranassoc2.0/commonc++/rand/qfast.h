
#ifndef __qfast_h__
#define __qfast_h__

namespace BIOS
{

/*_______________________________________________________________*/

double pdfqfast(double x, int df);
/*_______________________________________________________________*/


double pdfTestqfast(double x, int df);


}
#endif
