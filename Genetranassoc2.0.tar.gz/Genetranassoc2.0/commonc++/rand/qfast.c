
#ifndef __qfast_c__
#define __qfast_c__

namespace BIOS
{

  
/*_______________________________________________________________*/

double pdfqfast(double x, int df)
{
// probability density function

}

/*_______________________________________________________________*/

double pdfTestqfast(double product, int numberOfProducts)
// 1-cumulative distribution function
// it computes p value prob (Chi^2>x) and df degrees of freedom
{
double x, t, q;
     if (product==0) return 0;
     if (numberOfProducts>1) x=-std::log(product);
     t=product;
     q=product;
     for (int i=1; i<numberOfProducts; i++)
{
t=t*x/i;
q=q+t;
}
return q;
    }

}


#endif
