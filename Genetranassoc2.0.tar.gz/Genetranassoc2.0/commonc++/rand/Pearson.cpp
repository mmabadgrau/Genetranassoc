
#ifndef __Pearson_cpp__
#define __Pearson_cpp__

namespace BIOS
{


Pearson::Pearson(doubleList* firstList, doubleList* secondList, int actualSize)
{
this->firstList=firstList;
this->secondList=secondList;
if (firstList->size()!=secondList->size())
throw OutOfBounds(firstList->size(), secondList->size());
measure=-2;
this->actualSize=actualSize;
}


/*______________________________________________________*/

Pearson::~Pearson()
{
}
/*______________________________________________________*/

 ostream& operator<< (ostream& out, Pearson& l)
{
out << "First list of values: " << *l.firstList <<"\n";
out << "Second list of values: "<< *l.secondList <<"\n";
return out;
}

/*______________________________________________________*/

double Pearson::getMeasure()
{
if (measure==-2) setMeasure();
return measure;
}

/*______________________________________________________*/

void Pearson::setMeasure()
{
try
{
int n=actualSize; //firstList->size();
double result=0, averageX=0, averageY=0, num=0, den1=0, den2=0;
for (int i=0; i<firstList->size(); i++)
if (!isNAN(firstList->getElement ( i )) && !isNAN(secondList->getElement ( i )))
{
averageX+=firstList->getElement(i);
averageY+=secondList->getElement(i);
}
averageX/=n;
averageY/=n;
for (int i=0; i<firstList->size(); i++)
if (!isNAN(firstList->getElement ( i )) && !isNAN(secondList->getElement ( i )))
{
num+=(firstList->getElement(i)-averageX)*(secondList->getElement(i)-averageY);
den1+=std::pow(firstList->getElement(i)-averageX,2);
den2+=std::pow(secondList->getElement(i)-averageY,2);
}
if ((den1*den2)==0) measure=0;
else measure=num/sqrt(den1*den2);
}
catch ( BasicException& be ) {be.addMessage ( "\ncalled from void Pearson::setMeasure()" ); throw;};

}





/*______________________________________________________*/


}
#endif
