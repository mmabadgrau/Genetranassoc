
#ifndef __Pearson_h__
#define __Pearson_h__

namespace BIOS
{

class Pearson
{
protected:
doubleList* firstList, *secondList;
double measure;
int actualSize;

public:
Pearson(doubleList* firstList, doubleList* secondList, int actualSize);
~Pearson();
double getMeasure();
void setMeasure();
friend ostream& operator<< (ostream& out, Pearson& l);
};
}
#endif
