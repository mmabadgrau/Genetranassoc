double cdfSumOfHalfNormal(const double x)
{
return erf(x/2)*erf(x/2);
}

/*________________________________________*/

double getPValSumOfHalfNormal(const double x)
{
return 1-cdfSumOfHalfNormal(x);
}

