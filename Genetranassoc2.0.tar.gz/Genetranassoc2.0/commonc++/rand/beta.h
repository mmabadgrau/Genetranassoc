#include <iostream>
//#include <ostream>
//#include <fstream>
#include <string>
#include <math.h>


#ifndef __beta_h__
#define __beta_h__

/*********************************************************************
   Returns the beta distribution
   From "NUmerical recipes in c"        
*********************************************************************/
namespace BIOS {
#define MAXIT 100
#define EPS 3.0e-7
#define FPMIN 1.0e-30

double beta(double z, double w);
double betai(double a, double b, double x);
double betacf(double a, double b, double x);

}
#endif
