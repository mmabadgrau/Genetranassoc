double cdfNormal(const double x);


double getPValNormalTwoSided(const double x);


double getPValNormalOneSided(const double x);

