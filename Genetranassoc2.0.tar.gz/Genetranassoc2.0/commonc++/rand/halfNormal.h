double cdfHalfNormal(const double x, double sd=1);


double getPValHalfNormal(const double x);


