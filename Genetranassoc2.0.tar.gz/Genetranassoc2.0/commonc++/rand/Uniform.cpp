/* File: Uniform.cpp */


#ifndef __Uniform_cpp__
#define __Uniform_cpp__


#include "Uniform.h"


namespace BIOS {

//#define RAND_UNIFORME (double)rand()/(double)RAND_MAX


/**********************************/
double uniform(double min, double max)
{
double result;
do
{
result=RAND_UNIFORME;
if (result>min && result<max) return result;
} while(1==1);
}



};  // End of Namespace

#endif

/* End of file: Binomial.h */




