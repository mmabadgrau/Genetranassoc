/* File: Uniform.h */


#ifndef __Uniform_h__
#define __Uniform_h__



namespace BIOS {


/************************/
/* Binomial STATISTIC*/
/************************/


/**
        @memo Uniform

	@doc
        Definition:
        Uniform distribution  

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/


 
//class Uniform  {


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* PUBLIC FUNCTIONS (INTERFACE) */

//public:
#define RAND_UNIFORME (double)rand()/(double)RAND_MAX


double uniform(double min=0, double max=1);








};  // End of Namespace

#endif

/* End of file: Binomial.h */




