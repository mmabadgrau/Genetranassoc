#include <iostream>
//#include <ostream>
//#include <fstream>
#include <string>
#include <math.h>


#ifndef __tStudent_c__
#define __tStudent_c__

/*********************************************************************
   Returns the tStudent distribution
   From "NUmerical recipes in c"        
*********************************************************************/
namespace BIOS {


double tStudent(double x, int df, int way)
{
// pVal=1- cdf; cdf=1-betai(df/(double)2, 0.5, df/(double)(df+x*x));
// -1 left, 0: two side, 1 right
try
{

// t = Inf*sign(r);
// p= 2*tcdf(-abs(t),n-2);2 sides
// p = tcdf(-t,n-2);// right
// p = tcdf(t,n-2); // left
double p=betai(df/(double)2, 0.5, df/(double)(df+x*x));
if (way==1) p/=2;


//cout <<"val x is: " << x << ", df is: " << df << " and p val is: " << p <<"\n";
return p;
}
catch ( BasicException& be ) {be.addMessage ( "\ncalled from double tStudent(double a, double x)" ); throw;};

}


}
#endif
