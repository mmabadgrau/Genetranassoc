/*
  The Broad Institute
  SOFTWARE COPYRIGHT NOTICE AGREEMENT
  This software and its documentation are copyright (2005) by the
  Broad Institute/Massachusetts Institute of Technology. All rights are
  reserved.

  This software is supplied without any warranty or guaranteed support
  whatsoever. Neither the Broad Institute nor MIT can be responsible for its
  use, misuse, or functionality.
*/
/* calculates exponential deviates. used for interarrival
 * times for poisson processes.
 * numerical recipes.
 */

#include <math.h>
#include "rng.h"

double
expdev (void)
{
	double dum = 0;

	while (dum == 0.0)
		dum = (double) 1 - random_double();
	return -log (dum);
}
