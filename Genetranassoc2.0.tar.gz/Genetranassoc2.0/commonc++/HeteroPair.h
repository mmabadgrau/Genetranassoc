/* File: HeteroPair.h */


#ifndef __HeteroPair_h__
#define __HeteroPair_h__



using namespace std;

namespace BIOS {


// is a pair of lists
template < class P, class Q> class HeteroPair
  {
public:
           P First;
           Q Second;
           HeteroPair(P f, Q s) ;
           HeteroPair(const HeteroPair<P, Q>& p) ;
           HeteroPair() ;
           ~HeteroPair() ;
											void empty();
	   bool operator>(const HeteroPair<P, Q>& p) const;
	   bool operator<(const HeteroPair<P, Q>&p) const;
	   bool operator==(const HeteroPair<P, Q>p) const;
    HeteroPair<P,Q> & operator=(const HeteroPair<P,Q>& other);





           void setValues(P f, Q s) ;
	   P first();
	P getFirst();
	   Q second();
Q getSecond();
     static HeteroPair* fromString(string s);
    HeteroPair* clone(); 
  };

/*
	template<class T> bool compare( const HeteroPair<T>& arg1, const HeteroPair<T>& arg2)
	{
return arg1>arg2;
}
*/
/*______________________________________________________*/

template<class T, class U> ostream& operator<<(ostream& out, HeteroPair<T, U>& HeteroPair);



}//end namespace
#endif
