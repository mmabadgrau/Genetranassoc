
#ifndef __Basic2_h__
#define __Basic2_h__


using namespace std;

namespace BIOS
{


  //void print(char* filename);

  //R/template <class T, template <class T> class Cont> 
   template <class Cont, class T> 
  bool empty(Container<Cont, T>* lista);


  //  stringList*  getList (char * genotypebuf, char* tokensSource);

  stringVector*  getStringVector (char * genotypebuf, const char* tokensSource);

  //R/template <class T, template <class T> class Cont> 
  template <class Cont, class T> 
  Container<Cont,T>*  getContainer (char * genotypebuf, char* tokensSource);

   longLongList* getNumbers (char* input);

  PairOfLongsVector* getConsecutiveNumbers (char* input);
  longLongList* getIndividualNumbers (char* input);

	PairOfDoublesVector* computeROC ( doubleList*positives, doubleList*negatives );

double computeAUC(PairOfDoublesVector* roc);

double computeAUC2(doubleList*positives, doubleList*negatives);

double trapezoid_area(double x1, double x2, double y1, double y3);
  //  template <class T> Container<T, list>* createList(T* array, int length);

}
// end namespace

//#include "basic.cpp"
#endif


