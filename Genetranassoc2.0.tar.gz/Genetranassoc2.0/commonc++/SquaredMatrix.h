/* File: SquaredMatrix.h */


#ifndef __SquaredMatrix_h__
#define __SquaredMatrix_h__


using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  class SquaredMatrix: public Matrix //
  {//
    // it is a xD table with position numbers first in deep vars. Example: 2x2 table. Position numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
  public:

 
    /*______________________________________________________*/

    SquaredMatrix();
/*______________________________________________________*/


  ~SquaredMatrix();


 
    /*______________________________________________________*/

    SquaredMatrix(int xDim);

/*___________________________________________________*/

double getTrace ();

};
  /*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, SquaredMatrix& p);
}
#endif
