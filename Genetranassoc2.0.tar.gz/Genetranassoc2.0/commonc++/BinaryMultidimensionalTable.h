/* File: BinaryMultidimensionalTable.h */


#ifndef __BinaryMultidimensionalTable_h__
#define __BinaryMultidimensionalTable_h__
/*
#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"
*/
using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  template <class T> class BinaryMultidimensionalTable: public MultidimensionalTable<T> //
  {//
    // it is a xD table with position numbers first in deep vars. Example: 2x2 table. Position numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
  public:





    BinaryMultidimensionalTable();

    BinaryMultidimensionalTable(int totalDimensions);

    BinaryMultidimensionalTable(BinaryMultidimensionalTable &source);

void set(int totalDimensions) ;

virtual    ~BinaryMultidimensionalTable();
  };
 

}
#endif
