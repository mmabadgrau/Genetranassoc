/* File: Container.h */


#ifndef __GenericContainer_h__
#define __GenericContainer_h__





/**
    @memo Declaration of a Container (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* Container DEFINITION */
  /************************/
//template <class T> class list: public vector<T>{};
//typedef vector ListOfPointers;

  /**
          @memo Container 
   
  	@doc
          Definition:
          A set of Container's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the Container
   
      @author Maria M. Abad Grau
  	@version 1.0
  */


 // template <template<class T, class _Compare = std::less<T>, class _Alloc = std::allocator<T> > class Cont, class T> class AssociateContainer;
//typedef template <class T>  vector<T> list;

  //template <class T> class Set;
 
//template <template<class T> class Cont> class Container: public Cont<T>

template <template<class T, class _Compare=std::allocator<T>, class _Alloc=std::allocator<T> > class Cont, class T, class _Compare, class _Alloc > 
struct NoTemplate<Cont<T, _Compare, _Alloc > > {
enum{r=true};
typedef _Compare FirstType;
typedef _Alloc SecondType;
template <template<class, class> class Temp1, class B=_Alloc >
struct SubstType
{
typedef Temp1<B> R;
};
};

//template<class U, class _Alloc2 = std::allocator<U>, class _Compare2 = std::less<U> > 
struct AssociateContainer
{
Cont<T, _Compare, _Alloc > Class<T,  _Alloc2,  _Compare2>;
};

union cont
{
template <template <class T, typename _Alloc=std::allocator<T> > class Cont, class T> class Container;
template <template<class T, class _Compare = std::less<T>, class _Alloc = std::allocator<T> > class Cont, class T> class AssociateContainer;
};



template <int type, class T, template <class T, typename _Alloc=std::allocator<T> > class Cont, template <class T, typename _Compare = std::less<T>,  typename _Alloc=std::allocator<T> > class Cont2 >
class GenericContainer
{
typedef Cont<T> Container;
typedef Cont2<T> AssociateContainer;

int getElement(){};
};
template<class T, template <class T, typename _Alloc=std::allocator<T> > class Cont, template <class T, typename _Compare = std::less<T>,  typename _Alloc=std::allocator<T> > class Cont2 > class GenericContainer<1, T, Cont, Cont2>
{
};

template<class T, template <class T, typename _Alloc=std::allocator<T> > class Cont, template <class T, typename _Compare = std::less<T>,  typename _Alloc=std::allocator<T> > class Cont2 > int GenericContainer<1, T, Cont, Cont2>::getElement()
{
};



  template <class T> class GenericContainer<1, T>: public Container<vector<T>, T>;
 

  template <2, class T> class GenericContainer: public AssociateContainer<set, T>;


} // end namespace
#endif


/* Fin Fichero: Container.h */


/* Fin Fichero: Container.h */
