/* File: MultidimensionalTable.h */


#ifndef __MultidimensionalTable_h__
#define __MultidimensionalTable_h__
/*
#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"
*/
using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  template <class T> class MultidimensionalTable: public MultidimensionalEmptyTable<T> //
  {//
  // it is a xD table with position numbers first in deep vars. Example: 2x2 table. Position numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
protected:

    T* table;


  public:

    T totalCounts;
    /*______________________________________________________*/

    MultidimensionalTable();
        virtual void set(); 
        virtual void set(intList* dimensionList);
       MultidimensionalTable(intList* dimensionList); 
        MultidimensionalTable(MultidimensionalTable &source);
void initialize();
T GetMax();
 //   void setSize() throw (ZeroValue);
     virtual  ~MultidimensionalTable();
    virtual void empty();
  MultidimensionalTable<T>* project(intList* sourcePosList);
   void setTotalCounts();
      T getTotalCounts();
       void setValue(int* pos, T value);
       void setValue(int pos, T value);
     void addValue(int pos, T value);
       void addValue(int* pos, T value);
  //     int getSubtableSize(int dim);
    //  long long int getPos(int *pos) throw (OutOfRange<long long int>);
    //   int getDimension();
    //   int* getPositions(long long int pos)  throw (OutOfRange<long long int>);

      bool isCompletelyMissing(int *pos);
       void setMissing(int* pos, int index);
       bool isMissing(int *pos);
       int getTotalMissing(int *pos);
       intList* getMissingDimensions(int *pos);
      int* getMissingVars(int *pos);
       int getFirstMissing(int *pos);
       T getValue(int pos);
       T getValue(int *pos);
  //     int getSize() ;
//       int getSize(int* values);
     void normalize();
    void removeInconsistenciesWithEvidence(intList* sourcePosList, T value);
    string print();
 MultidimensionalTable* getTable (HeteroListPair<long long int, T>* pair);
 


//static MultidimensionalTable*  estimateMLE (MultidimensionalTable* currentEstimation, MultidimensionalTable<double> * genotypeCounts, double totalCounts, int it=1000, MultidimensionalTable<double>* externallyKnownAmbiguousCounts=NULL, MultidimensionalTable<double> * solvedHaplotypes=NULL, int transmission=0);
//static MultidimensionalTable*  estimateMLE (MultidimensionalTable* currentEstimation, MultidimensionalTable<double> * genotypeCounts, double totalCounts, int it=1000, int transmission=0);

/*
int getAmbiguousPos (int knownPos1, int knownPos2, int variable);


static int getTotalAmbiguousValues (int totalKnownValues);
static int getTotalUnknownValues (int totalKnownValues);
*/
//int getTotalKnownValues (int pos);
/*
int getKnownPos (int ambiguousPos, int variable, bool left);
int getUnknownPos (int pos1, int pos2, int variable);
int* getSolvedConf(int* positions, long long int solvedPosition, bool left);

bool isAKnownValue (int v, int variable);

*/
   }; // end class
  

 // template <class T> ostream& operator<<(ostream& out, MultidimensionalTable<T>& p);
  
  
 
  

 template <class T> ostream& operator<<(ostream& out, MultidimensionalTable<T>& p);
/*
{
throw NonImplemented("ostream& operator<<(ostream& out, MonolociMeasure<T>& pm)");
return out;
};
//ostream& operator<<(ostream& out, MultidimensionalTable<longLongList*>& p);
*/

};// end namespace
#endif
