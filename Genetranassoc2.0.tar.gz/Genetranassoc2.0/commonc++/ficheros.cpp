/* File: ficheros.cpp */


#ifndef __ficheros_cpp__
#define __ficheros_cpp__

#include "ficheros.h"

namespace BIOS
{



unsigned short int Fichero_entrada::existefichero (char* nomfich)
{
struct stat fs;
if (stat(nomfich, &fs)==0) return (1); else return (0);
}
/////////////////////
void Fichero_entrada::abrir(char referencia[63])//
{//
 strcpy(ref, referencia);//
 if (Fichero_entrada::existefichero (ref)==0)
 {
 cout <<"Error, fichero " << referencia << " no existe";
 exit(0);
 }

Fichero_entrada::open(ref, ios::in); //
 if (!Fichero_entrada())//
 {//
  cout << "No se puede abrir el archivo.";//
  }//
}//

////////////////////////////////
unsigned int Fichero_entrada::taman()//
{//
posicion=Fichero_entrada::tellg();//
Fichero_entrada::seekg(ios::beg);//
patron=0;//
//cout <<  "Leyendo fichero\n";//
Fichero_entrada::get(carac);//
while (!Fichero_entrada::eof())//
{//
 Fichero_entrada::get(carac);//
 if (!Fichero_entrada::eof())//
 if (carac=='\n')//
 {//
// cout  << patron << "\r";//
 patron=patron+1;//
}//
}//
Fichero_entrada::clear();
Fichero_entrada::seekg (posicion);//
return(patron);//
}//
//////////////////////////////////////
void Fichero_entrada::ir (unsigned int pos, unsigned int ancho_registro)//
{//
Fichero_entrada::seekg(ancho_registro*pos, ios::cur); //
}//
/////////////////////////////////////////
void Fichero_entrada::fin_de_linea()//
{//
char cad[256];//
//Fichero_entrada::get(cad, 256, '\n');//
Fichero_entrada::getline(cad, 256);
//Fichero_entrada::get(cara); //
}//



/////////////////////
void Fichero_salida::abrir(char referencia[63])//
{//
 strcpy(ref, referencia);//
  Fichero_salida::open(ref, ios::out);//
 if (!fichero_salida())//
 {//
  cerr << "No se puede abrir el archivo.";//
  }//
}//
///////////////////////
void Fichero_salida::abrir_truncando(char referencia[63])//
{//
 strcpy(ref, referencia);//
  Fichero_salida::open(ref, ios::trunc);//
 if (!fichero_salida())//
 {//
  cerr << "No se puede abrir el archivo.";//
  }//
}//
/////////////////////
void Fichero_salida::anadir(char referencia[63])//
{//
 strcpy(ref, referencia);//
  Fichero_salida::open(ref, ios::app);//
 if (!fichero_salida())//
 {//
  cerr << "No se puede abrir el archivo.";//
  }//
}//

}
#endif
