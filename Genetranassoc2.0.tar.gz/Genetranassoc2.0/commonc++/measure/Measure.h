#ifndef Measure_h//
#define Measure_h//



namespace BIOS 
{


//////

template <class T> class Measure

{ 
	
protected:


//void set(Sample<T>* sample);
   
public:

BayesType bayesType;
float alpha;

    Measure(BayesType bayesType=MLE, float alpha=0);
    bool operator==(Measure<T>& otherMeasure) {throw NonImplemented(" bool operator==(Measure<T>& otherMeasure)"); };


};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Measure<T>& lista);

  
} // end namespace
#endif
