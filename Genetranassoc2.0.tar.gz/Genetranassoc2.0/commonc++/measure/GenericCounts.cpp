/* File: PhylogeneticDistance.h */

#ifndef __GenericCounts_cpp__
#define __GenericCounts_cpp__

//using namespace stats;

namespace BIOS {

/*______________________________________________________________*/

GenericCounts::GenericCounts(int totalPermutations)
{
this->totalPermutations=totalPermutations;
this->permutations=NULL;

};

/*______________________________________________________________*/

GenericCounts::GenericCounts(GenericCounts& other)
{
this->totalPermutations=other.totalPermutations;
this->permutations=other.permutations;

};


/*_________________________________________________________________*/

 GenericCounts::~GenericCounts()
 {
zaparr(permutations, totalPermutations);
 };
 
/*_________________________________________________________________*/

GenericCounts ** GenericCounts::getPermutations ()
{
if (permutations==NULL) setPermutations();
return permutations;
}

/*_________________________________________________________________*/

void  GenericCounts::setPermutations()
{
throw NonImplemented("void  GenericCounts::setPermutations()");
};

/*_________________________________________________________________*/

int GenericCounts::getTotalSecondVars ()
{
throw NonImplemented("int GenericCounts::getTotalSecondVars ()");
}
/*_________________________________________________________________*/

VectorOfParentalHaplotypes*  GenericCounts::getParentalHaplotypesList()
{
throw NonImplemented("VectorOfParentalHaplotypes*  GenericCounts::getParentalHaplotypeList()");
};

/*_________________________________________________________________*/

VectorOfParentalGenotypes*  GenericCounts::getParentalGenotypes()
{
throw NonImplemented("VectorOfParentalHaplotypes*  GenericCounts::getParentalGenotypes()");
};

/*_________________________________________________________________*/

int  GenericCounts::getTotalPos()
{
throw NonImplemented("int  GenericCounts::getTotalPos()");
};

/*_________________________________________________________________*/

int  GenericCounts::getTotalPermutations()
{
return totalPermutations;
};


/*_________________________________________________________________*/
 


};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */




