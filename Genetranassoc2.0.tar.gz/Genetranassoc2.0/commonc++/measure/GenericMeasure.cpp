#ifndef __GenericMeasure_cpp__
#define __GenericMeasure_cpp__

namespace BIOS
{

	GenericMeasure::GenericMeasure ( bool permutations )
	{
		this->permutations=permutations;

	};

	/*___________________________________________________________ */

	GenericMeasure::GenericMeasure ( SampleGenericCounts* SampleGenericCounts,  bool permutations )
	{
this->counts=SampleGenericCounts;
		this->permutations=permutations;
	};

	/*___________________________________________________________ */

	GenericMeasure::~GenericMeasure()
	{
	};

	/*_________________________________________________________________*/

	GenericMeasure::GenericMeasure ( GenericMeasure& other )
	{
		this->permutations=other.permutations;
this->counts=other.counts;

	};

	/*_____________________________________________________________*/

	void GenericMeasure::setPermutations ( int totalPermutations )
	{
		throw NonImplemented ( "void GenericMeasure::setPermutations (int totalPermutations)" );
	}


	/*_____________________________________________________________*/

	void GenericMeasure::setPermutations ( )
	{
		throw NonImplemented ( "void GenericMeasure::setPermutations ()" );
	}

	/*_____________________________________________________________*/

	double GenericMeasure::getBestPVal( )
	{
		throw NonImplemented ( "void GenericMeasure::getBestPVal ( )" );
	}


	/*_____________________________________________________________*/

	double GenericMeasure::getWorstStatistic( )
	{
		throw NonImplemented ( "void GenericMeasure::getWorstStatistic ( )" );
	}
	/*_____________________________________________________________*/
/*
	double GenericMeasure::getBestStatistic( )
	{
		throw NonImplemented ( "void GenericMeasure::getBestStatistic ( )" );
	}

/*_________________________________________________________________*/

void GenericMeasure::setCounts(SampleGenericCounts* SampleGenericCounts)
{
this->counts=SampleGenericCounts;
}

/*_________________________________________________________________*/

SampleGenericCounts* GenericMeasure::getCounts()
{
return counts;
}
	/*_____________________________________________________________*/
/*
	virtual GenericMeasure* getNewMeasure ( GenericMeasure* GenericMeasure, SampleGenericCounts** training=NULL, SampleGenericCounts** test=NULL )
	{
throw NonImplemented();
	}

	/*_____________________________________________________________*/

	double GenericMeasure::getPVal()
	{
		//cout <<"measure with perms is:" << this->getName() <<"\n";
		double result=1;
		doubleList* null=new doubleList();
		double* nullArray;
		GenericMeasure* gm;
		if ( counts->getPermutations() ==NULL )
			counts->setPermutations();


		for ( int i=0; i<counts->getTotalPermutations(); i++ )
		{
			//if (i%10==0)  cout <<"permutation " << i <<"\n";
			gm=getNewMeasure ( counts->getPermutations() [i] );
			null->insertElement ( gm->getStatistic() );
			zap ( gm );
		}
		null->sort();
//  cout <<*null <<"\nwhile real value is:" << getStatistic() <<"\n";
		nullArray=null->getTable();
		result=getPValue ( nullArray, counts->getTotalPermutations(), getStatistic() );
		zap ( null );
		zaparr ( nullArray );
		return result;
	}

	/*_________________________________________________________________*/
	/*
		 GenericMeasure* GenericMeasure::getNewGenericMeasure(SampleGenericCounts* tuCounts2)
		{

	 return getNewGenericMeasure(tuCounts2, positions, length);
		}
	 /*_________________________________________________________________*/



};

#endif
