#ifndef __FachadeMeasureC_h__ 
#define __FachadeMeasureC_h__ 



#include "GenericMeasure.cpp"
#include "SampleGenericCounts.cpp"
#include "BivariateCountsAlongSecondVar.cpp"
#include "Measure.cpp"
#include "MeasureCompetition.cpp"

#include "DependenceMeasure.cpp"
#include "MLEst.cpp"
#include "Entropy.cpp"
#include "BayesScore.cpp"
#include "EmpiricalRisk.cpp"
#include "MDL.cpp"
#include "Correlation.cpp"
#include "InformationGain.cpp"
#include "SymmetricalUncertainty.cpp"
#include "MeasureResults.cpp"
#include "StatisticalTestResults.cpp"
#include "MultipleSamplesRateResults.cpp"

#endif
