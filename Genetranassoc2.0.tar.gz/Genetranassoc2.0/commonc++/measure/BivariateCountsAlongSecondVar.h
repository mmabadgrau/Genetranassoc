/* File: PhylogeneticDistance.h */

#ifndef __BivariateCountsAlongSecondVar_h__
#define __BivariateCountsAlongSecondVar_h__

//using namespace stats;

namespace BIOS {


/************************/
/* SNP'S MultimarkerMeasure DEFINITION */
/************************/


/**
        @memo GenericCounters required for a GenericMeasure

	@doc
        Definition:

     it will obtain the counts from a file with a sample

    
        @author Maria M. Abad
	@version 1.0
*/

class TestModeClass;
class GenericSample;
 
class	BivariateCountsAlongSecondVar: public SampleGenericCounts {


public:
//  int totalPermutations;
int totalSecondVars;





doubleList* firstVarList;
doubleList** arrayOfSecondVarList;
doubleList* firstRankList;
bool ties;

protected:


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/





      public:

//BivariateCountsAlongSecondVar(char* file, TestModeClass* testModeClass);

BivariateCountsAlongSecondVar(int totalPermutations=0, int totalSecondVars=0);

 BivariateCountsAlongSecondVar(BivariateCountsAlongSecondVar& source);

BivariateCountsAlongSecondVar(doubleList* firstVarList, doubleList** secondVarList, int totalPermutations=0, int totalSecondVars=0);

virtual BivariateCountsAlongSecondVar* clone();

//virtual void divideSample()=0;

//MeasureResults** getResults(ListOfGenericMeasures* test, int*pos, int size);
//intSet* selectPositions(int foldSize, Sampling* sampling, int i);

//virtual bool isEmpty()=0;

virtual~BivariateCountsAlongSecondVar();

friend ostream& operator<<(ostream& out, BivariateCountsAlongSecondVar& l) {l.print(out); return out; };

virtual void print(ostream&);

virtual void setPermutations ();

virtual int getTotalSecondVars();

};

};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */




