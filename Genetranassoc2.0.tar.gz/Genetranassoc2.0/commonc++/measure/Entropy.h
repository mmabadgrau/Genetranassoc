#ifndef Entropy_h//
#define Entropy_h//



namespace BIOS 
{


//////

template <class T> class Entropy: public MLEst<T>

{ 
	
   
public:


    Entropy();
Entropy(BayesType bayesType=MLE, float alpha=0);
//virtual bool better(double m1, double m2);
virtual double getMeasure(CPT *s1, CPT* priors=NULL);
//double getMeasure(MLSample<T>* sample, intList* varList, intList* conditionalVarList=NULL);

};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Entropy<T>& lista);

  
} // end namespace
#endif
