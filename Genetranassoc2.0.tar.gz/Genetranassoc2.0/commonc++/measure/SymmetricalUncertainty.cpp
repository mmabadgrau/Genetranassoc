#ifndef SymmetricalUncertainty_cpp//
#define SymmetricalUncertainty_cpp//



namespace BIOS 
{

/*______________________________________________________*/

template <class T> SymmetricalUncertainty<T>::SymmetricalUncertainty(BayesType bayesType, float alpha):Entropy<T>(bayesType, alpha)
{
if (alpha==0) alpha=1;
this->bayesType=bayesType;
}

/*______________________________________________________*/

template <class T> bool SymmetricalUncertainty<T>::better(double m1, double m2)
{
if (m1<m2) return true; else return false;
}

/*______________________________________________________*/

template <class T> double SymmetricalUncertainty<T>::getMeasure(CPT *s1, CPT* s2)
{
cout <<"SymmetricalUncertainty<T>::getMeasure(CPT *s1, CPT* s2) not defined yet";
end();
}
/*______________________________________________________*/
/*
template <class T> double SymmetricalUncertainty<T>::getMeasure(MLSample<T>* sample, intList* varList, intList* conditionalVarList)
{
cout <<"SymmetricalUncertainty<T>::getMeasure(MLSample<T>* sample, intList* varList, intList* conditionalVarList) not defined yet";
end();
}
/*______________________________________________________*/
/*
template<> double SymmetricalUncertainty<int>::getMeasure(MLSample<int>* sample, intList* varList, intList* conditionalVarList)
{
double entropy=DependenceMeasure<int>::getMeasure(sample, varList, conditionalVarList);
double conditionalEntropy=DependenceMeasure<int>::getMeasure(sample, varList);
return (entropy-conditionalEntropy)/entropy;
}
/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, SymmetricalUncertainty<T>& lista)
{
 
//out << *lista.sample;

return out;
  }

  
} // end namespace
#endif
