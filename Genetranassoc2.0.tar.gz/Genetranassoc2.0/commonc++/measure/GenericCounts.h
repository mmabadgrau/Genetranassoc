/* File: PhylogeneticDistance.h */

#ifndef __GenericCounts_h__
#define __GenericCounts_h__

//using namespace stats;

namespace BIOS {


/************************/
/* SNP'S MultimarkerMeasure DEFINITION */
/************************/


/**
        @memo GenericCounters required for a GenericMeasure

	@doc
        Definition:

     it will obtain the counts from a file with a sample

    
        @author Maria M. Abad
	@version 1.0
*/

class TestModeClass;
class GenericSample;
class VectorOfParentalHaplotypes;
class VectorOfParentalGenotypes;

 
class	GenericCounts {


public:
  int totalPermutations;

protected:


GenericCounts** permutations;

//char* filename;

GenericSample* genericSample;

//char* fileName;
//TestModeClass* testModeClass;
//GenericSample* genericSample;


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/





      public:

//GenericCounts(char* file, TestModeClass* testModeClass);

GenericCounts(int totalPermutations=0);

 GenericCounts(GenericCounts& source);

//virtual GenericCounts* clone()=0;

//virtual void divideSample()=0;

//MeasureResults** getResults(ListOfGenericMeasures* test, int*pos, int size);
//intSet* selectPositions(int foldSize, Sampling* sampling, int i);

//virtual bool isEmpty()=0;

virtual~GenericCounts();

friend ostream& operator<<(ostream& out, GenericCounts& l) {l.print(out); return out; };

virtual void print(ostream&)=0;

virtual int getTotalPermutations();

virtual GenericCounts** getPermutations();

virtual void setPermutations ();

virtual int getTotalSecondVars();

virtual GenericCounts* clone()=0;

virtual VectorOfParentalHaplotypes* getParentalHaplotypesList();

virtual int getTotalPos();

virtual VectorOfParentalGenotypes* getParentalGenotypes();

};

};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */




