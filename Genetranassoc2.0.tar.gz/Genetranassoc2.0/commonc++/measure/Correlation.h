#ifndef Correlation_h//
#define Correlation_h//



namespace BIOS 
{


//////

template <class T> class Correlation: public DependenceMeasure<T>

{ 
	
private:

int classNum;   
DiagonalTable<double>* correlationMatrix;
intList *classVar, *feature1, *feature2;
//MLSample<T>* sample;

public:



  //  Correlation(int classNum, Sample<vector, vector, T>* sample, BayesType bayesType=MLE, float alpha=0);
    ~Correlation();
    double getMeasure(intList* varList);
    double getMeasure(CPT* sample, CPT* priors=NULL){};//{cout <<"DependenceMeasure getMeasure not implemented yet"; end();};

    bool better(double m1, double m2){};//{cout <<"DependenceMeasure better not implemented 
  
};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Correlation<T>& lista);
  
} // end namespace
#endif
