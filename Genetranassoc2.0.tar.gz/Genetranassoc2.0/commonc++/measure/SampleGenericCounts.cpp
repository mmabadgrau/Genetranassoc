/* File: PhylogeneticDistance.h */

#ifndef __SampleGenericCounts_cpp__
#define __SampleGenericCounts_cpp__

//using namespace stats;

namespace BIOS {

/*______________________________________________________________*/

SampleGenericCounts::SampleGenericCounts(int totalPermutations)
{
this->totalPermutations=totalPermutations;
this->permutations=NULL;

};

/*______________________________________________________________*/

SampleGenericCounts::SampleGenericCounts(SampleGenericCounts& other)
{
this->totalPermutations=other.totalPermutations;
this->permutations=other.permutations;

};


/*_________________________________________________________________*/

 SampleGenericCounts::~SampleGenericCounts()
 {
zaparr(permutations, totalPermutations);
 };
 
/*_________________________________________________________________*/

SampleGenericCounts ** SampleGenericCounts::getPermutations ()
{
if (permutations==NULL && totalPermutations>0) setPermutations();
return permutations;
}

/*_________________________________________________________________*/

void  SampleGenericCounts::setPermutations()
{
throw NonImplemented("void  SampleGenericCounts::setPermutations()");
};

/*_________________________________________________________________*/

int  SampleGenericCounts::size()
{
throw NonImplemented("void  SampleGenericCounts::size()");
};

/*_________________________________________________________________*/

int SampleGenericCounts::getTotalSecondVars ()
{
throw NonImplemented("int SampleGenericCounts::getTotalSecondVars ()");
}
/*_________________________________________________________________*/

VectorOfParentalHaplotypes*  SampleGenericCounts::getParentalHaplotypesList()
{
throw NonImplemented("VectorOfParentalHaplotypes*  SampleGenericCounts::getParentalHaplotypeList()");
};

/*_________________________________________________________________*/

VectorOfParentalGenotypes*  SampleGenericCounts::getParentalGenotypes()
{
throw NonImplemented("VectorOfParentalHaplotypes*  SampleGenericCounts::getParentalGenotypes()");
};

/*_________________________________________________________________*/

int  SampleGenericCounts::getTotalPos()
{
throw NonImplemented("int  SampleGenericCounts::getTotalPos()");
};

/*_________________________________________________________________*/

int  SampleGenericCounts::getTotalPermutations()
{
return totalPermutations;
};


/*_________________________________________________________________*/
 


};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */




