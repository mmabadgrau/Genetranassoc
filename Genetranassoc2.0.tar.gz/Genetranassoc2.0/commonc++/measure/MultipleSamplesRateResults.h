/* File: MultipleSamplesRateResults.h */

#ifndef __MultipleSamplesRateResults_h__
#define __MultipleSamplesRateResults_h__



//using namespace UTILS;


namespace BIOS
{


  class MultipleSamplesRateResults: public MeasureResults
  {
  
  private:
  
  doubleList* rates;// association rates
  PairOfDoublesVector* alpha;
  doubleList* pVals;
  bool returnPVals;
  
  public: 

    MultipleSamplesRateResults();
		MultipleSamplesRateResults(MultipleSamplesRateResults& other);
 //   MultipleSamplesRateResults(doubleList* rates, PairOfDoublesVector* alpha);
    doubleList* getPVals();
		MultipleSamplesRateResults(MeasureResults** mrArray, int size, PairOfDoublesVector* alpha, bool returnPVals=false);
//		MultipleSamplesRateResults(MultipleSamplesRateResults** mrArray, int size, PairOfDoublesVector* alpha, bool returnPVals=false);
    virtual ~MultipleSamplesRateResults();

virtual void set();

virtual void empty();

virtual void printClass(){cout << "Class MultipleSamplesRateResults\n";};

virtual MultipleSamplesRateResults* clone();

void addResult(MeasureResults*m, int size);
virtual double getMainResult();
virtual void print(ostream& out, bool verticalPrint=true);
void printHeading(ostream& out);
void printHeadingPlus(string s, ostream& out);
 
  };
};  // Fin del Namespace

#endif

/* Fin Fichero: TestModeClass.h */
