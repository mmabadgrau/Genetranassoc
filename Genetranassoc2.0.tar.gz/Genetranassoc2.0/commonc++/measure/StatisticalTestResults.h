/* File: StatisticalTestResults.h */

#ifndef __StatisticalTestResults_h__
#define __StatisticalTestResults_h__



//using namespace UTILS;


namespace BIOS
{


  class StatisticalTestResults: public MeasureResults
  {
  
  private:
  
  double pVal;

  double totalMultiTest;


  

  
  public: 

    StatisticalTestResults();
		StatisticalTestResults(StatisticalTestResults& other);
    StatisticalTestResults(double pVal, double totalMultiTest=0);
     ~StatisticalTestResults();

virtual void set();

virtual StatisticalTestResults* clone();

virtual void addResult(MeasureResults*m, int size);
virtual double getMainResult();
virtual void empty();
virtual void printClass(){cout << "Class StatisticalTestResults\n";};
virtual void print(ostream& outt, bool verticalPrint=true);
virtual void printHeading(ostream& out);
virtual void printHeadingPlus(string s, ostream& out);
virtual double getTotalMultiTest();
  };
};  // Fin del Namespace

#endif

/* Fin Fichero: TestModeClass.h */
