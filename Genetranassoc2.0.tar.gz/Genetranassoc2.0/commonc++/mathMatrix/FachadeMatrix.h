#ifndef __FachadeMatrix_h__ 
#define __FachadeMatrix_h__ 

// header file for double precision dvector and matrix classes
// doublevec - double dvector indexed from 0
// dvector - double dvector indexed from offset, can't remember what it does
// dv2d - double matrix indexed from 0, supports matrix arithmetic
// dsvd - set of three matrices forming singular value decomposition of source matrix
// rank_table - not distributing this code yet


namespace BIOS {





class doublevec;
class dvector;
class dv2d;
class dsvd;
}

#include "doublevec.h"
#include "dvector.h"
#include "dv2d.h"
#include "dsvd.h"
//#include "rank_table.h"
#include "dsvdc.c"
#include "pca.h"
//#include "dsvdcode.cpp"






#endif
