/* File: BinaryMultidimensionalTable.h */


#ifndef __BinaryMultidimensionalTable_cpp__
#define __BinaryMultidimensionalTable_cpp__
/*
#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"
*/
using namespace std;

namespace BIOS
{

template <class T> BinaryMultidimensionalTable<T>::BinaryMultidimensionalTable():MultidimensionalTable<T>()
    {      };

    /*______________________________________________________*/

      template <class T>  BinaryMultidimensionalTable<T>::BinaryMultidimensionalTable(int totalDimensions):MultidimensionalTable<T>()
    {
    set(totalDimensions);
    };
      /*______________________________________________________*/

      template <class T>  BinaryMultidimensionalTable<T>::BinaryMultidimensionalTable(BinaryMultidimensionalTable &source):MultidimensionalTable<T>()
    {
try{
 if (source.dimensionList==NULL) set();
    else 
{

 this->totalCounts=source.totalCounts;
  set(source.dimensionList);
      for (int i=0; i<this->size();i++)
       setValue(i, source.getValue(i));
}
}
catch (MissingValue mv){mv.PrintMessage("BinaryMultidimensionalTable(BinaryMultidimensionalTable &source)");end();}
      }
     /*______________________________________________________*/

  template <class T> void  BinaryMultidimensionalTable<T>::set(int totalDimensions) 
{
try
{
if (totalDimensions<1) throw OutOfRange<int>(totalDimensions, "BinaryMultidimensionalTable<T>::set");
intList* dimensionList=new intList();
for (int i=0; i<totalDimensions; i++)
 dimensionList->insertElement(2); 
this->MultidimensionalTable<T>::set(dimensionList);
zap(dimensionList);
}
catch (ORI & ori){throw;}
}
 
     /*______________________________________________________*/

     template <class T>   BinaryMultidimensionalTable<T>::~BinaryMultidimensionalTable(){};
  


}
#endif
