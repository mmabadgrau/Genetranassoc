/* File: Partition.h */


#ifndef __Partition_cpp__
#define __Partition_cpp__



/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

 // template <class Cont, class T> class Container;


  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /*
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A Cont of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria M. Abad Grau
  	@version 1.0
  */
//template <class T> typedef  Container<Cont, T> Container<Cont, T>;


// template <template <class T, typename STL2 > class Cont, class T, typename STL2=std::allocator<T> >

/*template<class T> void Partition<T>::Class::insertElement(HaplotypeSet* element)
{
throw NonImplemented("void Partition::insertElement(HaplotypeSet* element) non implemented");
}
*/
/*____________________________________________________________ */

//template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
//void Container<set<set<Haplotype*> >, set<Haplotype*> >::insertElement(Haplotype* haplotype, Container<set<set<Haplotype*> >, set<Haplotype*> >::iterator it) 
/*
template<> void PartitionOfHaplotypes::insertElement(HaplotypeSet* element)
{
cout << "here\n";
HaplotypeSet::iterator it3;
HaplotypeSet* hs;
for (HaplotypeSet::const_iterator it=element->begin(); it!=element->end();it++)
for (PartitionOfHaplotypes::const_iterator it2=this->begin(); it2!=this->end();it2++)
{
it3=this->getElement(it2)->end();
hs=(HaplotypeSet*)*it2;
if (hs->findElement((Haplotype*)*it)!=it3)
      throw BadFormat("Partition<T>::Class::insertElement");
}
insertElement(element, this->begin());
};


/*________________________________________________________________*/

/*
template<> void PartitionAsSetSampleOfHaplotypes::PartitionAsSetSampleOfHaplotypes()
{
outputSeparator='\t';
leftDelimiter='[';
rightDelimiter=']';
}


/*________________________________________________________________*/

/*
template<> void PartitionAsSetSampleOfHaplotypes::insertElement(HaplotypeSet* element)
{
HaplotypeSet* hs;
for (HaplotypeSet::const_iterator it=element->begin(); it!=element->end();it++)
for (PartitionAsSetSampleOfHaplotypes::iterator it2=this->begin(); it2!=this->end();it2++)
{
hs=(HaplotypeSet*)*it2;
if (hs->findElement((Haplotype*)*it)!=this->getElement(it2)->end())
{
cout << "trying to add element " << *element <<"\nin:\n";
cout << *this <<"\n";
      throw BadFormat("Partition<T>::Class::insertElement");
}
}
insertElement(element, begin());//, this->end());
};
*/
 
/*
 template <class T> ostream& operator<<(ostream& out, struct  Partition<T>::Class& l)
{
cout <<"GGGG\n";
for (typename Partition<T>::Class::iterator it=l.begin(); it<l.end(); it++)
 out << *l.getElement(it) <<"\n";
return out;
}
*/
/*

 ostream& operator<<(ostream& out, HaplotypeSet& l)
{
//cout <<"there\n";
Haplotype* h;
for (HaplotypeSet::iterator it=l.begin(); it!=l.end(); it++)
{
h=l.getElement(it);
out <<*h <<" ";
}
return out;
}
*/
/*
 ostream& operator<<(ostream& out, PartitionOfHaplotypes& l)
{
//l.setDelimiters('[',']');
HaplotypeSet* h;
for (PartitionOfHaplotypes::iterator it=l.begin(); it!=l.end(); it++)
{
 h=l.getElement(it);
 // h->setDelimiters('[',']');
 h->setOutputSeparator(' '); 
 out << "[" << *h <<"]";
}
//out << (Container<HaplotypeSet*,Haplotype*>)l;
return out;
}
*/

/*___________________________________________________________________________________________*/
/*
   template <class T> void Partition<T>::Class::insertElement(T element, typename Partition<T>::Class::iterator it)
  {
   for (Partition<T>::Class::iterator it2=this->begin(); it2!=this->end();it2++)
    if (it2!=it)
     if (*it2->findElement(element)!=it2->end())
      throw BadFormat("Partition<T>::Class::insertElement");
    Set<Set<T>::Class >::Class::insertElement(it, element);
  };  

/*___________________________________________________________________________________________*/




}; // end namespace
#endif

//#include "ListOfPointers.cpp"

/* Fin Fichero: ListOfPointers.h */
