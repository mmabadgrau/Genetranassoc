/* File: Set.h */


#ifndef __Set_cpp__
#define __Set_cpp__



/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /**
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A Cont of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria M. Abad Grau
  	@version 1.0
  */




/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
void Container<set<Node*>, Node*>::insertElement(Container<set<Node*>, Node*>::iterator first, Container<set<Node*>, Node*>::iterator second) 
{
this->insert(first, second);
};

/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
void Container<set<Haplotype*>, Haplotype*>::insertElement(Container<set<Haplotype*>, Haplotype*>::iterator first, Container<set<Haplotype*>, Haplotype*>::iterator second) 
{
this->insert(first, second);
};


/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
//Node*& Container<set<Node*, fncomp, allocator<Node*> >, Node*>::getElement(int position)  
Node*& Container<set<Node*>, Node*>::getElement(int position)  
{
return this->getElement(this->getNode(position));
};

/*____________________________________________________________ */

//template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
//string & Container<set<string, fncomp, allocator<string> >, string>::getElement(int position)  

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
string & Container<set<string>, string>::getElement(int position)  
{
return this->getElement(this->getNode(position));
};


/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
allele& Container<set<allele>, allele>::getElement(int position)  
{
return this->getElement(this->getNode(position));
};

/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
Integer*& Container<set<Integer*>, Integer*>::getElement(int position)  
{
return this->getElement(this->getNode(position));
};


/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
Clique*& Container<set<Clique*>, Clique*>::getElement(int position)  
{
return  this->getElement(this->getNode(position));
};


/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
int& Container<set<int>, int>::getElement(int position)  
{
return  this->getElement(this->getNode(position));
};

/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
void intSet::insertElement(intSet::iterator first, intSet::iterator second) 
{
this->insert(first, second);
};


/*____________________________________________________________ */
/*
template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
void Container<set<Haplotype*>, Haplotype*>::insertElement(Container<set<Haplotype*>, Haplotype*>::iterator first, Container<set<Haplotype*>, Haplotype*>::iterator second) 
{
this->insert(first, second);
};


/*________________________________________________*/

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
bool NodeSet::operator== (const NodeSet& group)
	{
//cout << "inside\n";
if (((NodeSet&)group).size()!=this->size()) return false;
NodeSet::iterator it2, it3;

for (NodeSet::iterator it=group.begin(); it!=group.end();it++)
{
//it2=this->end();
//it3=this->findEqualElement(*it2);
if (this->findEqualElement(*it)==this->end()) return false;
}

return true;
	};

/*____________________________________________________________ */

template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
void stringSet::insertElement(stringSet::iterator first, stringSet::iterator second) 
{
return this->insert(first, second);
};


	/*___________________________________________________________________________________________*/
/*
	template <> void HaplotypeSet::insertElement ( Haplotype* element, HaplotypeSet::iterator it )
	{
throw NonImplemented("void HaplotypeSet::insertElement ( Haplotype* element, HaplotypeSet::iterator it )");
//cout << "before inserting:" << *this <<"\n";
//cout << "inserting element: " << *element <<"\n";
		insert ( element );
//cout << "after inserting:" << *this <<"\n";
	}
*/

	template <> void SetOfCliques::insertElement ( Clique* element){insert(element);};

	template <> void SetOfAttributes::insertElement ( Attribute* element){insert(element);};

	template <> void HaplotypeSet::insertElement ( Haplotype* element){insert(element);};

	template <> void boolSet::insertElement ( bool element){insert(element);};

	template <> void alleleSet::insertElement ( allele element){insert(element);};

	template <> void baseSet::insertElement ( base element){insert(element);};

	template <> void intSet::insertElement ( int element){insert(element);};

	template <> void floatSet::insertElement ( float element){insert(element);};

	template <> void doubleSet::insertElement ( double element){insert(element);};

	template <> void stringSet::insertElement ( string element){insert(element);};

	template <> void longLongSet::insertElement ( long long int element){insert(element);};

	template <> void IntegerSet::insertElement ( Integer* element){insert(element);};

	template <> void NodeSet::insertElement ( Node* element){insert(element);};





template <> void SetOfCliques::insertElement ( Clique* element, SetOfCliques::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void SetOfAttributes::insertElement ( Attribute* element, SetOfAttributes::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void HaplotypeSet::insertElement ( Haplotype* element, HaplotypeSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void boolSet::insertElement ( bool element, boolSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void alleleSet::insertElement ( allele element, alleleSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void baseSet::insertElement ( base element, baseSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void intSet::insertElement ( int element, intSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void floatSet::insertElement ( float element, floatSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void doubleSet::insertElement ( double element, doubleSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void stringSet::insertElement ( string element, stringSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void longLongSet::insertElement ( long long int element, longLongSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void IntegerSet::insertElement ( Integer* element, IntegerSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};

	template <> void NodeSet::insertElement ( Node* element, NodeSet::iterator){throw NonImplemented("voidSet::insertElement ( T* element, Set::iterator it )");};




/*___________________________________________________________________________________________*/

//template <class T> typedef  AssociateContainer<Cont, T> AssociateContainer<Cont, T>;


// template <class T> class Set: public AssociateContainer<Cont, T>
//   {





/*____________________________________________________________ */

 
   //R/template <template<class> class Cont, class T>
/*
   template <class T>  
   Set<T>::Class* Set<T>::Class::removeSubsets ()
    {
     typename Container<set, T>::iterator p=this->GetFirst(), pNext, p2=NULL;
      bool found;
      while (p!=this->end())
      {
      p2=this->GetFirst();
      found=false;
      while(p2!=this->end() && !found)
      {
      if (p!=p2 && this->GetElement(p)->includes(this->GetElement(p2)))
      {
      p2=this->removeNode(p2);
      found=true;
      }
      else p2=this->GetNext(p2);
      }
      p=this->GetNext(p);
      }
    }
    /*___________________________________________________________*/







    //template <class T>  
    //Set<T>::Class* Set<T>::Class::getCommonNodes (Set<T>::Class* otherSet)
// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 


template<>// gcc 4.1.2. Try template template partial specialization in future g++ compilers (with 
Container<set<Node*>, Node*>* Container<set<Node*>, Node*>::getCommonNodes(Container<set<Node*>, Node*>* otherSet) 

    {
throw NonImplemented("Container<set<Node*>, Node*>::getCommonNodes");
}
/* 
      if (otherSet==NULL)
      {
        cout <<"Error in Set::getCommonNodes, argument is NULL";
        end();
      }
      Container<set, T>* commonSet=new Container<Cont, T>();
      Container<set, T>* orderedSet1=NULL;
      Container<set, T>* orderedSet2=NULL;
      // choose this shortest list
      if (this->GetSize()>otherSet->GetSize())
      {
        orderedSet1=new Container<Cont, T>(*this);
        orderedSet2 =new Container<Cont, T>(*otherSet);
      }
      else
      {
        orderedSet1=new Container<Cont, T>(*otherSet);
        orderedSet2 =new Container<Cont, T>(*this);
      }
      T* element=NULL;
      typename Container<Cont, T>::iterator p=orderedSet1->GetFirst(), pNext, p2=NULL;
      
      while (p!=orderedSet1->end())
      {
        element=orderedSet1->GetElement(p);
	if (element==orderedSet1->end())
	{
	cout <<"EERRR";
	end();
	}
	//cout <<"\nfinding element" << element->print() <<" in bag:" << orderedSet2->print();
        p2=orderedSet2->findElement(element);
        if (p2!=orderedSet2->end())
        {
          commonSet->insertElement(element);
          orderedSet2->removeNode(p2);
        }
        p=orderedSet1->GetNext(p);
      }
      
      zap(orderedSet1);
      zap(orderedSet2);
      return commonSet;
    }
*/

/*
 template <class T>   T*&  Container<set<T, fncomp>,T>::getElement(int position)
{
int i=0;
for (typename Set<T>::Class::iterator it=begin(); it!=end(); it++)
if (i==position) return *it;
throw OutOfRange("Set<T>::Class::getElement(int position)");

//throw NonImplemented("Attribute*& SetOfAttributes::getElement(int position) , nonsense");
//return this->at(position);
//return this->getElement(this->getNode(position));
};

/*____________________________________________________________ */

/*
template <>
Attribute*& SetOfAttributes::getElement(int position) 
{
throw NonImplemented("Attribute*& SetOfAttributes::getElement(int position) , nonsense");
//return this->at(position);
//return this->getElement(this->getNode(position));
};

/*____________________________________________________________ */

//template <class T, template <class> class STL2>
//T&  Set< T>::Class::getElement(int position) 
/*
template <>
Clique*& SetOfCliques::getElement(int position) 
{
throw NonImplemented("Clique*& SetOfCliques::getElement(int position) , nonsense");
//return this->at(position);
//return this->getElement(this->getNode(position));
};
/*____________________________________________________________ */

//template <class T, template <class> class STL2>
//T&  Set< T>::Class::getElement(int position) 
/*
template <>
Node*& NodeSet::getElement(int position) 
{
throw NonImplemented("Node*& NodeSet::getElement(int position) , nonsense");

//return this->at(position);
//return this->getElement(this->getNode(position));
};
*/



/*____________________________________________________________ */

//template <class T, template <class> class STL2>
//T&  Set< T>::Class::getElement(int position) 






    	/*___________________________________________________________________________________*/

 
//template <class Cont, class T> 

/*
template <> 
SetOfCliques::iterator SetOfCliques::findElementContainingInternalElement(Node*& element)
{
cout <<" findineddddddl" << *element <<"\n";
typename Container<Cont, T>::iterator p=this->getFirst();
while (p!=this->end())
{
	if (this->getElement(p)->findElement(element)!=this->getElement(p)->end()) return p;
p=this->getNext(p);
}
return this->end();

  };

/*
template<class T> ostream& operator<<(ostream& out, Container<set<T, fncomp>, T > & pm)
       {
for (typename Container<set<T, fncomp>, T >::iterator it=pm.begin(); it!=pm.end(); pm++)
out << **(T&&)pm;
return out;
};

/*_____________________________________________________________________*/
/*
  ostream& operator<<(ostream& out, Set<Clique*>::Class& lista)
  {
   Set<Clique*>::Class::iterator p=lista.begin();
   while (p!=lista.end())
   {
      out << *lista.getElement(p);
      p=lista.getNext(p); 
      if (p!=lista.end()) out <<"; ";
   }
   
   return out;
  }
*/
 
/*______________________________________________________*/
 
/*
  ostream& operator<<(ostream& out, Set<Clique*>::Class& lista)
  {
   Set<Clique*>::Class::iterator p=lista.begin();
   while (p!=lista.end())
   {
      out << *lista.getElement(p);
      p=lista.getNext(p); 
      if (p!=lista.end()) out <<"; ";
   }
   
   return out;
  }

*/

    

}; // end namespace
#endif

//#include "ListOfPointers.cpp"

/* Fin Fichero: ListOfPointers.h */
