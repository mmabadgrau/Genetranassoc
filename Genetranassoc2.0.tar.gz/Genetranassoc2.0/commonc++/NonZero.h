/* File: NonZero.h */


#ifndef __NonZero_h__
#define __NonZero_h__



using namespace std;

namespace BIOS {


class NonZero
{
public:
double nz;
NonZero(double n) 
{
if (n==0)
{
cout <<"error NonZero is 0";
exit(0);
}
nz=n;
}
double getValue()
{
return nz;
}
};


}//end namespace
#endif
