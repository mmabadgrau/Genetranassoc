/* File: ListOfOrderedAttributes.h */


#ifndef __ListOfOrderedAttributesTreeDistances_h__
#define __ListOfOrderedAttributesTreeDistances_h__




//using namespace UTILS;


namespace BIOS
{



  /************************/
  /* ListOfOrderedAttributes DEFINITION */
  /************************/


  /**
          @memo ListOfOrderedAttributes 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */

// template <class T, template <class T> class Cont> class ListOfOrderedAttributes: public Set<Attribute, ListOfOrderedAttributes>

//template <class T, template <class T> class Cont> class Sample: public ListOfPointers<Container<T, Cont> >

//template <Attribute, ListOfPointers> class ListOfOrderedAttributes
// template <class T> class vector
//template <class T, template <class T> class Cont> class ListOfOrderedAttributes
//template <> Container<Attribute, ListOfPointers> class ListOfOrderedAttributes

//template<class T, template<class T> class Cont> class ListOfOrderedAttributes<Attribute, ListOfPointers>

  class ListOfOrderedAttributesTreeDistances: public ListOfOrderedAttributes
  {


  
  public:

intList* positionsVectorToComputeDistances;// relative positions to compute distances

Attribute* Pop();

    ListOfOrderedAttributesTreeDistances(char* texto);
    ListOfOrderedAttributesTreeDistances(ListOfOrderedAttributesTreeDistances & vectorOfOrderedAttributes);
    ListOfOrderedAttributesTreeDistances(ListOfAttributes & vectorOfAttributes);

    ListOfOrderedAttributesTreeDistances(floatList* positionsVector=NULL, intList* positionsVectorToComputeDistances=NULL);
				ListOfOrderedAttributesTreeDistances(int totalAtts, int totalMods,floatList* positionsVector=NULL, intList* positionsVectorToComputeDistances=NULL);
    ~ListOfOrderedAttributesTreeDistances();
ListOfOrderedAttributesTreeDistances* clone();

void setPositionsVectorToComputeDistances(intList* positionsVectorToComputeDistances);

  float getDistance(Container<vector<float>, float> * pattern1, Container<vector<float>, float> * pattern2, bool useMissing, bool noclass, DistanceMethodClass* distanceMethodClass, int classPosition, doubleList* weights=NULL);   

 

     };  // End of class ListOfOrderedAttributes

   ostream& operator<<(ostream& out, ListOfOrderedAttributesTreeDistances& vectora);
/*______________________________________________________*/
/*
    ostream& operator<<(ostream& out, Set<Attribute, ListOfPointers>& vectora)
  {
   Set<Attribute, ListOfPointers>::iterator p=vectora.getFirst();
   out <<"\n";
 while (p!=NULL)
    {
         out << *vectora.getElement(p);
         p=vectora.getNext(p); 
        out <<"\n";
    }
   
    return out;
  }
*/
}
;  // Fin del Namespace

#endif
//#include "ListOfOrderedAttributes.cpp"

/* Fin Fichero: ListOfOrderedAttributes.h */
