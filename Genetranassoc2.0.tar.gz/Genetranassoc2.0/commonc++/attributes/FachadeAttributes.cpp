#ifndef __FachadeAttributes_C__ 
#define __FachadeAttributes_C__ 

#include "Attribute.cpp"
#include "ListOfAttributes.cpp"
#include "ListOfOrderedAttributes.cpp"
#include "ListOfOrderedAttributesTreeDistances.cpp"
#include "DistanceMethodClass.cpp"
#endif
