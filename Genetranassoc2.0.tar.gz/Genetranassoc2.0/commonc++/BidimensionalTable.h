/* File: BidimensionalTable.h */


#ifndef __BidimensionalTable_h__
#define __BidimensionalTable_h__


using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  template <class T> class BidimensionalTable: public MultidimensionalTable<T> //
  {//
    // it is a xD table with position numbers first in deep vars. Example: 2x2 table. Position numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
  public:


    BidimensionalTable();
    BidimensionalTable(BidimensionalTable<T>& other);
    BidimensionalTable(const char* filename, bool separation=true);
virtual  ~BidimensionalTable();
//    void set();
    BidimensionalTable(intList* dimensionList);
    BidimensionalTable(int xDim, int yDim);
void set(int xDim, int yDim);
void reset(int xDim, int yDim);
void setValue (int i, int j, T value);
void addValue (int i, int j, T value);
int getXDim();
int getYDim();
T getValue (int i, int j);
int getPos (int i, int j);




};
  /*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, BidimensionalTable<T>& p);
}
#endif
