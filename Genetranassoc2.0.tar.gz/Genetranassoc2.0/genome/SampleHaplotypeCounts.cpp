/* File: MultimarkerMeasure.h */


#ifndef __SampleHaplotypeCounts_cpp__
#define __SampleHaplotypeCounts_cpp__





//using namespace stats;

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////



/*_________________________________________________________________*/

SampleHaplotypeCounts::SampleHaplotypeCounts(int* pos, int* absPos, int length, GeneticUnitCountsVector* countsVector, int totalPermutations): SampleGeneticCounts(pos, absPos, length, countsVector, totalPermutations)
{
//this->hapExtractionConfiguration=hapExtractionConfiguration;
}


/*_________________________________________________________________*/
/*
SampleHaplotypeCounts::SampleHaplotypeCounts(int* pos, int length, GeneticUnitCountsVector* countsVector, int totalPermutations): SampleGenericCounts(totalPermutations)
{
this->countsVector=countsVector;
this->hapExtractionConfiguration=NULL;
this->length=length;
if (pos!=NULL)
{
this->pos=new int[length];
for (int i=0; i<length; i++)
 this->pos[i]=pos[i];
}
else this->pos=NULL;
}

/*_________________________________________________________________*/

SampleHaplotypeCounts::SampleHaplotypeCounts(SampleHaplotypeCounts& tu): SampleGeneticCounts((SampleGeneticCounts&) tu)
{
//this->hapExtractionConfiguration=tu.hapExtractionConfiguration;
}

 	



/*_________________________________________________________________*/

SampleHaplotypeCounts::~SampleHaplotypeCounts ()
{
}





/*_________________________________________________________________*/

 SampleHaplotypeCounts::SampleHaplotypeCounts(): SampleGeneticCounts()
{
}

/*_________________________________________________________________*/

void SampleHaplotypeCounts::print(ostream& out)
       {
try
{
//  cout << "inside SampleHaplotypeCounts::print(ostream& out)\n";
          SampleGeneticCounts::print(out);
	  
	//  out << *hapExtractionConfiguration <<"\n";

}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void SampleHaplotypeCounts<T>::print(ostream& out)" ); throw;};
};









};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */

//stringList * BIOS::SampleHaplotypeCounts::getTDTFreqsResults(SNPPos snpPos)
//{
//}






