/* File: MultimarkerMeasure.h */


#ifndef __CaseControlCounts_cpp__
#define __CaseControlCounts_cpp__





//using namespace stats;

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

CaseControlCounts* CaseControlCounts::clone()
{
return new CaseControlCounts(*this);
} 


/*_________________________________________________________________*/

CaseControlCounts::CaseControlCounts(int*pos, int length, HapExtractionConfiguration* hapExtractionConfiguration, HaplotypeCaseControlCountsVector* haplotypeCountsVector, int totalPermutations): GeneticCounts(pos, length, hapExtractionConfiguration, totalPermutations)
{
}

/*_________________________________________________________________*/

CaseControlCounts::CaseControlCounts(CaseControlCounts& tu):GeneticCounts((GeneticCounts&)tu)
{
}
 


/*_________________________________________________________________*/

CaseControlCounts::~CaseControlCounts()
{
}

/*_________________________________________________________________*/

CaseControlCounts::CaseControlCounts():GeneticCounts()
{
}


/*_________________________________________________________________*/

void CaseControlCounts::setPermutations()
{
throw NonImplemented("CaseControlCounts::setPermutations()");
}







};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */

//stringList * BIOS::CaseControlCounts::getTDTFreqsResults(SNPPos snpPos)
//{
//}






