#ifndef __HaplotypeCaseControlCounts_cpp__
#define __HaplotypeCaseControlCounts_cpp__

void print(BIOS::HaplotypeCaseControlCounts *h){
	cout << *h << endl;
}

void print2(BIOS::HaplotypeCaseControlCounts *h){
	cout << "hola" << endl;
}

namespace BIOS {

	HaplotypeCaseControlCounts::HaplotypeCaseControlCounts(int size): HaplotypeCounts(size)
	{
		frequencyControls=0;
		frequencyCases=0;
	};
	

	/*_________________________________________________________________*/
	

			HaplotypeCaseControlCounts::HaplotypeCaseControlCounts(Haplotype* haplotype, float frequencyCases, float frequencyControls): HaplotypeCounts(haplotype, frequencyCases, frequencyControls)
			{
			}
			
				/*_________________________________________________________________*/
	
			HaplotypeCaseControlCounts::HaplotypeCaseControlCounts(HaplotypeCaseControlCounts& other): HaplotypeCounts((HaplotypeCounts&) other)
			{
			frequencyCases=other.frequencyCases;
			frequencyControls=other.frequencyControls;
			}
	
	/*_________________________________________________________________*/
	
GeneticUnitCounts* HaplotypeCaseControlCounts::clone() 
{
  return new HaplotypeCaseControlCounts ( *this );
  
};



	
			/*_________________________________________________________________*/
	/*
	void HaplotypeCaseControlCounts::sumProps( GeneticUnitCounts* other){


HaplotypeCaseControlCounts h=(HaplotypeCaseControlCounts*) other;
		this->frequencyCases += h->frequencyCases;
		this->frequencyControls += h->frequencyControls;
	}

	




/*_________________________________________________________________*/
/*
void HaplotypeCaseControlCounts::print(ostream& output)
{
				output << "[";
				//cout <<"size is " << h.size() << "\n";
			
					output << *this->geneticUnit;

				output << "][" << this->frequencyCases << "]";
				output << "[" << this->frequencyControls << "]";


				//return output;
}
*/

};

#endif
