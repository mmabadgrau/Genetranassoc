#ifndef __GeneticUnitCounts_cpp__
#define __GeneticUnitCounts_cpp__

//void print(BIOS::GeneticUnitCounts *h){
//	cout << *h << endl;
//}

//void print2(BIOS::GeneticUnitCounts *h){
//	cout << "hola" << endl;
//}

namespace BIOS {

	GeneticUnitCounts::GeneticUnitCounts()
	{
		geneticUnit=NULL;
		setFirstFrequency(0);
		setSecondFrequency(0);
	};
	
			/*_________________________________________________________________*/
	
	void GeneticUnitCounts::add(int first, int second){
		this->firstFreq += first;
		this->secondFreq += second;
	}

 

	/*_________________________________________________________________*/
	
/*
			GeneticUnitCounts::GeneticUnitCounts(GeneticUnit* geneticUnit)
			{
			this->geneticUnit=geneticUnit->clone();
			this->firstFreq = 0;
			this->secondFreq = 0;
			}
			
				/*_________________________________________________________________*/
	
			GeneticUnitCounts::GeneticUnitCounts(GeneticUnitCounts& other)
			{
			  if ( other.geneticUnit != NULL)
					this->geneticUnit=other.geneticUnit->clone();
			  else
				 	geneticUnit = NULL;
this->firstFreq=other.firstFreq;
		this->secondFreq =other.secondFreq;
			}

	/*_________________________________________________________________*/

	GeneticUnitCounts::GeneticUnitCounts(GeneticUnit* geneticUnit, float frequencyCases, float frequencyControls)
{
if (geneticUnit!=NULL) this->geneticUnit=geneticUnit->clone();
else  this->geneticUnit=NULL;
this->firstFreq = frequencyCases;
this->secondFreq = frequencyControls;
}

	/*_________________________________________________________________*/
	
	bool GeneticUnitCounts::operator!=(GeneticUnitCounts & other){
		return !(*this==other);
	}

		/*_________________________________________________________________*/
	
	bool GeneticUnitCounts::operator==(GeneticUnitCounts & other){
		//cout << " comparing HaplotypeTUCounts ..." << endl;
return *this->getGeneticElement()==*other.getGeneticElement() && getFirstFrequency()==other.getFirstFrequency() & getSecondFrequency()==other.getSecondFrequency();
/*
		if ( frequencyT != h.frequencyT || frequencyU != h.frequencyU || frequencyHomo != h.frequencyHomo)  
			return false;
		if (haplotype==NULL && h.haplotype==NULL) return true;
  if ((haplotype==NULL && h.haplotype!=NULL) || (haplotype==NULL && h.haplotype!=NULL))
   return false;
 //throw BadFormat("	bool HaplotypeTUCounts::operator==(HaplotypeTUCounts & h)");
		return * this->haplotype == * h.haplotype;
*/
	}
/*_________________________________________________________________*/

	void GeneticUnitCounts::sumProps( GeneticUnitCounts* other){
if (*other->getGeneticElement()!=*getGeneticElement())
throw NonImplemented("GeneticUnitCounts::sumProps( GeneticUnitCounts* other)");
		this->firstFreq += other->firstFreq;
		this->secondFreq += other->secondFreq;
	}
				/*_________________________________________________________________*/
	
GeneticUnit* GeneticUnitCounts::getGeneticElement()
	{
		return geneticUnit;
	}
	
	/*_________________________________________________________________*/

	GeneticUnitCounts::~GeneticUnitCounts()
	{
//		cout << "calling destructor GeneticUnitCounts..." << endl;
		zap(geneticUnit);
	}



			/*_________________________________________________________________*/
	
	bool GeneticUnitCounts::hasSameAllelesAs(GeneticUnitCounts *h)
	{
 if (geneticUnit==NULL || h->geneticUnit==NULL) throw NullValue("template<class T> GeneticUnitCounts<T>::hasSameAllelesAs(GeneticUnitCounts *h)");
		return *(this->geneticUnit) == *(h->geneticUnit);
	}

	



	



			/*_________________________________________________________________*/
	
	int GeneticUnitCounts::size()
	{ 
	  	if ( geneticUnit != NULL)
			return geneticUnit->size();
		else
		  	return 0;
	};

	
	

				/*_________________________________________________________________*/
	
void GeneticUnitCounts::print(ostream& output)
{
try
{

output << "[";
				//cout <<"size is " << h.size() << "\n";
			if (geneticUnit==NULL) cout <<"null genetic unit\n";
else
					this->geneticUnit->print(output);
				output << "][" << this->getFirstFrequency() << "]";
				output << "[" << this->getSecondFrequency() << "]";


			//	output << "[";
				//cout <<"size is " << h.size() << "\n";
				
}

		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void GeneticUnitCounts::print(ostream& out)" ); throw;};


			//	return output;
			}
/*_________________________________________________________________*/

 double GeneticUnitCounts::getFirstFrequency()
{
return firstFreq;
}
	/*_________________________________________________________________*/

 double GeneticUnitCounts::getSecondFrequency()
{
return secondFreq;
};

/*_________________________________________________________________*/

 void GeneticUnitCounts::setFirstFrequency(double f)
{
this->firstFreq=f;
}
	/*_________________________________________________________________*/

 void GeneticUnitCounts::setSecondFrequency(double f)
{
this->secondFreq=f;
};


/*_________________________________________________________________*/

double GeneticUnitCounts::getThirdFrequency()
{
throw NonDefinedMethod("HaplotypeCaseControlCounts::getThirdFrequency()");
return 0;
}

/*_________________________________________________________________*/

void GeneticUnitCounts::setThirdFrequency(double b)
{
throw NonDefinedMethod("HaplotypeCaseControlCounts::setThirdFrequency(double b)");
}

	
	
};

#endif
