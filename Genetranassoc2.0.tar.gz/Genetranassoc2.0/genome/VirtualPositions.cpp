/* File: VirtualPositions.h */

#ifndef __VirtualPositions_cpp__
#define __VirtualPositions_cpp__


#include "VirtualPositions.h"


namespace BIOS {



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
// private

/*___________________________________________________________ */

 template<> PosS*Container<vector<SNPPos>, PosS*>::readElement (ifstream * is,const  char* tokens, int* pos, int size)
{
  	PosS* posS=new PosS();
	char *line;
//cout << *is;
	line=CaptureLine(is);

//cout <<"v" << line;
//char st[20];
//sscanf(line, "%s", &st);
//cout << "bf" << st << "aft";
	sscanf(line, "%lf", &posS->pos);
	delete line;

	return posS;
}
/*____________________________________________________________ */

	  PosS* VirtualPositions::GetExtremeElement(bool max)//{};

//  template<> PosS vector<PosS>::GetExtremeElement(bool max)
  {
    // it returns a pointer to the element in the vector which has the closest upper value than argument
  cout <<"Not implemented yet";
  exit(0);
 //   PosS posS;
   // return posS;
  };

/*____________________________________________________________ */

void VirtualPositions::SetFilePos ()
{
SNPPos i=0;
iterator IndPosition=getFirst();
while (IndPosition!=this->end())
{
this->getElement(IndPosition)->filepos=i;
//cout <<"pos:" <<  IndPosition->element->filepos;
IndPosition=getNext(IndPosition);
i++;
}
}

///////////////////
//// public ////////
///////////////////
/*____________________________________________________________ */
/*
VirtualPositions::VirtualPositions()
{
}
*/
/*____________________________________________________________ */

void VirtualPositions::addRSNumbers()
{
	stringList* RSList=new stringList(fileRS);
	stringList::iterator p=RSList->getFirst();
	iterator IndPosition=getFirst();

	if (RSList->size()!=size())
	{
		cout <<"Error, different size in rs file";
		end();
	}
	while (p!=RSList->end())
	{
this->getElement(IndPosition)->rsNumber=string(RSList->getElement(p));
IndPosition=getNext(IndPosition);
p=RSList->getNext(p);
	}
}
/*____________________________________________________________ */

VirtualPositions::VirtualPositions(char* filen):Container<vector<PosS*>, PosS*>()
{
//
//exit(0);
strcpy(filename, filen);
CheckFilename(filen);

getInfo(filen, "\t \n"); 
SetFilePos();
changeExtension(filename, fileRS, "rs");
if (fileExists(fileRS))
 addRSNumbers();
//cout << print();
}

/*____________________________________________________________ */

void VirtualPositions::PrintPositions (char* filename)
 {


  
  
  try
{
  OpenOutput(filename, &OutputFile);
}
catch (BasicException& be){be.addMessage("\ncalled from VirtualPositions::PrintPositions (char* filename)"); throw;};

iterator IndPosition=getFirst();
while (IndPosition!=this->end())
{
OutputFile << (getElement(IndPosition))->pos <<"\n";
IndPosition=getNext(IndPosition);
}
  
OutputFile.close();

cout <<"File " << filename << " has been written.\n";
 }
/*____________________________________________________________ */

void VirtualPositions::PrintRSNumbers (char* filename)
 {


  OpenOutput(filename, &OutputFile);

iterator IndPosition=getFirst();
while (IndPosition!=this->end())
{
OutputFile << getElement(IndPosition)->rsNumber.c_str() <<"\n";
IndPosition=getNext(IndPosition);
}
  
OutputFile.close();

cout <<"File " << filename << " has been written.\n";
 }
/*____________________________________________________________ */

//SNPPos vector<SNPPos>::ReadElement (ifstream * is, unsigned long int size){};
/*____________________________________________________________ */

Container<vector<SNPPos>, SNPPos>* VirtualPositions::GetOnlyFilePos ()
 {
Container<vector<SNPPos>, SNPPos>* FP;

FP=new Container<vector<SNPPos>, SNPPos>();
//FP->List=NULL;
iterator IndPosition=getFirst();
while (IndPosition!=this->end())
{
FP->insertElement(getElement(IndPosition)->filepos);
IndPosition=getNext(IndPosition);
}
return FP; 
}

/*____________________________________________________________ */

SNPPos VirtualPositions::GetTotalSNPs()
{
 return this->size();
}
/*__________________________________________________________*/

void VirtualPositions::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP(SNP, TotalSNPs, "VirtualPositions::CheckRangeSNP(SNPPos SNP)");
}
		 catch (OverflowedSNP & ov) {
		 ov.PrintMessage(SNP); throw;}

}
/*____________________________________________________________ */

double VirtualPositions::getPosition(SNPPos SNP)
{
	return getPosition(getNode(SNP));
}
/*____________________________________________________________ */

double VirtualPositions::getPosition(VirtualPositions::iterator p1)
{
	return getElement(p1)->pos;
}

/*____________________________________________________________ */

string VirtualPositions::PrintPosition(SNPPos SNP, int integerPart, int decimalPart)
{

return PrintPosition(getNode(SNP), integerPart, decimalPart);


}
/*____________________________________________________________ */

string VirtualPositions::PrintPosition(VirtualPositions::iterator p, int integerPart, int decimalPart)
{

return tos(getElement(p)->pos, integerPart, decimalPart);


}

/*____________________________________________________________ */

string VirtualPositions::getRSNumber(SNPPos SNP)
{

return getRSNumber(getNode(SNP));


}
/*____________________________________________________________ */

string VirtualPositions::getRSNumber(VirtualPositions::iterator p)
{

return getElement(p)->rsNumber;


}
/*____________________________________________________________ */

void VirtualPositions::SNPSampling (Container<vector<SNPPos>, SNPPos> *Sampling)
{
	VirtualPositions* sample2;
	sample2=new VirtualPositions();
    PosS *newpos;
	Container<vector<SNPPos>, SNPPos>::iterator p=Sampling->getFirst();
	while (p!=Sampling->end())
	{
     newpos=getElement(Sampling->getElement(p));
	 sample2->insertElement(newpos);
	 p=Sampling->getNext(p);
	}
      assign (sample2->begin(), sample2->end());
zap(sample2);


}

/*____________________________________________________________ */

void VirtualPositions::ChangeUnits (SNPPos factor)
{
	VirtualPositions* sample2;
	sample2=new VirtualPositions();
    PosS* newpos;

    iterator p=getFirst();
	while (p!=this->end())
	{
     newpos=getElement(p);
	 newpos->pos=newpos->pos*factor;
	 sample2->insertElement(newpos);
	 p=getNext(p);
	}
    *this=*sample2;
}

};  // Fin del Namespace

#endif

/* Fin Fichero: VirtualPositions.cpp */
