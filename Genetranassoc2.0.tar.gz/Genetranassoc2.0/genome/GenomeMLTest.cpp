#ifndef GenomeMLTest_cpp//
#define GenomeMLTest_cpp//






//using namespace UTILS;

namespace BIOS {

GenomeMLTest::GenomeMLTest(char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int jointRows, int verbose):GenericMLTest(fileSample, internalTestMod, externalTestMod, 3, verbose)// 3 is to say that information in each sample file has to be split together in trios (trio samples)
{
try
{
this->totalPermutations=totalPermutations;
    this->hapExtractionConfiguration=hapExtractionConfiguration->clone();
    this->hapExtractionConfiguration2=hapExtractionConfiguration->clone();
}
catch (BasicException& be){be.addMessage("\ncalled from GenomeMLTest::GenomeMLTest(char* fileSample, TestModeClass *testMod, int totalPermutations, int jointRows):GenericMLTest(fileSample, testMod, 3)"); throw;};
}

/*___________________________________________________________ */

GenomeMLTest::GenomeMLTest(char* fileSample, char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int jointRows, int verbose):GenericMLTest(fileSample, secondFileSample, 3, verbose)// 3 is to say that information in each sample file has to be split together in trios (trio samples)
{
try
{
this->totalPermutations=totalPermutations;
    this->hapExtractionConfiguration=hapExtractionConfiguration->clone();
    this->hapExtractionConfiguration2=hapExtractionConfiguration->clone();
}
catch (BasicException& be){be.addMessage("\ncalled from GenomeMLTest::GenomeMLTest(char* fileSample, TestModeClass *testMod, int totalPermutations, int jointRows):GenericMLTest(fileSample, testMod, 3)"); throw;};
}
/*___________________________________________________________ */

int GenomeMLTest::getRealNumberOfAtts()
{
return (totalAtts-7)/2;
} 
/*___________________________________________________________ */

GenomeMLTest::~GenomeMLTest()
{
zap(hapExtractionConfiguration);
zap(hapExtractionConfiguration2);
}
/*___________________________________________________________ */

  GenericSample*  GenomeMLTest::getSample (char* file, int*pos, int length)
  {
    try
    {
      throw NonImplemented("GenomeMLTest::getSample (char* file, int*pos, int length)");
//cout << "getting sample from file " << file <<"\n";
     
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from GenericSample*  TUMLTest::getSample(char* file, int* pos, int size) "); throw;};
  }
  
  
  /*___________________________________________________________ */

  SampleGenericCounts*  GenomeMLTest::getCounts (GenericSample* ts, int* pos, int size)
  {
 try
    {


   SampleGenotypeCaseControlCounts* results= ( (GenomaSample*) ts)->getSampleGenotypeCaseControlCounts (totalPermutations, pos, size);

     return results;
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from  SampleGenericCounts*  TUMLTest::getCounts(char* file, int* pos, int size)"); throw;};
  }

} // end namespace
#endif
