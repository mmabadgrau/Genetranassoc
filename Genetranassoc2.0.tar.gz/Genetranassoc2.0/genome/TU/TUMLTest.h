#ifndef TUMLTest_h//
#define TUMLTest_h//



namespace BIOS {




//class InputTUI;


////////////////////////////

class TUMLTest: public HaplotypeMLTest 
{

/** This class is used as a generalization of any sample (ML Sample, genetic samples, etc.) so that they all can be divided in order to use tests, classifier or any other measure using different testting comfigurations (cross-validation, holdout, training).
*/



private:

//TrioSample**  

 bool useOnlyHetero;


public:

//TUMLTest(char* fileSample, TestModeClass *testMod);
TUMLTest(char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero, int verbose=0);
TUMLTest (char* fileSample,char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero, int verbose =0);
void checkOrder(char* file);
~TUMLTest();
virtual SampleGenericCounts* getCounts(GenericSample* ts, int* pos, int size);
virtual GenericSample* getSample(char* file, int* iniPos, int size);
virtual GenericSample*  mergeSamples (GenericSample* first, GenericSample* second);
  

};

} // end namespace
#endif

