#ifndef __FachadeTU_cpp__ 
#define __FachadeTU_cpp__ 



#include "TrioGenotype.cpp"
#include "TrioPhenotype.cpp"
#include "Trio.cpp"
#include "TrioSample.cpp"
#include "TrioCounters.cpp"
#include "HaplotypeTUCounts.cpp"
//#include "HaplotypeTUCountsVector.cpp"
//#include "PartitionHaplotypeTUCountsVector.cpp"
//#include "SetOfPartitions.cpp"
#include "TDTtable.cpp"
#include "TrioCountersHapUAndT.cpp"
//#include "TrioSNPGenotype.cpp"
//#include "MultimarkerMeasuresByBlocks.cpp"
//#include "TreeDT.cpp"
#include "PD.cpp"
#include "SampleTUCounts.cpp"
#include "TUMLTest.cpp"
#include "TUMeasures/FachadeTUMeasures.cpp"
#include "ParentalGenotypesUsingPointers.cpp"
#include "VectorOfParentalGenotypes.cpp"
#include "VectorOfParentalHaplotypes.cpp"
//#include "TreeOfHaplotypeTUCounts.cpp"
//#include "HaplotypeTUCountsTree.cpp"
#endif
