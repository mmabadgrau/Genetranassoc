/* File:
TreeOfHaplotypeTUCounts.h */


#ifndef __TreeOfHaplotypeTUCounts_h__
#define __TreeOfHaplotypeTUCounts_h__

//using namespace UTILS;


namespace BIOS
{
  /************************/
  /* TreeOfHaplotypeTUCounts DEFINITION */
  /************************/
  /**
          @memo TreeOfHaplotypeTUCounts 
   
  	@doc
   
      @author José Moreno
  	@version 1.0
  */




typedef Tree<HaplotypeTUCounts*, int>::Class TreeOfHaplotypeTUCounts;





/*______________________________________________________*/

// ostream& operator<<(ostream& out, TreeOfHaplotypeTUCounts& p);


/*______________________________________________________*/



};
;  // Fin del Namespace

#endif

/* Fin Fichero: TreeOfHaplotypeTUCounts.h */
