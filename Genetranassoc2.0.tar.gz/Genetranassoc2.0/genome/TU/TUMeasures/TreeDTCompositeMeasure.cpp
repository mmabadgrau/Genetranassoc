#ifndef __TreeDTCompositeMeasure_cpp__
#define __TreeDTCompositeMeasure_cpp__


namespace BIOS {

	TreeDTCompositeMeasure::TreeDTCompositeMeasure(TUCounts* tuCounts, int k, double minFreq):
	  CompositeTUMeasure(tuCounts, 
		new TreeDTKMeasure((TUCounts*)NULL, (int)k), // Left Measure
		new TreeDTKMeasure( (TUCounts*)NULL, (int)k)) // Right Measure
	{
		this->k = k;	
	};



	string TreeDTCompositeMeasure::getName(){
		return string("TDTbranch-"  + tos(k) );
	};


/*_________________________________________________________________*/

  TreeDTCompositeMeasure* TreeDTCompositeMeasure::getNewMeasure(TUCounts* tuCounts, SampleTUCounts** training, SampleTUCounts** test)
{
}
/*_________________________________________________________________*/

/*
		TreeDTCompositeMeasure::TreeDTCompositeMeasure()
{
		};
		*/
/*_________________________________________________________________*/

		TreeDTCompositeMeasure::~TreeDTCompositeMeasure(){
  //tuCounts=NULL;
		};
/*_________________________________________________________________*/

		double TreeDTCompositeMeasure::getStatistic(){
			throw NonImplemented("TreeDTCompositeMeasure::getStatistic()");
		};
/*_________________________________________________________________*/

		stringList* TreeDTCompositeMeasure::getHeadFile(){
throw NonImplemented("TreeDTCompositeMeasure::getHeadFile()");
		};
/*_________________________________________________________________*/

		TreeDTCompositeMeasure* TreeDTCompositeMeasure::clone(){
 return new TreeDTCompositeMeasure(*this);
		};

/*_________________________________________________________________*/



/*_________________________________________________________________*/

		TUCounts* TreeDTCompositeMeasure::getTUCounts(){
  return tuCounts;
		};

/*_____________________________________________________________*/


		void TreeDTCompositeMeasure::print(ostream& out){
 throw NonImplemented(" TreeDTCompositeMeasure::print(ostream& out)");
		};

/*_____________________________________________________________*/

  TreeDTCompositeMeasure* TreeDTCompositeMeasure::fromString(string s){throw NonImplemented("TreeDTCompositeMeasure::fromString(string s)");};


};

#endif
