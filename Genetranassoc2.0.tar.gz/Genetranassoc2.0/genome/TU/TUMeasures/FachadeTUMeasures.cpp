#ifndef __FachadeTUMeasures_cpp__ 
#define __FachadeTUMeasures_cpp__ 



//#include "TDTMeasure.cpp"
//#include "CompositeTUMeasure.cpp"
#include "SimpleTUMeasure.cpp"
#include "GroupBasedTDTMeasure.cpp"
#include "Chi2TDTMeasure.cpp"
#include "EntropyTDTMeasure.cpp"
#include "TUMeasure.cpp"
#include "G2Measure.cpp"
#include "G2TreeMeasure.cpp"
#include "TDTPMeasure.cpp"
#include "TDT1Measure.cpp"

#include "YateTDTMeasure.cpp"
#include "LaplaceTDTMeasure.cpp"
/*
#include "TreeDTMeasure.cpp"
#include "TreeDTSimpleMeasure.cpp"
#include "TDTbranchSimpleMeasure.cpp"
#include "TDTbranchMeasure.cpp"
#include "TDTbranchCompositeMeasure.cpp"
*/
/*
#include "LengthContrastMeasure.cpp"
#include "SignedRankMeasure.cpp"
#include "ScoreTDTMeasure.cpp"

#include "HWEMeasure.cpp"
*/
#endif
