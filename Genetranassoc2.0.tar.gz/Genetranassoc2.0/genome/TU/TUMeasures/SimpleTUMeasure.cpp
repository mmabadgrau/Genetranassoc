#ifndef __SimpleTUMeasure_cpp__
#define __SimpleTUMeasure_cpp__





namespace BIOS {

		SimpleTUMeasure::SimpleTUMeasure(SampleGeneticCounts* counts, double minFreq, bool permutations, bool left):TUMeasure(counts, minFreq, permutations)
{
		};

/*_________________________________________________________________*/

			SimpleTUMeasure::SimpleTUMeasure():TUMeasure()
{
		};
/*_________________________________________________________________*/

			SimpleTUMeasure::SimpleTUMeasure(double minFreq, bool permutations):TUMeasure(minFreq, permutations)
{
		};
/*_________________________________________________________________*/

			SimpleTUMeasure::SimpleTUMeasure(SimpleTUMeasure& other):TUMeasure(other)
{
		};
/*___________________________________________________________________________________*/


	double	SimpleTUMeasure::getGenotypeCount(Haplotype*a, Haplotype*b)
{
double total=0;
ParentalHaplotypesUsingPointers* p;
for (ParentalHaplotypesUsingPointersList::iterator it=this->counts->getParentalHaplotypesList()->begin();it<this->counts->getParentalHaplotypesList()->end();it++)
{
p=*it;
if (p->getHap(0,t)!=NULL && *(Haplotype*)(p->getHap(0,t))==*a && p->getHap(0,u)!=NULL && *(Haplotype*)(p->getHap(0,u))==*b) total+=p->freq;
if (p->getHap(1,t)!=NULL && *(Haplotype*)(p->getHap(1,t))==*a && p->getHap(1,u)!=NULL && *(Haplotype*)(p->getHap(1,u))==*b) total+=p->freq;
}
return total;
};	
/*_________________________________________________________________*/
/*

		SimpleTUMeasure::SimpleTUMeasure(bool permutations):GenericMeasure()
{
this->permutations=permutations;
hapExtractionConfiguration=NULL;
		};
/*_________________________________________________________________*/

			SimpleTUMeasure::~SimpleTUMeasure(){
  //counts=NULL;
		};
/*_________________________________________________________________*/
/*
		double SimpleTUMeasure::getStatistic(){
  return new SimpleTUMeasure(*this);
		};

/*_________________________________________________________________*/
/*
	 SimpleTUMeasure* SimpleTUMeasure::getNewGenericMeasure(SampleGenericCounts* tuCounts2, bool useModel)
	{
 return getNewMeasure((TUCounts*)tuCounts2, useModel);
	}
		 
	

/*_________________________________________________________________*/

			SampleGenericCounts* SimpleTUMeasure::getTUCounts(){
  return (SampleGenericCounts*)this->counts;
		};



/*_____________________________________________________________*/
/*
	double SimpleTUMeasure::getPVal()
  {
  //cout <<"measure with perms is:" << this->getName() <<"\n";
  double result=1;
  doubleList* null=new doubleList();
  double* nullArray;
  SimpleTUMeasure* tu;
  if (counts->getPermutations()==NULL) 
  counts->setPermutations();

  
  for (int i=0; i<counts->getTotalPermutations(); i++)
  {
  //if (i%10==0)  cout <<"permutation " << i <<"\n";
   tu=(SimpleTUMeasure*)this->getNewMeasure(counts->getPermutations()[i]);
   null->insertElement(tu->getStatistic());
   zap(tu);
  }
  null->sort();
//  cout <<*null <<"\nwhile real value is:" << getStatistic() <<"\n";
  nullArray=null->getTable();
  result=getPValue(nullArray, counts->getTotalPermutations(), getStatistic());
  zap(null);
  zaparr(nullArray);
  return result;
  }
/*_____________________________________________________________*/

	  SimpleTUMeasure* SimpleTUMeasure::fromString(string s){throw NonImplemented("SimpleTUMeasure::fromString(string s)");};


};

#endif
