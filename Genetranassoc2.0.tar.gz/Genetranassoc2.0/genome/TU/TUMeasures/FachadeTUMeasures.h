#ifndef __FachadeTUMeasures_h__ 
#define __FachadeTUMeasures_h__ 


#include "TUMeasure.h"
//#include "CompositeTUMeasure.h"
#include "SimpleTUMeasure.h"
#include "Chi2TDTMeasure.h"
#include "EntropyTDTMeasure.h"
#include "GroupBasedTDTMeasure.h"
//#include "TDTMeasure.h"
#include "G2Measure.h"
#include "G2TreeMeasure.h"
#include "TDTPMeasure.h"
#include "TDT1Measure.h"
//#include "TDT1TMeasure.h"
//#include "TDT1UMeasure.h"
#include "YateTDTMeasure.h"
#include "LaplaceTDTMeasure.h"
//#include "TreeDTModel.h"
//#include "TreeDTMeasure.h"

//#include "TDTbranchSimpleMeasure.h"
//#include "TDTbranchMeasure.h"
//#include "TDTbranchCompositeMeasure.h"
//#include "LengthContrastMeasure.h"
//#include "SignedRankMeasure.h"
//#include "ScoreTDTMeasure.h"
//#include "ScoreTDTPMeasure.h"
//#include "HWEMeasure.h"
//#include "WeightedTDTMeasure.h"
//#include "MeasureBuilder.h"
#endif
