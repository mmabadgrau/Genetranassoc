#ifndef GWASByBlocks_cpp//
#define GWASByBlocks_cpp//






//using namespace UTILS;

namespace BIOS
{



/*___________________________________________________________ */

void GWASByBlocks::setBlocks(char* fileBlocks)
{
// it sets an intSample with block positions: blocksPos;

    if ( totalSamples!=1 ) throw BadFormat ( "void GWASByBlocks::setBlocks(char* fileBlocks)" );


    char filePos[1024];
    changeExtension ( fileSample, filePos, "pou" );
    intList* positions=new intList(filePos);
    intList* lastBlock=NULL, *currentBlock;
    intSample* blocks=new intSample(fileBlocks);
    blocksPos=new intSample();
    int iniBlock, endBlock;
    intList*row;
intList::iterator currentIt;
    intSample::iterator it2=blocks->begin();
if (blocks->size()==0)
throw EmptyFile();
        iniBlock=blocks->getElement(it2)->getFirstElement();
        endBlock=blocks->getElement(it2)->getElement(1);
//cout << *blocks->getElement(it2);

currentBlock=new intList(' ', '\0', '\0');

bool newBlock=false;

currentIt=positions->begin();

while (currentIt!=positions->end())
    {
        // skip blocks before the current position
       while (it2!=blocks->end() && endBlock<positions->getElement(currentIt))
        {
        newBlock=true;
        iniBlock=blocks->getElement(it2)->getFirstElement();
        endBlock=blocks->getElement(it2)->getElement(1);
        it2=blocks->getNext(it2);
        }
	// end block if current position is larger than end of block or shorter than begining of the block
if (currentIt!=positions->begin() && (newBlock || positions->getElement(currentIt)<iniBlock))
{
blocksPos->insertElement(currentBlock);
currentBlock=new intList(' ', '\0', '\0');
if (positions->getElement(currentIt)>iniBlock) newBlock=false;
}
currentBlock->insertElement(positions->getPosition(currentIt));
currentIt++;
        }
blocksPos->insertElement(currentBlock);


    totalBlocks=blocks->size();
    totalChunks=totalBlocks;
    zap(blocks);
    zap(positions);
char fileBlockResults[1024];
strcpy (fileBlockResults, resultsDir);
strcat(fileBlockResults, removeDir(fileBlocks));

 ofstream OutputFile;

OpenOutput ( fileBlockResults, &OutputFile );
blocksPos->setOutputSeparator('\n');
blocksPos->setDelimiters('\0', '\0');
OutputFile << *blocksPos <<"\n";
OutputFile.close();
}
/*___________________________________________________________ */

GWASByBlocks::GWASByBlocks ( ListOfGenericMeasures* measures, char*
                             fileSample, char* blockFile, bool trios, const char* resultsDir, int
                             totalSamples, TestMode internalTestMode, int internalNumberOfFolds, int
                             externalNumberOfFolds,
                             int width, int offset, int totalPermutations, int iniPos,
                             int length, bool measureFiles, bool useOnlyHetero, bool returnPVals,
                             AlleleOrderType genotypeOrder, PhaseAlg phaseAlg, EMDistributions
                             emDistributions, EMRestriction emRestriction,   intList* alpha,  TestMode
                             externalTestMode, bool printGWASByBlocksConfig, int verbatim ): GWAS(measures, fileSample,
                                             trios, resultsDir, totalSamples, internalTestMode, internalNumberOfFolds,
                                             externalNumberOfFolds,
                                             totalPermutations, iniPos, length, measureFiles,
                                             useOnlyHetero, returnPVals, genotypeOrder, phaseAlg, emDistributions,
                                             emRestriction, alpha,  externalTestMode, printGWASByBlocksConfig, verbatim)
{
    try
    {
        setBlocks(blockFile);
        this->resultsForBlocks=resultsForChunks;
        setResults();

//printGWASByBlocksConf();
    }
    catch ( BasicException& be ) {
        be.addMessage ( "\ncalled from GWASByBlocks::GWASByBlocks(ListOfGenericMeasures* measures,, ..." );
        throw;
    };

}



/*___________________________________________________________ */

GWASByBlocks::GWASByBlocks ( ListOfGenericMeasures* measures, char*
                             trainingFileSample, char* testFileSample, char*
                             blockFile, bool trios, const char* resultsDir, int width, int offset, int
                             totalPermutations, int iniPos, int length, bool measureFiles, bool
                             useOnlyHetero, bool returnPVals, AlleleOrderType genotypeOrder, PhaseAlg
                             phaseAlg, EMDistributions emDistributions, EMRestriction emRestriction,
                             intList* alpha,  bool printGWASByBlocksConfig, int verbatim ): GWAS(measures,
                                             trainingFileSample, testFileSample, trios,
                                             resultsDir,totalPermutations, iniPos, length, measureFiles, useOnlyHetero,
                                             returnPVals, genotypeOrder, phaseAlg, emDistributions, emRestriction,   alpha,
                                             printGWASByBlocksConfig, verbatim)
{
    try
    {


        setBlocks(blockFile);
        this->resultsForBlocks=resultsForChunks;
        setResults();
//printGWASByBlocksConf();
    }
    catch ( BasicException& be ) {
        be.addMessage ( "\ncalled from GWASByBlocks::GWASByBlocks(ListOfGenericMeasures* measures,, ..." );
        throw;
    };

}


/*___________________________________________________________ */

GWASByBlocks::~GWASByBlocks()
{
    this->resultsForBlocks=NULL;
    zap(blocksPos);
    resultsForBlocks=NULL;

}

/*___________________________________________________________ */

void GWASByBlocks::set()
{
    internalTestModeClass=NULL;
    externalTestModeClass=NULL;
    hapExtractionConfiguration=NULL;
    genericMLTests=NULL;
}

/*___________________________________________________________ */
/*
	void GWASByBlocks::printGWASByBlocksConf()
	{
		cout << "internal test mode is: " << *internalTestModeClass;
		cout << "external test mode is: " << *externalTestModeClass;
	}

	/*___________________________________________________________ */

int* GWASByBlocks::getPositions(int i)
{
//cout <<"qqqq\n";
//cout <<"code is:" << *blocksPos->getElement ( i ) <<"\n";
    return blocksPos->getElement ( i )->toArray();
}
/*___________________________________________________________ */

int GWASByBlocks::getSizeOfChunk(int i)
{
    return blocksPos->getElement ( i )->size();
}

/*___________________________________________________________ */

void GWASByBlocks::setAverageResults()
{
}

/*___________________________________________________________ */
/*
	void  GWASByBlocks::setResults()
	{
		try
		{




			Container<vector<ofstream*>,ofstream*>*
listOfStreams=NULL;
			if ( measureFiles ) listOfStreams=getWindowsStreams (
false, "detail" );
			resultsForWindows=new MeasureResults**[totalMeasures];
			averageResults=new MeasureResults**[totalMeasures];
			for ( int k=0; k<totalMeasures; k++ )
				resultsForChunks[k]=new
MeasureResults*[totalChunks];

			int* pos;
			MeasureResults*** temp, * temp2[totalSamples];
			cout <<"\nTotal number of windows calculated: " <<
totalWindows<<endl;
//totalWindows=2;
			for ( int i=0; i<totalChunks; i++ )  // BLOCKS
			{
				// for each given window, repeat the process of
calculating p-values
				if ( ( i+1 ) %10==0 )
					cout <<"block number: " << i+1 <<"\n";

				pos=blocksPos->getElement ( i )->toArray();
//cout <<"positions:\n";
//print(pos, sw->getWindowSize());
				temp=new MeasureResults**[totalSamples];
				for ( int j=0; j<totalSamples; j++ )  // SAMPLES
				{
    					temp[j]=NULL;
					// for each sample file in disk (in the
corresponding window) it calculates p-values
					if ( totalSamples>1 && ( j+1 ) %10==0 )
						cout <<"sample number: " << j+1
<<endl;

					if ( genericMLTests[j]!=NULL )
					{
						// genericMLTests has the data
for each sample

genericMLTests[j]->setSampleGenericCounts ( pos, sw->getSizeOfWindow ( i ) );
						//cout << "calculate p-values
for 'measures'";

temp[j]=genericMLTests[j]->getResults ( measures, listOfStreams );  // <--
P-VALUES

						// free memory of tuCounts
generated
					genericMLTests[j]->emptyCounts();
					}
					else	temp[j]=NULL;
				}
				for ( int k=0; k<totalMeasures; k++ )
				{

					// for each measure it computes
association rates if more than one sample is used
					for ( int j=0; j<totalSamples; j++ )
						if ( temp[j]!=NULL )
temp2[j]=temp[j][k];
						else temp2[j]=NULL;
					if ( totalSamples==1 )
						if ( temp2[0]==NULL ) throw
NullValue ( "the first sample cannot be null" );
						else
resultsForWindows[k][i]=temp2[0]->clone();
					else resultsForWindows[k][i]=new
MultipleSamplesRateResults ( temp2, totalSamples, alpha, returnPVals );



					//cout <<"measure:" <<
measures->getElement(k)->getName();
					//cout <<"pval:" <<
*resultsForWindows[k][i] <<"\n";
				}
				for ( int j=0; j<totalSamples; j++ )
					zaparr ( temp[j], totalMeasures );

				zaparr ( temp, totalSamples );
				zaparr ( pos );

				//cout <<"iniSecond\n";
				//for (int x=0; x<100000; x++)
				//for (int y=0; y<20000; y++);
				//cout <<"end\n";

			} // LOOP FOR CALCULATION OF P-VALUES

			// begin STATISTICS FOR RESULTS?
			{
			 intSet* windowOverlaps;
				MeasureResults** mr=NULL;
				int totalOverlaps;
				for ( int i=0; i<totalUsedSNPs; i++ )
				{

windowOverlaps=sw->getWindowOverlapsForPosition ( i );
					totalOverlaps=windowOverlaps->size();
					mr=new MeasureResults*[totalOverlaps];
					for ( int j=0; j<measures->size(); j++ )
					{
						for ( int k=0; k<totalOverlaps;
k++ )

mr[k]=resultsForWindows[j][windowOverlaps->getElement ( k ) ];

averageResults[j][i]=mr[0]->getAverage ( mr, totalOverlaps );
					}
					zaparr ( mr);  // DO NOT CHANGE: we do
not want to delete the objetcs, only the pos
				}
				if ( measureFiles )
					for (
Container<vector<ofstream*>,ofstream*>::iterator it=listOfStreams->begin();
it<listOfStreams->end(); it++ )
						listOfStreams->getElement ( it
)->close();
			}
			// end STATISTICS FOR RESULTS?

		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from
GWASByBlocks::setResults()" ); throw;};
	}

	/*___________________________________________________________ */

MeasureResults***  GWASByBlocks::getResultsForBlocks()
{
    return resultsForBlocks;
}
/*___________________________________________________________ */

MeasureResults***  GWASByBlocks::getAverageResults()
{
    return NULL;
}
/*___________________________________________________________ */

MeasureResults**  GWASByBlocks::getResultsForBlocksForMeasure ( int
        measureIndex )
{
    return resultsForBlocks[measureIndex];
}
/*___________________________________________________________ */

MeasureResults**  GWASByBlocks::getAverageResultsForMeasure ( int
        measureIndex )
{
    return NULL;
}




	/*___________________________________________________________ */

	void   GWASByBlocks::printResultsForBlocks ( bool verticalOutput, bool
oneFile, const char* extension, stringList* firstPartHeading, stringList*
rowHeading )
	

	{
try
{
  printResultsForChunks();
  		
}

    catch (BasicException& be) {be.addMessage ("\ncalled from void GWASByBlocks::printResultsForBlocks ( bool verticalOutput, bool oneFile, const char* extension, stringList* firstPartHeading, stringList* rowHeading )");
throw;};
	}

	/*___________________________________________________________ */

Container<vector<ofstream*>,ofstream*>*
GWASByBlocks::getBlocksStreams (const char* extension )
{


    return getChunksStreams(extension);
}
/*___________________________________________________________ */
/*
Container<vector<ofstream*>,ofstream*>*
GWASByBlocks::getChunksStreams ( bool oneFile, const char* extension)
{
cout <<"isnide\n";
    return getBlocksStreams(oneFile, extension);
}

/*___________________________________________________________ */

string   GWASByBlocks::getDescription ()
{

    return string("Blocks");
}

/*___________________________________________________________ */
/*
void  GWASByBlocks::printResultsForWindow()
{
char filename[256];
for (int i=0; i<totalMeasures;i++)
{
strcpy(filename, fileSample);
sprintf(filename, "%s_resultsForSWOfSize%dAndOffsetOf%d_%s.mult",
fileSample, sw->getWindowSize(), sw->getOffset(),
measures->getElement(i)->getName().c_str());
cout <<"Results have been written in: " << filename <<"\n";
OpenOutput(filename, &OutputFile);
resultsForWindows[0][0]->printHeading(OutputFile);
OutputFile << "\n";
for (int j=0; j<totalWindows; j++)
 OutputFile << *resultsForWindows[i][j] << "\n";
OutputFile.close();
}
}

/*___________________________________________________________ */
/*
MeasureResults**  GenericMLTest::getResults(ListOfGenericMeasures*
measures, int*pos, int size)
{
MeasureResults*** results=new MeasureResults**[measures->size()],
**finalResults=new MeasureResults*[measures->size()];
GenericMeasure** training=NULL, **test=NULL;
char file[256], currentFile[256];
stringSample*sample, *result;
string t;
SampleGenericCounts* genericCounts=NULL;
//GenericSample* gs;
for (int k=0; k<measures->size();k++)
{
results[k]=new MeasureResults*[testMod->numberOfFolds];
}
for (int i=0; i<testMod->numberOfFolds;i++)
{
cout <<"fold number: " << i <<"\n";
 training=new GenericMeasure*[measures->size()];
 test=new GenericMeasure*[measures->size()];
for (int j=0; j<2;j++)
{
if (j==0) t=string("dat"); else t=string("test");
 changeExtension(fileName, file, (t+tos(i)).c_str());


 for (int k=0; k<measures->size(); k++)
 if (j==0)
 {
  if (k==0) {genericCounts=getCounts(file, pos, size);}

training[k]=measures->getElement(k)->getNewGenericMeasure(genericCounts);
   cout <<"meuasreis:" << training[k]->getName()<<"\n";
      cout << *training[k]<<"\n";
 }
 else
 {
 test[k]=training[k]->getNewGenericMeasure(genericCounts, true);
 results[k][i]=test[k]->getResults();
       cout <<"meuasreis:" << *test[k]<<"\n";
       cout << *results[k][i] <<"\n";
 }
 remove(currentFile);
 }
  zap(genericCounts);
  zaparr(training, measures->size()); zaparr(test, measures->size());
}
for (int k=0; k<measures->size();k++)
{
finalResults[k]=results[k][0]->getAverage(results[k],
testMod->numberOfFolds);
zaparr(results[k], testMod->numberOfFolds);
}
zaparr(results, measures->size());
zaparr(pos);

return finalResults;
}
*/
} // end namespace
#endif
