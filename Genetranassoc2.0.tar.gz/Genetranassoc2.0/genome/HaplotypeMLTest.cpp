#ifndef HaplotypeMLTest_cpp//
#define HaplotypeMLTest_cpp//






//using namespace UTILS;

namespace BIOS
{

  HaplotypeMLTest::HaplotypeMLTest (char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int codeTrios, int verbose) :GenomeMLTest (fileSample, internalTestMod, externalTestMod, hapExtractionConfiguration, totalPermutations, codeTrios, verbose) // 3 is to say that information in each sample file has to be split together in trios (trio samples)
  {
  try
  {
  //  this->useOnlyHetero=useOnlyHetero;
//checkOrder(fileSample);
    }
catch (BasicException & be){be.addMessage("\ncalled from HaplotypeMLTest::HaplotypeMLTest (char* fileSample, TestModeClass *testMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero)"); throw;};
  }
  
    /*___________________________________________________________ */
  
/*
  
   void  HaplotypeMLTest::checkOrder(char*fileSample)
    {
      TrioSample* ts=new TrioSample (fileSample, NULL, 0, hapExtractionConfiguration->alleleOrderType);
if (!ts->groupedFamilies())
{
cout << "some families are not written in consecutive lines at file " << fileSample << "\n";
//throw BadFormat("HaplotypeMLTest::HaplotypeMLTest (char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero)");
//exit(0);
zap(ts);
exit(0);
}
zap(ts);
    }

  /*___________________________________________________________ */
  
    HaplotypeMLTest::HaplotypeMLTest (char* fileSample,char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int codeTrios, int verbose) :GenomeMLTest (fileSample, secondFileSample, hapExtractionConfiguration, totalPermutations, codeTrios, verbose) // 3 is to say that information in each sample file has to be split together in trios (trio samples)
  {
  try
  {
//checkOrder(fileSample);
//checkOrder(secondFileSample);

     


  }
catch (BasicException & be){be.addMessage("\ncalled from  HaplotypeMLTest::HaplotypeMLTest (char* fileSample,char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero)"); be.PrintMessage(); throw;};
  }

  /*___________________________________________________________ */


  HaplotypeMLTest::~HaplotypeMLTest()
  {
  }
  /*___________________________________________________________ */
/*
  GenericSample*  HaplotypeMLTest::getSample (char* file, int*pos, int length)
  {
    try
    {
       TrioSample *hapSample=NULL;
      bool completeMis=true, allowRecombination=false, solveMIUsingChildren=false, completeFamily=true;
    //   int sizeInPhase=7;//maxi(7,length);
//cout <<"length is:" << length <<" and size is:" << sizeInPhase <<"\n";
//cout << "getting sample from file " << file <<"\n";
      TrioSample* ts=new TrioSample (file, NULL, 0, hapExtractionConfiguration->alleleOrderType, completeMis, allowRecombination, solveMIUsingChildren, completeFamily);
//cout <<"now\n";

//BIOS::print(pos, length, cout);
      VectorOfParentalGenotypes* result=ts->getGenotypeCounts (pos, length, hapExtractionConfiguration, true);// it only works for left/right and incomplete left/right so far

     zap (ts);
     return  result;
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from GenericSample*  HaplotypeMLTest::getSample(char* file, int* pos, int size) "); throw;};
  }



  /*___________________________________________________________ */
/*
  SampleGenericCounts*  HaplotypeMLTest::getCounts (GenericSample* ts, int* pos, int windowSize)
  {
    try
    {
bool includeMissing=true;// true

//BIOS::print(pos, windowSize, cout);

      SampleTUCounts* results= (SampleTUCounts*)( (VectorOfParentalGenotypes*) ts)->getSampleTUCounts (hapExtractionConfiguration2, totalPermutations, pos, windowSize, includeMissing);
if (verbose) cout << "total size in each window/chink: " << results->getTotalPos() <<"\n";
if (verbose) cout << "total size in each parental genotype:" << results->getParentalGenotypes()->getTotalPositions() <<"\n";
if (1==0)
if (windowSize>10)
{
cout <<"tucounts:" << *results;
exit(0);
}
      return results;
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from  SampleGenericCounts*  HaplotypeMLTest::getCounts(char* file, int* pos, int size)"); throw;};
  }
  
    /*___________________________________________________________ */
} // end namespace
#endif
