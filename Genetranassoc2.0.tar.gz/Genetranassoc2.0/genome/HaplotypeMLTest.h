#ifndef HaplotypeMLTest_h//
#define HaplotypeMLTest_h//



namespace BIOS {




//class InputTUI;


////////////////////////////

class HaplotypeMLTest: public GenomeMLTest 
{

/** This class is used as a generalization of any sample (ML Sample, genetic samples, etc.) so that they all can be divided in order to use tests, classifier or any other measure using different testting comfigurations (cross-validation, holdout, training).
*/



private:

//TrioSample**  

// bool useOnlyHetero;


public:

//HaplotypeMLTest(char* fileSample, TestModeClass *testMod);
HaplotypeMLTest(char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int codeTrios, int verbose=0);
HaplotypeMLTest (char* fileSample,char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int codeTrios, int verbose =0);
// void checkOrder(char* file)=0;
~HaplotypeMLTest();
virtual SampleGenericCounts* getCounts(GenericSample* ts, int* pos, int size)=0;
virtual GenericSample* getSample(char* file, int* iniPos, int size)=0;
};

} // end namespace
#endif

