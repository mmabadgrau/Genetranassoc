/* File: MultimarkerMeasure.h */


#ifndef __SampleHaplotypeCaseControlCounts_cpp__
#define __SampleHaplotypeCaseControlCounts_cpp__





//using namespace stats;
#include "SampleHaplotypeCounts.h"

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////



/*_________________________________________________________________*/

SampleHaplotypeCaseControlCounts::SampleHaplotypeCaseControlCounts(int* pos, int* absPos, int length, GeneticUnitCountsVector* countsVector, int totalPermutations): SampleHaplotypeCounts(pos, absPos, length, countsVector, totalPermutations)
{
//this->hapExtractionConfiguration=hapExtractionConfiguration;
}


/*_________________________________________________________________*/
/*
SampleHaplotypeCaseControlCounts::SampleHaplotypeCaseControlCounts(int* pos, int length, GeneticUnitCountsVector* countsVector, int totalPermutations): SampleGenericCounts(totalPermutations)
{
this->countsVector=countsVector;
this->hapExtractionConfiguration=NULL;
this->length=length;
if (pos!=NULL)
{
this->pos=new int[length];
for (int i=0; i<length; i++)
 this->pos[i]=pos[i];
}
else this->pos=NULL;
}

/*_________________________________________________________________*/

SampleHaplotypeCaseControlCounts::SampleHaplotypeCaseControlCounts(SampleHaplotypeCaseControlCounts& tu): SampleHaplotypeCounts((SampleHaplotypeCounts&) tu)
{
//this->hapExtractionConfiguration=tu.hapExtractionConfiguration;
}

 	

/*_________________________________________________________________*/

SampleGenericCounts* SampleHaplotypeCaseControlCounts::clone()
{
return new SampleHaplotypeCaseControlCounts(*this);
}



/*_________________________________________________________________*/

SampleHaplotypeCaseControlCounts::~SampleHaplotypeCaseControlCounts ()
{
}





/*_________________________________________________________________*/

 SampleHaplotypeCaseControlCounts::SampleHaplotypeCaseControlCounts(): SampleHaplotypeCounts()
{
//hapExtractionConfiguration=NULL;
}


/*_________________________________________________________________*/


AssociationTable* SampleHaplotypeCaseControlCounts::createBasicAssociationTable(TUMeasure*g)
{
 // cout << "about creating\n";
  AssociationTable*a= new HaplotypeCaseControlTable(this->getCountsVector(), g->minFreq);
 // cout << "table created at SampleHaplotypeCaseControlCounts::createBasicAssociationTable(TUMeasure*g): " << *a << endl;
 // cout << "from " << *this->getCountsVector() << end;
  return a;
}


/*_________________________________________________________________*/

AssociationTable* SampleHaplotypeCaseControlCounts::createComposedAssociationTable(GeneticUnitCountsSample * p)
{
return new HaplotypeCaseControlTable(p);
}	
/*_________________________________________________________________*/
/*
AssociationTable* SampleHaplotypeCaseControlCounts::createAssociationTable(TUMeasure*g)
{
// cout << "
//throw NonImplemented("SampleHaplotypeCaseControlCounts::createAssociationTable(TUMeasure*g)");

//		cout << "before in s\n";	
AssociationTable* a= new HaplotypeCaseControlTable(this->getCountsVector(), g->minFreq), *result=NULL;
			double totalFirst=a->getTotalFirstRow(), totalSecond=a->getTotalSecondRow();

//cout <<"basictable:" << *a <<"\n";
   zap(a);
GeneticUnitCountsSample * p=g->getPartition(getCountsVector(), totalFirst, totalSecond);
//cout <<"partition is: " << *p <<"\n";
//cout <<"after fil\n";
//cout <<"remove p\n";
//cout << "totalelement in first:" << p->getElement(0)->size() <<"\n";
//cout << "totalelement in second:" << p->getElement(1)->size() <<"\n";
//zap( p->getElement(0));
//zap( p->getElement(1));
//			zap ( p );
			if ( p->getElement ( 0 )->size() >0 && p->getElement ( 1 )->size() >0 )
				result=new TDTtable( p );
//cout <<"newtable:" << *result <<"\n";

			zap ( p );
			return result;
}

/*_________________________________________________________________*/

AssociationTable* SampleHaplotypeCaseControlCounts::createAssociationTable(Vector<GeneticUnitCounts*>::Class*g)
{
//  cout << "SampleHaplotypeCaseControlCounts::inside createAssociation\n";
return new HaplotypeCaseControlTable(g);
}






};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */

//stringList * BIOS::SampleHaplotypeCaseControlCounts::getTDTFreqsResults(SNPPos snpPos)
//{
//}






