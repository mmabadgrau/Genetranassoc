#ifndef HaplotypeCaseControlMLTest_h//
#define HaplotypeCaseControlMLTest_h//



namespace BIOS {




class HaplotypeMLTest;

////////////////////////////

class HaplotypeCaseControlMLTest: public HaplotypeMLTest
{

/** This class is used as a generalization of any sample (ML Sample, genetic samples, etc.) so that they all can be divided in order to use tests, classifier or any other measure using different testting comfigurations (cross-validation, holdout, training).
*/



private:




public:

//HaplotypeCaseControlMLTest(char* fileSample, TestModeClass *testMod);
HaplotypeCaseControlMLTest(char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int verbose=0);
HaplotypeCaseControlMLTest (char* fileSample,char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int verbose =0);
~HaplotypeCaseControlMLTest();
virtual SampleGenericCounts* getCounts(GenericSample* ts, int* pos, int size);
virtual GenericSample* getSample(char* file, int* iniPos, int size);
};

} // end namespace
#endif

