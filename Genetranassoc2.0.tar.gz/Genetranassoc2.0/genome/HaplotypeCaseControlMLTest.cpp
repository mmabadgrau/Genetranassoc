#ifndef HaplotypeCaseControlMLTest_cpp//
#define HaplotypeCaseControlMLTest_cpp//






//using namespace UTILS;

namespace BIOS
{

  HaplotypeCaseControlMLTest::HaplotypeCaseControlMLTest (char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int verbose) :HaplotypeMLTest (fileSample, internalTestMod, externalTestMod, hapExtractionConfiguration, totalPermutations, 1, verbose) // 1 is to say that information in each sample file is from independent subject (case/control))
  {
  try
  {
    }
catch (BasicException & be){be.addMessage("\ncalled from HaplotypeCaseControlMLTest::HaplotypeCaseControlMLTest (char* fileSample, TestModeClass *testMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero)"); throw;};
  }
  
   

  /*___________________________________________________________ */
  
    HaplotypeCaseControlMLTest::HaplotypeCaseControlMLTest (char* fileSample,char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int verbose) :HaplotypeMLTest (fileSample, secondFileSample, hapExtractionConfiguration, totalPermutations, 1, verbose) // 3 is to say that information in each sample file is from independent subjects (case/control)
  {
  try
  {
    


  }
catch (BasicException & be){be.addMessage("\ncalled from  HaplotypeCaseControlMLTest::HaplotypeCaseControlMLTest (char* fileSample,char* secondFileSample, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero)"); be.PrintMessage(); throw;};
  }

  /*___________________________________________________________ */


  HaplotypeCaseControlMLTest::~HaplotypeCaseControlMLTest()
  {
  }
  /*___________________________________________________________ */

  GenericSample*  HaplotypeCaseControlMLTest::getSample (char* file, int*pos, int length)
  {
    try
    {
        GenomaSample* ts=new GenomaSample (file, NULL, 0, everybody, hapExtractionConfiguration->alleleOrderType);
      GenomaSample* result=ts->filter (pos, length);// it only works for left/right so far
     zap (ts);
     return  result;
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from GenericSample*  HaplotypeCaseControlMLTest::getSample(char* file, int* pos, int size) "); throw;};
  }



  /*___________________________________________________________ */

  SampleGenericCounts*  HaplotypeCaseControlMLTest::getCounts (GenericSample* ts, int* pos, int windowSize)
  {
    try
    {


SampleGenericCounts* result=( (GenomaSample*) ts)->getSampleHaplotypeCaseControlCounts (totalPermutations, pos, windowSize, everyGender, true);

return result;

    }
    catch (BasicException& be) {be.addMessage ("\ncalled from  SampleGenericCounts*  HaplotypeCaseControlMLTest::getCounts(char* file, int* pos, int size)"); throw;};
  }
} // end namespace
#endif
