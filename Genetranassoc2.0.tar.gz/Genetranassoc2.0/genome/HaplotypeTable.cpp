#ifndef __HaplotypeTable_cpp__
#define __HaplotypeTable_cpp__




/*_____________________________________________________________*/

void print ( BIOS::HaplotypeTable *t )
{
	cout << *t << endl;
}


/*_____________________________________________________________*/


namespace BIOS
{

	HaplotypeTable::HaplotypeTable ( int cols, double minFreq, bool HWE ) :AssociationTable (cols, minFreq, HWE)
	{
	};

	/*_____________________________________________________________________________________________________________*/


	HaplotypeTable::HaplotypeTable ( const HaplotypeTable& other ) :AssociationTable( (AssociationTable& ) other )
	{
	};

	/*_____________________________________________________________________________________________________________*/

/*
	AssociationTable* HaplotypeTable::clone()
	{
		return new HaplotypeTable ( *this );
	}

	

	/*_____________________________________________________________________________________________________________*/


	HaplotypeTable::HaplotypeTable ( GeneticUnitCountsSample * p, int totalRows, double minFreq, bool HWE )
			:AssociationTable (p, totalRows, minFreq, HWE )
	{
		
	};

	/*_____________________________________________________________________________________________________________*/

	HaplotypeTable::HaplotypeTable ( GeneticUnitCountsVector * p, int totalRows, double minFreq, bool HWE )
			:AssociationTable (p, totalRows, minFreq, HWE )
	{
	};




};

#endif
