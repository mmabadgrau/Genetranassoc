/* File: EM.h */

#ifndef __EM_h__
#define __EM_h__



//using namespace UTILS;


namespace BIOS {



class EM: public Classifier
{
private:


int iterations;
floatMLSample* reducedSample;
floatlist targetInputPattern;




private:


virtual void setMLEstimations();
virtual void runEMAlgorithm(int it);
virtual double* getFrequencies();
virtual void setExpectation();
virtual void maximize();

void set ();

public:

EM();


//EM(char* filename, floatList* parameterList);

EM(floatMLSample* sample, int att, floatList* parameterList, VerbosityClass *verbosity, LossFunction* lossFunction, int iterations=1000);

	
~EM();

virtual double* GetClassFrequencies(floatList* targetInputPattern);

};
};  // Fin del Namespace

#endif

//#include "EM.cpp"
/* Fin Fichero: EM.h */
