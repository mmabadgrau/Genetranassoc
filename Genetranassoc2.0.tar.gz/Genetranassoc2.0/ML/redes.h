stringList
#ifndef redes_h//
#define redes_h//
char FileName[63]; // para c45
#include "backprop.h"//  
#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//
#include "recuento.h"//
#include "frecuencias.h"//
#include "SampleFrequencies.h"//
#include "defns.h"// C4.5//
#include "types.h"//
#include "extern.i"//
#include "c4.5.h"//
#include "buildex.i"//
#include "getnames.h"// //
#include "getdata.h"// //
#include "trees.h"// //
#include "sort.h"//
#include "info.h"//
#include "contin.h"// //
#include "discr.h"// //
#include "stats.h"// //
#include "subset.h"// //
#include "build.h"//
#include "confmat.h" //
#include "besttree.h"//
#include "prune.h"//  //
#include "classify.h"//
#include <cassert>//
#define numints 10;

////////////////////////////
class red//
{//
private://
 bool verbosity;
 unsigned int error,//
 suma_dim, *padres, acumulados, ModoSeleccion; //
 char *marcado_completo, carac;//
 unsigned int dependiente, cualitativos;
 unsigned int *cambiados, *cambiadosexactos; //
 unsigned short int salida; //
 int  maximo_modalidades_ord, numero_clases, *modalidades;//
 entrada_caracter caracter;//
 entrada_cadena cadena;//
 entrada_numero entero;//
 real numreal;//
 float *valorescambiados;//
 muylargos numeromuylargo;//
 tabla tabla_enteros, tabla_reales, tabla_caracteres, tabla1;//
 fichero_entrada fichero_entrada1, fichero_entrada2;//
 fichero_salida fichero_salida1, fichero_salida2, fichero_salida3;//
 double dimension;//
 bool mostrar_intervalos; //
 unsigned int  taman_ficherot, taman_ficherop;  //
 int *incompletosorig;//
 struct nodo *tablanodo;// tabla con pares de nodos
 double *tablacon;//tabla con el valor IMC de cada par de nodos
 
 void leerfichero (unsigned int, int*, int*, char, float*, unsigned int); //
// int comparar (const void*, const void*); // 
 unsigned int cuentaclase(char); //
 float cuentaatributo(unsigned int, char); //
 unsigned int seleccionar_atributos(unsigned int, unsigned int, unsigned int, unsigned int*);//
 void seleccionar_atributos2(unsigned int, unsigned int,   int, unsigned int*);//
 unsigned int obtener_distintos(void);//
 void creararchivoseleccion (char, char*, char);//
 unsigned int calculartotalclasesensegmento (float, float, unsigned int, unsigned int); //
 void proyectar_seleccionar (char[63],unsigned int, char);//
 int comprobar_igual(unsigned int, unsigned int);//
 int comprobar_igual_proyeccion(unsigned int, unsigned int, bool);//
 int comprobar_igual_clase(unsigned int, unsigned int);//
 double seleccionar_entrenamiento(char*, unsigned int);//
 void marcar_prueba (unsigned int);//
 void restaurarmarcado (void);//
 void restaurarmissing2 (void);//
 void poda_parcial(char [63]);//
 void podar_parcialmente(char [63]); //
 void dividir(unsigned int, char[63], char[63], unsigned int);//
 void prueba2(char, unsigned int, float&);//
 void nuevo(char, unsigned int, float&);//
 void eliminar_repetidos(char[63]);//
 unsigned int obtenerlugar(struct frecuencia*, int, //
 int, unsigned int*, unsigned int, unsigned int*, char,
 unsigned int, unsigned int); //
 unsigned int obtenerlugarmayo2003(struct frecuencia*, int, //
 int, unsigned int*, unsigned int, unsigned int*, char); //
 unsigned int obtener_configuracion(void);//
 void convertir_formato_UCI(char[63]);//
 void independencia_parcial(char [63]);//
 double obtener_indice_por_combinacion(int, int, unsigned int*,  //
 unsigned int, int, unsigned int*);//
 double IMC(unsigned int, unsigned int, unsigned int, unsigned int*, char);//
 double obtenermaximofichero (unsigned int); //
 double obtenermaximofichero2 (unsigned int); //
 unsigned int ObtenerTotalMarcados(char tipo);
 unsigned int podar(unsigned int);//
 unsigned int podarsesgo(unsigned int);//
 unsigned int podarsesgo2(unsigned int);//
 void seleccionvariospadres(unsigned int, char, unsigned short int, bool, bool);//
 void seleccionvariospadres2(unsigned int, char, unsigned short int, bool, bool);//
 void seleccionpadresTAN(unsigned int, char, unsigned int, bool);//
 int PosicionNodo (unsigned int, bool);
 bool EsAscendiente (unsigned int, unsigned int); //
 bool EsPadreTAN (unsigned int, unsigned int); //
 void encontrarpadres (unsigned int);//
 void inclusion2(unsigned int);//
 void inclusion3(unsigned int);//
 unsigned short int espadre (unsigned int, unsigned int); //
 float* puntero_patrones(void); //
 void obtenerintervalos (unsigned int*, unsigned int*, unsigned int*, unsigned int*, //
 unsigned int, unsigned int, int*, int*, struct frecuencia*, //
 int, unsigned int*, char, unsigned int, unsigned int); //
 void borrarmarcas(void);//
 void BuscaArcoGanador ();
 void CrearArbolMaximo (unsigned int);
 void ImprimirArbol ();
 void ObtenerRaiz ();
 double obtenermargenSRM (unsigned short int, unsigned short int, double, double long*, unsigned int, float, double &, double &);
 unsigned int ObtenerDependiente();
public://
 char *marcado; //
 float total_intervalos_parcial, *patrones;
 struct atributo *atributos; //
 unsigned int *patronborrado, total_atributos_entrada, total_atributos, taman_fichero, taman_ficheromissing, taman_ficheromissingt, taman_ficheromissingp, total_seleccionados;
 int  incompleta, incompletaorg, maximo_modalidades, *incompletos; //
// red (); //
 red(char[63], int,  struct atributo*, unsigned int, char, unsigned short int, unsigned short int, bool verbosity);//
 unsigned int total_clases(void); //
 void imprimir_atributos_seleccionados ();
 unsigned int obtener_total_seleccionados();//
 unsigned int obtener_total_atributos_entrada_seleccionados();//
 void realizar_seleccion (char, unsigned int*, bool);
 void seleccionar_todos();
 void imprimir_tipodisc (int disc);
 unsigned int seleccionar_atributos (unsigned int,unsigned int);//
 void asignaIMC (char, unsigned int);                           
 void ImprimirIMC (unsigned int);
 void marcar_entrenamiento_prueba (unsigned int, unsigned int, unsigned int);//
 void discretizacion(char, int); //
 void DiscretizarVariable (char tipo, int disc, unsigned int i);
 void quitarmissing (void);//
 void quitarmissingorg (void);//
// void quitarmissingsindiscretizar (void);//
 void ponerruido (unsigned int);//
 void restaurarmissing (void);//
 void deteriorar (unsigned int, unsigned int);//
 void perder (unsigned int, unsigned int, unsigned int);//
 void restaurardeterioro (unsigned int, unsigned int);//
 unsigned int bayes(char, bool, bool);//
 unsigned int c45(char, char[63], char, short int, unsigned short int); //
 unsigned int m1nn(char, unsigned short int);//
 unsigned int knn(char, unsigned int, unsigned short int);//
 unsigned int DependenciaFuncional(char tipo, unsigned int clase, unsigned int condicionados, unsigned int* TablaCondicionados);//
 int METADALINE (float, char, int, long); //
 int METBP ( float, char, int, long,int); //
 void podaMRE(unsigned int);//
 void inclusionIMC(unsigned int, char);//
 void obtener_padres(unsigned int, unsigned int, char, unsigned int);//
 void LeerFrecuencias(char tipo,unsigned int *topedesbordamiento,unsigned int **dimensiones_condicionantes,unsigned int **bases,int *total_distribuciones,int *total_distribuciones_condicionantes,struct frecuencia **total_condicionantes, unsigned int *tf, unsigned int *tfa, unsigned int *tp);
 unsigned int ContarAciertosBayes(char tipo, bool bayesiano, bool convex, unsigned int *topedesbordamiento,unsigned int **dimensiones_condicionantes,unsigned int **bases,int *total_distribuciones,int *total_distribuciones_condicionantes,struct frecuencia **total_condicionantes,unsigned int *tf,unsigned int *tp,unsigned int *tfa);
 ~red();
 };
//////////////
 red::~red() {

 zap (padres); //
 zap (marcado_completo);
 zap (patronborrado); 

 zap (marcado);  //

 zap (incompletos); 
 zap (incompletosorig); //
 zap (atributos); //
 zap (modalidades); //
 zap (tablacon);
 zap (patrones); 
 zap (tablanodo);
 
 zap (cambiados);          //
 zap (cambiadosexactos); //
 zap (valorescambiados);//

 };//
///////////////////////////////////////
red::red(char texto[63], int total_atribs_entr, struct atributo *atribs, unsigned int id, char tipofichero,
unsigned short int sal, unsigned short int seleccion1, bool verb)//
{//
/* Pasa a memoria interna los patrones del fichero de entrada, guardando las//
entradas y las salidas en tablas con ese nombre.//
Almacena adem s el taman_fichero y el total_modalidades para cada uno de los//
atributos*///
red::ModoSeleccion=seleccion1;
verbosity=verb;
salida=sal;//
if (salida==3) mostrar_intervalos=true; else mostrar_intervalos=false;
acumulados=0;
total_atributos_entrada=total_atribs_entr;//
total_atributos=total_atributos_entrada+1;//

if ((padres= new unsigned int[total_atributos_entrada*(total_atributos_entrada+2)])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//

dependiente=total_atributos_entrada;//
if ((atributos = new atributo[(total_atributos_entrada+1)])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//

if ((tablacon=new double[total_atributos_entrada*total_atributos_entrada])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((tablanodo = new nodo [total_atributos_entrada-1])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
///////////
total_intervalos_parcial=0.0;
unsigned int i2, num_atributo;//
total_seleccionados=total_atributos_entrada+1;//
atributos[total_atributos_entrada].seleccionado=1;//
//char a;//
for (int i=0; i <= total_atributos_entrada; i++)//
{//
 atributos[i].seleccionado=1; //
 atributos[i].total_modalidades=atribs[i].total_modalidades;//
// cout <<"totmods atrib: " << i <<": " << atributos[i].total_modalidades;//
 strncpy (atributos[i].nombre, atribs[i].nombre, 19);//
 atributos[i].nombre[19]='\0'; //
 atributos[i].tipo_distancia=atribs[i].tipo_distancia;//
// cout <<"nombre: " << atributos[i].nombre; //
 if (atributos[i].tipo_distancia<2) //
 {//
  for (int i2=0; i2 < atributos[i].total_modalidades; i2++) //
   { //
		strncpy(atributos[i].modalidad[i2], atribs[i].modalidad[i2], 39); //
		atributos[i].modalidad[i2][39]='\0'; //
 //  cout <<"\nmod atrib " << i <<":" << atributos[i].modalidad[i2] <<" "; //
   }//
 }//
 else //
  for (int i2=0; i2< cpuntos; i2++) //
   atributos[i].puntos[i2]=atribs[i].puntos[i2]; //
 } //

 fichero_entrada1.abrir(texto);//
 taman_fichero=fichero_entrada1.taman();//
 if (tipofichero=='p') // si se usan dos ficheros (.data y .test)
 {//
 char *texto2;//
 if ((texto2 = new char[64])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);
  };//
 strcpy(texto2, texto);// //
 cadena.cambiar_cadena(texto,  texto2, (char*)"test", '.');//
 fichero_entrada2.abrir(texto2);//
 taman_ficherot=taman_fichero;//
 //cout <<"tamfich:" << taman_fichero;
 taman_ficherop=fichero_entrada2.taman();//
 taman_fichero=taman_ficherot+taman_ficherop;//
 taman_ficheromissingt=taman_ficherot;//
 taman_ficheromissingp=taman_ficherop;//
 zap (texto2); //
 }//
// else taman_ficherot=taman_fichero; // se usa un fichero .all
 
// cout <<"\nEn el fichero existen " << taman_fichero <<" patrones\n";//
//cin >>a;//
 ///////////////////
 
 taman_ficheromissing=taman_fichero;//
if ((incompletos=new int[total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((incompletosorig=new int[total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
 if ((patrones=new float[taman_fichero*total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
//cout <<"tamantotal:" << sizeof(float)*taman_fichero*total_atributos;//
if ((marcado_completo = new char[taman_fichero])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((marcado = new char[taman_fichero])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if (tipofichero=='t') // un solo fichero .all
{//
  tabla_caracteres.iniciar ('t', taman_fichero, marcado_completo);//marca los patrones que//
  //alguna vez se han elegido como de prueba.//
  tabla_caracteres.iniciar ('t', taman_fichero, marcado);//
}//
  else //
  {//                                                                       
  tabla_caracteres.iniciar ('t', taman_ficherot, marcado_completo);//marca los patrones que//
  tabla_caracteres.iniciar ('p', taman_ficherop, marcado_completo+taman_ficherot);//marca los patrones que//
  tabla_caracteres.iniciar ('t', taman_ficherot, marcado);//
  tabla_caracteres.iniciar ('p', taman_ficherop, marcado+taman_ficherot);//marca los patrones que//
  }//
if ((patronborrado=new unsigned int[taman_fichero])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
//  total_modalidades_muestra = new  unsigned int[total_atributos]; // n£mero total de modalidades por atributo//
//  tabla_enteros.iniciar (0, total_atributos, total_modalidades_muestra);//
 
 maximo_modalidades=0; //
  cualitativos=1;//
  for (int i=0; i < total_atributos-1; i++) //
  {//
   if (atributos[i].tipo_distancia==1) //
	if (atributos[i].total_modalidades > maximo_modalidades_ord) //
		maximo_modalidades_ord=atributos[i].total_modalidades; // //
   if (atributos[i].tipo_distancia<2) //
	if (atributos[i].total_modalidades > maximo_modalidades) //
	 maximo_modalidades=atributos[i].total_modalidades; //
   if (atributos[i].tipo_distancia!=0) //
	cualitativos=0;//
  }//
  if ((modalidades= new int [total_atributos*(maximo_modalidades+1)])==NULL)
{
cout <<"falta memoria"; exit(0);
};//
  tabla_enteros.iniciar (0, total_atributos*(maximo_modalidades+1), &modalidades[0]);//
  tabla_enteros.iniciar (0, total_atributos, incompletos);//
  tabla_enteros.iniciar (0, total_atributos, incompletosorig);//
  tabla_enteros.iniciar (0, taman_fichero, patronborrado);//
  incompletaorg=0;//
  if (tipofichero=='t') //
  {//
// cout <<"STE:";//
// cin >>a;//
  red::leerfichero (taman_fichero, &incompletaorg, incompletosorig, 't', patrones, id); //
  fichero_entrada1.close();//
  }//
  if (tipofichero=='p') //
  {//
  red::leerfichero (taman_ficherot, &incompletaorg, incompletosorig, 't', patrones, id); //
  fichero_entrada1.close();//
  red::leerfichero (taman_ficherop, &incompletaorg, incompletosorig, 'p', patrones, id); //
  fichero_entrada2.close();//
  }//
//exit(0);//
//cout <<"Maxmods: " << maximo_modalidades;//

  for (num_atributo=0;num_atributo<total_atributos;num_atributo++) //
  {//
//   for (i=0; i<maximo_modalidades;i++)//
		if (incompletosorig[num_atributo]==1)//  && (atributos[num_atributo].tipo_distancia<2))//
	{//
//         incompletos[num_atributo]=1; //
//cout <<"atribin: " <<num_atributo;//
	 atributos[num_atributo].total_modalidades=atributos[num_atributo].total_modalidades+1;//
	}//
  }//

 incompleta=incompletaorg;//
 
// if (incompleta==1) //
//  cout <<"Base de datos incompleta\n";//
//  red::discretizacion('t', 2);//

///////////

 if ((valorescambiados=new float[taman_fichero*(total_atributos-1)])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//

  
 if ((cambiados=new unsigned int[taman_fichero*(total_atributos-1)])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((cambiadosexactos=new unsigned int[taman_fichero*(total_atributos-1)])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }
//

 tabla1.iniciar(0, taman_fichero*(total_atributos-1), cambiados);//
 tabla1.iniciar(0, taman_fichero*(total_atributos-1), cambiadosexactos);//
 tabla1.iniciar(0.0, taman_fichero*(total_atributos-1), valorescambiados);//

}//
/////////////////////////////////
#include "discretizacion.h"//                                                                                                   
////////////////
unsigned int red::ObtenerDependiente()
{
return(dependiente);
}
//////////////////////////
void red::DiscretizarVariable (char tipo, int disc, unsigned int i)
{
	discretizacion::discretizacion *discretiz;

	  if ((discretiz = new discretizacion::discretizacion(tipo, disc, this, i))==NULL)
     {
	 cout << "fallo de memoria";
	 exit(0);
	 }
	  if (mostrar_intervalos)
	  discretiz->PrintIntervals();
}

///////////////////////
void red::discretizacion(char tipo, int disc)
{
	
int atribsreales=0;
for (int i=0; i<total_atributos_entrada; i++)//
{
comprobar (atributos, i, total_atributos, "d36");
if (atributos[i].tipo_distancia==2) // continuo
{//

DiscretizarVariable(tipo, disc, i);
//if (2==3)
{
 atribsreales=atribsreales+1;
 if (mostrar_intervalos)
  cout <<"\nAtrib: " <<i <<": "; // << atributos[i].total_modalidades; //
 for (int i2=0; i2<(atributos[i].total_modalidades-1);i2++)//
 {
 comprobar (atributos[i].puntos, i2, cpuntos, "d37");
 if (mostrar_intervalos)
 cout <<atributos[i].puntos[i2] <<", "; //
 }
 total_intervalos_parcial=total_intervalos_parcial+atributos[i].total_modalidades;
 if (mostrar_intervalos)
 cout <<"\ntotalints:" <<  atributos[i].total_modalidades;

}
};

};

total_intervalos_parcial=total_intervalos_parcial/(float)atribsreales;
//cout <<"atribsreales: " << atribsreales;
//total_intervalos=total_intervalos+total_intervalos_parcial;
//cout <<"\ntotalintsacum:" <<  total_intervalos_parcial;

  }
//////////
unsigned int red::total_clases()//
{//
unsigned int total_class=0;//
total_class=atributos[ObtenerDependiente()].total_modalidades;//
if (incompletos[ObtenerDependiente()]==1) //
total_class= //
atributos[ObtenerDependiente()].total_modalidades-1;//
return(total_class); //
}//
////////
/////////////////////////
void red::leerfichero (unsigned int tamfich, int *inca, int *incos, char tipo, float *patrs, unsigned int id) //
{ //
 unsigned int num_atributo, offset, inicio, patron;//
 char a;//
 char *buffer, *cad;//
 numero_clases=atributos[total_atributos_entrada].total_modalidades;//
//cout << "clases: " << clase[0] <<clase[1];//
 if ((cad=new char[128])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);
  };//
if ((buffer = new char[100000])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
// cout <<"numatrib: " <<total_atributos;//
// cin >>a;//
if (tipo=='t') inicio=0;//
else inicio=taman_ficherot;//
 for (patron=inicio; patron <(tamfich+inicio); patron++)//
   {//
// cout <<"patron:"<<patron<<"\n";
   if (tipo=='t') //
	fichero_entrada1.get (buffer, 99999, '\n'); //
   else //
	fichero_entrada2.get (buffer, 99999, '\n'); //
	fichero_entrada1.clear(); 
	fichero_entrada2.clear();
	if (*(buffer+strlen(buffer)-1)=='.') //
	 *(buffer+strlen(buffer)-1)='\0';//
//    cout <<"patron " << patron << "\nbuffer:" << buffer<<"\n";//
//cin >>a;//
// cout <<"\npatron " << patron;//
	if (tipo=='t') //
	fichero_entrada1.fin_de_linea();//
	else //
	fichero_entrada2.fin_de_linea();//
	fichero_entrada1.clear(); 
	fichero_entrada2.clear();       
	offset=0;//
	if (id==1) //
	{//
	 sscanf (buffer+offset, "%s", cad);//
	 offset=offset+strlen(cad)+1;//
	}//
//    cout <<"seg";//
//    cin >>a;//
//    cout <<"patron " << patron << "\nbuffer:" << buffer<<"\n";//
	for (num_atributo=0;num_atributo<total_atributos;num_atributo++) //
	{//
 //    cout <<"\n buffer:";
 //    cout << buffer+offset;//
 //    cout << buffer;//
  //  cout <<"patron " << patron << "\nbuffer:" << buffer+offset<<"\n";//
 //    exit(0);
	sscanf (buffer+offset, "%s", cad);//
	offset=offset+strlen(cad)+1;//
	if (num_atributo<total_atributos_entrada) //
     if (*(cad+strlen(cad)-1)==',')
	  *(cad+strlen(cad)-1)='\0';//
// cout <<"cadena: " <<cad;//
//cout <<"ter";//
//   cin >>a;//
	if (strncmp(cad, "?", 1)==0) //
	{ //
//         cout <<"desc patr" << patron;//
//     exit(0);//
	 *inca=1; //
	 incos[num_atributo]=1;//
//    cout <<"falta arib " <<num_atributo <<"en paadtron: " <<patron;//
	 if (atributos[num_atributo].tipo_distancia < 2) //
	  patrs[patron*total_atributos+num_atributo]=(float)atributos[num_atributo].total_modalidades;//
	 else //
	 { //
	 patrs[patron*total_atributos+num_atributo]=(float)maxreal;//
//     cout <<"valor del patron" <<patron <<", atribcont:" <<num_atributo <<": " << //
//     patrs[patron*total_atributos+num_atributo]<<"\n"; //
	 } //
	}//
	else //
	{ //
//     cout <<"cuar";//
//     cin >>a;//
	 if (atributos[num_atributo].tipo_distancia < 2) //
	 {//
//     cout <<"cuar2";//
//     cin >>a;//
	 patrs[patron*total_atributos+num_atributo]=(float)cadena.buscarcadena (cad,  //
	  atributos[num_atributo]);//
 //      cout << patrs[patron*total_atributos+num_atributo] <<" "; //
//     cout <<"cuar3";//
//     cin >>a;//
//      if (num_atributo==total_atributos_entrada) //
//       cout <<"\nnum_atributo: " <<num_atributo <<", valor:" <<cad <<" "; //
   //   cout <<"quin";//
//     cin >>a;//
	  if ((unsigned int)patrs[patron*total_atributos+num_atributo]>=atributos[num_atributo].total_modalidades)//
	  { //
	   cout <<"\nError en el atributo " << num_atributo <<" del patron " <<patron <<"valor: " <<cad <<", valor conv:" << //
	   patrs[patron*total_atributos+num_atributo]; //
	  cin >>a;//
	  }//
	 }//
	 else //
	 {//
	  patrs[patron*total_atributos+num_atributo]=atof(cad);//
//      cout <<cad <<" " <<patrs[patron*total_atributos+num_atributo]; //
	 }//
	} //
 //   cout <<"sex0";//
//          cin >>a;//
//	cout <<"valor atrib " << num_atributo << ": " << patrs[patron*total_atributos+num_atributo];
   }// fin atributo//
//     cout << patrones[patron*total_atributos+num_atributo];//
//    cout <<"\n";//
// cout <<"sex";//
//          cin >>a;//
 }// fin patron//
// exit(0);
zap (cad);
zap (buffer);
} //

///////////////
void red::imprimir_atributos_seleccionados ()
{
	cout <<"\nAtributos seleccionados: ";
for (int i=0;i<total_atributos;i++)
 if (atributos[i].seleccionado==1)
	 cout << i << "(" << atributos[i].nombre <<"), ";
}

////////////////////
unsigned int red::obtener_total_seleccionados()//
 {
  unsigned total=0;
  for (int i=0; i<total_atributos;i++)
   if (atributos[i].seleccionado==1)
	total++;
   return (total);
 }
////////////////////
unsigned int red::obtener_total_atributos_entrada_seleccionados()//
 {
  unsigned total=0;
  for (int i=0; i<total_atributos_entrada;i++)
   if (atributos[i].seleccionado==1)
	total++;
   return (total);
 }
////////////////////
void red::seleccionar_todos()//
 {
  for (int i=0; i<total_atributos;i++)
   atributos[i].seleccionado=1;
 }

#include "seleccion.h"
/////////
void red::realizar_seleccion (char tipo, unsigned int *listaseleccion, bool all)
{
sel_mode mode=(sel_mode) ModoSeleccion;
seleccion * sel;

if (mode==manual && all)
 seleccionar_todos();
else
{


  if ((sel = new seleccion(ObtenerDependiente(), tipo, ModoSeleccion, this, listaseleccion))==NULL)
     {
	 cout << "fallo de memoria";
	 exit(0);
	 }
};

}
/////////////////////////////////////////////
void red::borrarmarcas()//
{//
 tabla_caracteres.iniciar ('t', taman_fichero, marcado_completo);//marca los patrones que//
}//
//////////////////
unsigned int red::seleccionar_atributos(unsigned int dep, unsigned int seleccionar)//
{//
char pod, *textoatributo;//
unsigned int contador;//
if ((textoatributo = new char[4])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);
}  ;//
//
dependiente=dep;//
atributos[dependiente].seleccionado=0;//
//
if (seleccionar==2)//
{//
total_seleccionados=total_atributos_entrada;//
pod=caracter.leer_sn((char*)"+Desea eliminar algun atributo (s/n): ",'n');//
if (pod=='s') //
{//
do//
{//
 textoatributo = cadena.leer((char*)"Introduzca atributo a eliminar('f' para terminar): ",4, 1);//
 if ((textoatributo[0] != 'f') && (atributos[atoi(textoatributo)].seleccionado==1) 
&& (atoi(textoatributo)!= dependiente))//
 {//
  atributos[atoi(textoatributo)].seleccionado=0;//
  total_seleccionados=total_seleccionados-1;//
 }//
}//
while (textoatributo[0] != 'f');//
}//
} //
else // incorporar//
{//
total_seleccionados=0;//
for (contador=0; contador<total_atributos_entrada; contador++) //
 atributos[contador].seleccionado=0; //
pod=caracter.leer_sn((char*)"Desea incorporar algun atributo (s/n)?: ",'n');//
if (pod=='s') //
{//
do//
{//
 textoatributo = cadena.leer((char*)"Introduzca atributo a incorporar('f' para terminar): ",4, 1);//
 if ((textoatributo[0] != 'f') && (atributos[atoi(textoatributo)].seleccionado==0) 
&& (atoi(textoatributo)!= dependiente))//
 {//
  atributos[atoi(textoatributo)].seleccionado=1;//
  total_seleccionados=total_seleccionados+1;//
 }//
}//
while (textoatributo[0] != 'f');//
}//
} //
return(total_seleccionados);//
zap (textoatributo);
}//
//////////////////
unsigned int red::seleccionar_atributos(unsigned int dep, //
unsigned int seleccionar, unsigned int numero, //
unsigned int *atribs)//
{//
unsigned int cont;//
//
dependiente=dep;//
atributos[dependiente].seleccionado=0;//
//
if (seleccionar==2)//
 {//
total_seleccionados=total_atributos_entrada;//
for (cont=0; cont < numero; cont++) //
{//
  atributos[atribs[cont]].seleccionado=0;//
  total_seleccionados=total_seleccionados-1;//
 }//
} //
if (seleccionar==1)// incorporar//
{//
total_seleccionados=0;//
for (cont=0; cont < total_atributos_entrada; cont++) //
 atributos[atribs[cont]].seleccionado=0; //
for (cont=0; cont < numero; cont++) //
{//
  atributos[atribs[cont]].seleccionado=1;//
  total_seleccionados=total_seleccionados+1;//
 }//
} //
return(total_seleccionados);//
}//
//////////////////////////////////////////////
//////////////////
void red::seleccionar_atributos2(unsigned int dep, unsigned int total,//
int seleccionar,unsigned int *tabla_orden)//
{//
unsigned int contador;//
dependiente=dep;//
if ((seleccionar==1) || (seleccionar==0))//   seleccionar  o todos//
{//
for (contador=0; contador<total_atributos; contador++) //
 atributos[contador].seleccionado=0; //
//total_seleccionados=total+1;//
for (contador=0; contador<total;contador++) //
 atributos[tabla_orden[contador]].seleccionado=1;//
}//
if (seleccionar==2)//  eliminar//
{//
//total_seleccionados=total_atributos-total;//
for (contador=0; contador<total_atributos; contador++) //
 atributos[contador].seleccionado=1; //
for (contador=0; contador<total;contador++) //
 atributos[tabla_orden[contador]].seleccionado=0;//  //
}//
atributos[dep].seleccionado=1; //
//if ((seleccionar==1) && (total==6))//
//for (contador=0; contador<total_atributos;contador++) //
// cout << atributos[contador].seleccionado <<" ";//  //
//exit(0);//
//
//return(total_seleccionados);//
}//
//////////////////
void red::convertir_formato_UCI (char texto[63])//
//copia todos los patrones de la red separ ndolos por comas. Finaliza cada patr¢n con un punto.//
{//
unsigned int num_atributo, patron;//
fichero_salida1.abrir(texto);//
 for (patron=0;patron<taman_fichero;patron++)//
  if (patronborrado[patron]==0) //
  {//
  for (num_atributo=0;num_atributo<total_atributos; num_atributo++)//
  {//
	if (num_atributo != (total_atributos-1))//
	  fichero_salida1 << patrones[patron*total_atributos+num_atributo] << ", ";//
	else//
	 fichero_salida1 <<patrones[patron*total_atributos+num_atributo] << ".";//
 }//
 fichero_salida1 << "\n";//
  }//
 fichero_salida1.close();//
}//
//////////////////
void red::creararchivoseleccion (char tipo, char texto[63], char discreto)//
//copia s¢lo los patrones de prueba o de entrenamiento.//
{//
// discreto contiene un 1 si se ha prediscretizado, si no, contiene un 0
unsigned int num_atributo, tam, patron;//
char *valor;//
float posicion;//
fichero_salida1.abrir_truncando(texto);//

 for (patron=0;patron<taman_fichero;patron++)//
  if (patronborrado[patron]==0) //
   if (((tipo=='p') && (marcado[patron]=='p')) || ((tipo=='t') && (marcado[patron]=='t'))) //
   {//
    for (num_atributo=0;num_atributo<total_atributos; num_atributo++)//
     if (atributos[num_atributo].seleccionado==1) //
     {//
      posicion=intervalo(patrones[patron*total_atributos+num_atributo], num_atributo, atributos[num_atributo]);//
      // si no se ha prediscretizado y el atributo es continuo
      if ((atributos[num_atributo].tipo_distancia == 2) && (discreto=='0'))//
       if (patrones[patron*total_atributos+num_atributo]==(float)maxreal)  fichero_salida1 << "?, ";//
       else fichero_salida1 << patrones[patron*total_atributos+num_atributo] << ", ";//
      else//si discreto o numerico o discretizado//
      {//
       if ((incompletos[num_atributo]==1) &&//
	(((atributos[num_atributo].tipo_distancia<2) &&    //
	(posicion==atributos[num_atributo].total_modalidades-1)) || //
	((atributos[num_atributo].tipo_distancia==2) && //
	((float)patrones[patron*total_atributos+num_atributo]==(float)maxreal)))) //
	{//
	 if ((valor=new char[2])==NULL)
	 {
	  // cout <<"Falta memoria";
	  exit(0);
	 };//
	 strcpy (valor,"?\0");//
	} // fin incompleto//
	else //             si completo//
	{//
	 if (atributos[num_atributo].tipo_distancia == 2)//
	  tam=5; //
	 else//
	  tam=strlen(atributos[num_atributo].modalidad[(unsigned int)posicion]); //
	 if ((valor=new char[tam+1])==NULL) //
	 {//
	  // cout <<"Falta memoria";//
	  exit(0);//
	 }//
	 valor[0]='\0';//
	 if (atributos[num_atributo].tipo_distancia == 2)//
	  gcvt ((double)posicion, tam, valor);//
	 else//
	 {//
	  strcpy (valor, atributos[num_atributo].modalidad[(unsigned int)posicion]); //
	  // cout <<"atrib:" << num_atributo <<", MD:" << atributos[num_atributo].modalidad[(unsigned int)posicion];//
	 }//
	 //       valor[tam]='\0';//
	} // fin si completo//
	if (valor[0]==' ') cout <<"Error"; //
	 if (num_atributo<total_atributos-1) //
	 {//
	  fichero_salida1 << valor << ", ";//
		//  cout <<valor << ", ";//
	 }//
	 else fichero_salida1 << valor << ".";//
	 zap (valor); //
	}// fin si atributo discreto o discretizado//
       }// fin para cada atributo no eliminado//
      fichero_salida1 << "\n";//
      // cout <<"\n";//
     }// fin para cada patron//
 fichero_salida1.close();//
// zap (valor);
}//
//////////////////////////////////////////////
void red::proyectar_seleccionar (char texto[63], unsigned int //
cont, char tipo)//
//copia todos los patrones de la red si tipo vale "c" o s¢lo los de entrenamiento//
//o prueba seg£n tipo valga "t" o "p" respectivamente. Además proyecta por aquellos//
// atributos con valor 1 en atributos.seleccionado//
{//
unsigned int num_atributo, patron;//
fichero_salida1.abrir(texto);//
fichero_salida1 << cont << "\n";//
 for (patron=0;patron<taman_fichero;patron++)//
  if (patronborrado[patron]==0) //
   if ((tipo == marcado[patron]) || (tipo == 'c'))   //
  {//
   for (num_atributo=0;num_atributo<total_atributos; num_atributo++)//
   if (atributos[num_atributo].seleccionado==1) //
   { //
	if (num_atributo != (total_atributos-1))//
	  fichero_salida1 << patrones[patron*total_atributos+num_atributo] << " ";//
	else//
	  fichero_salida1 <<patrones[patron*total_atributos+num_atributo] << " ";//
   }//
  fichero_salida1 << "\n";//
}//
 fichero_salida1.close();//
}//
///////////////////////
unsigned int red::cuentaclase(char tipo) //
{//
unsigned int totalclase, patron, *cuentaclas, resultado; //
totalclase=red::total_clases();//
//cout <<"tc: " << totalclase;
if ((cuentaclas=new unsigned int [totalclase])==NULL)
{
cout <<"falta memoria";
exit(0);
};//
tabla1.iniciar(0, totalclase, cuentaclas);//
for (patron=0; patron<taman_fichero;patron++) //
 if (((tipo == 'p')&& (marcado[patron]==tipo)) || (tipo =='t'))//
  if (patronborrado[patron]==0) //
   cuentaclas[intervalo(patrones[patron*total_atributos+total_atributos_entrada], total_atributos_entrada, atributos[total_atributos_entrada])]=//
   cuentaclas[intervalo(patrones[patron*total_atributos+total_atributos_entrada], total_atributos_entrada, atributos[total_atributos_entrada])]+1;//
resultado=tabla1.maximo(totalclase, cuentaclas); //
//cout <<"result:" << resultado;
zap (cuentaclas);
return (resultado); //
}//
///////////////////////
float red::cuentaatributo(unsigned int atrib, char tipo) //
{//
float resultado; 
unsigned int rango, patron, *cuentaatrib; //
rango= atributos[atrib].total_modalidades;//
if ((cuentaatrib=new unsigned int[rango])==NULL)
{
cout <<"falta memoria";
exit(0);
};//
tabla1.iniciar(0, rango, cuentaatrib);//
for (patron=0; patron<taman_fichero;patron++) //
 if (((tipo == 'p')&& (marcado[patron]!=tipo)) || (tipo =='t'))//
  if (patronborrado[patron]==0) //
  //
	cuentaatrib[intervalo(patrones[patron*total_atributos+atrib], atrib, atributos[atrib])]=//
	cuentaatrib[intervalo(patrones[patron*total_atributos+atrib], atrib, atributos[atrib])]+1;//
resultado= (float) tabla1.maximo (rango, cuentaatrib);//
zap (cuentaatrib);
return resultado;
}//
////////////////////////////////////////////
double red::seleccionar_entrenamiento(char *clase, unsigned int total)//
//Obtiene el ¡ndice de dependencia de la clase dado un conjunto de atributos//
{//
unsigned int *eliminado, *total_class, contador, posicion, num_atributo,//
patron, patron2, igual, igual_clase, coincidente, exacto, encontrado_igual_clase;//
double configuracion, fiabilidad;//
if ((eliminado=new  unsigned int[taman_fichero])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
tabla_enteros.iniciar(0,taman_fichero, eliminado);//
if ((total_class=new unsigned int [total_clases()+1])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
contador=0;//
exacto= 0;//
configuracion=1;//
coincidente = 0; //cuenta los patrones coincidentes en entradas pero no//
// en clase//
for (patron=0;patron<taman_fichero;patron++)//
  if (patronborrado[patron]==0) //
{//
 for (num_atributo=0;num_atributo<total_atributos; num_atributo++)//
  if (eliminado[patron] == 0)//
 {//
  contador=contador+1;//
 tabla_enteros.iniciar (0, numero_clases+1, total_class);//
 for (num_atributo=0;num_atributo<total_atributos; num_atributo++)//
 if (atributos[num_atributo].seleccionado==1) //
  posicion=strchr (clase,(unsigned int)patrones[patron]) - clase;//
  total_class[posicion]=1;//
  total_class[numero_clases]=1;//
  encontrado_igual_clase=0;//
  for (patron2=patron+1; patron2<taman_fichero;patron2++) //
   if (patronborrado[patron2]==0) //
	   if (eliminado[patron2]==0)//
   {//
	igual=red::comprobar_igual(patron, patron2);//
	if (igual==1)//
	{//
	 eliminado[patron2]=1;//
	 coincidente=coincidente+1;//
	 posicion=strchr(clase,(unsigned int)patrones[patron2])-clase;//
	 total_class[posicion]=total_class[posicion]+1;//
	 total_class[numero_clases]=total_class[numero_clases]+1;//
	 igual_clase=red::comprobar_igual_clase(patron, patron2);//
	 if (igual_clase==1)//
	 {//
	  exacto=exacto+1;//
	  encontrado_igual_clase=1;//
	 }//
   }//
  }//
 if (encontrado_igual_clase==1) exacto=exacto+1;//
}//
}//
//
//indice=coincidente/taman_ficheromissing;//
cout << "exacto:" << exacto << ", sucesos:" << contador <<", configur:" << configuracion; //
fiabilidad=(double)exacto/(double)//
(contador*configuracion);//es el n§ de patrones iguales en las entradas menos la estudiada//
// e iguales en la clase dividido por el n£mero de posibles patrones //
//iguales en todas las entradas menos la estudiada (sin repetirlos)//
if (fiabilidad > 1) fiabilidad = 1;//
//fiabilidad=sqrt(fiabilidad);//
cout <<"Fiabil: " <<fiabilidad <<"\n";//
//zap eliminado;//
zap (total_class);//
zap (eliminado);//
return(fiabilidad);//
}//
//////////////////////////////////////////////
void red::poda_parcial(char texto[63])//
{//
unsigned int patron, atrib, cont, tam;//
fichero_entrada fich_entr;//
fich_entr.abrir(texto);//
tam=fich_entr.taman();//
//cout << "En el fichero existen " <<tam <<" filas. \n";//
for (cont=0; cont <tam;cont++)//
{//
fich_entr >> patron;//
//cout <<"Leyendo fila " << cont << "\r";//
fich_entr >> atrib;//
patrones[patron*total_atributos+atrib]=(float)maxreal;//
}//
fich_entr.close(); //
cout <<"\n";//
}//
//////////////////////////////////////////////
void red::podar_parcialmente(char texto[63])//
{//
unsigned int cont; //, enviado;//
fstream io (texto, ios::trunc);//
io.close();//
for (cont=0;cont<total_atributos;cont++)//
{//
//enviado=tabla1.minimo(total_atributos, lista_independencias);//
//lista_independencias[enviado]=maxreal;//
//cout <<"atributo  " <<enviado << "\n";//
 red::independencia_parcial(texto);//
 } //
}//
////////////////////////////////////////////////
  int red::comprobar_igual(unsigned int p1, unsigned int p2)//
{//
unsigned int igual, num_atributo;//
igual=1;//
  for (num_atributo=0; num_atributo<total_atributos; num_atributo++)//
	 if (intervalo(patrones[p2*total_atributos+num_atributo], num_atributo, atributos[num_atributo])!=//
		intervalo(patrones[p1*total_atributos+num_atributo], num_atributo, atributos[num_atributo]))//
	 igual=0;//
return(igual);//
   }//
////////////////////////////////////////////////
  int red::comprobar_igual_proyeccion(unsigned int p1, unsigned int p2, bool zeros=false)//
{//
unsigned int igual, num_atributo;//
igual=1;//
  for (num_atributo=0; num_atributo<total_atributos; num_atributo++)//
   if (atributos[num_atributo].seleccionado==1) //
        if (num_atributo!=ObtenerDependiente()) //
	{//
	 if ((zeros==false) || ((patrones[p2*total_atributos+num_atributo]!=0) &&  //
		(patrones[p1*total_atributos+num_atributo]!=0)))//
	 
	 if (intervalo(patrones[p2*total_atributos+num_atributo], num_atributo, atributos[num_atributo])!=//
		intervalo(patrones[p1*total_atributos+num_atributo], num_atributo, atributos[num_atributo]))//
	 igual=0;//
 //    else //
//    cout <<"\npatron1: " <<p1 <<"coincide con patr " <<p2 <<" en atrib: " <<num_atributo; //
	}//
return(igual);//
   }//
////////////////////////////////////////////////
  int red::comprobar_igual_clase(unsigned int p1, unsigned int p2)//
{//
unsigned int igual;//
igual=1;//
	 if (patrones[(p2+1)*total_atributos]!=patrones[(p1+1)*total_atributos])//
	 igual=0;//
return(igual);//
   }//
/////////////////////////////////////
void red::dividir(unsigned int total_training, char texto1[63], char texto2[63], //
unsigned int contador)//
/*texto1 contendr  los patrones completos de //
entrenamiento, texto2 los de prueba //
*///
{//
// time_t t;//
 int elegido, cont2, desp, total_prueba;//
 unsigned int num_atributo, patron;//
 fichero_salida1.abrir(texto1);//
 fichero_salida2.abrir(texto2);//
 fichero_salida1 << total_atributos-1 << "\n";//
 fichero_salida2 << total_atributos-1 << "\n";//
 total_prueba=taman_ficheromissing-total_training;//
//srand((unsigned) time(&t));//
tabla1.iniciar('t', taman_fichero, marcado);//
////////////    selecci¢n de patrones de prueba //////////////7//
 for (patron=0; patron < total_prueba; patron++)//
  {//
   cont2=0;//
   elegido=rand() % (taman_fichero-(contador*total_prueba)+patron);     //
//Selecciona de forma aleatoria los patrones de prueba sin repetirlos y cuando elige//
//uno marca con una 'p' su posici¢n en la tabla "marcado_completo".//
//cout <<" numero:" << elegido;//
	 for (desp=0;desp<(elegido); desp++) //
   {//
   cont2=desp;//
	while ((marcado_completo[cont2]=='p') || (patronborrado[cont2]==1))//
	 cont2=cont2+1;//
	 }//
   elegido=cont2;//
  marcado[elegido]='p';//
  for (num_atributo=0; num_atributo < total_atributos-1; num_atributo++)//
   fichero_salida2 << patrones[elegido*total_atributos+num_atributo] <<" ";//
  fichero_salida2 <<patrones[elegido*total_atributos+total_atributos-1] <<"\n";//
  }//
//
////////// el resto se guardan en los ficheros de entrenamiento (sin y con poda)//
 for (patron=0; patron < taman_fichero; patron++) //El resto van al fichero de patr. de prueba//
  if (patronborrado[patron]==0) //
	if (marcado[patron] == 't') //
  {//
   for (num_atributo=0; num_atributo<total_atributos-1;num_atributo++) //
	 fichero_salida1 << patrones[patron*total_atributos+num_atributo] <<" ";//
   fichero_salida1 <<patrones[patron*total_atributos+total_atributos-1] <<"\n";//
  }//
fichero_salida1.close();//
fichero_salida2.close();//
 }//
////////////////
void red::restaurarmarcado (void) //
{ //
 tabla_caracteres.iniciar ('t', taman_fichero, marcado_completo);//
}//
/////////////////////////////////////
void red::marcar_entrenamiento_prueba(unsigned int tipoprueba, unsigned int total_training, unsigned int contador)//
//marca con una "p" los patrones de prueba en la tabla "marcado_completo" y con "t" los//
// de entrenamiento.//
{ //
// tipoprueba es el fold, 1 si hay 2 ficheros
// time_t t;//
//char a;//
 int elegido, elegido_real, cont, total_prueba, patron=0;//
unsigned contador2=0;//
total_prueba=taman_ficheromissing-total_training;//
tabla_caracteres.iniciar ('t', taman_fichero, marcado);//
//cout <<"totalprueba: " <<total_prueba;//
//cout <<", TP:" <<tipoprueba;
// srand((unsigned) time(&t));//
//if (total_prueba==0)//
//{
// tabla_caracteres.iniciar ('p', taman_fichero, marcado);//
// cout <<"todos en p" <<",tamfich:" << taman_fichero;
//}
//else
if ((tipoprueba==1) && (total_prueba>0))//
{ //
for (cont=taman_ficheromissingt; cont<taman_fichero; cont++) //
 marcado[cont]='p';//
}//
else
if ((tipoprueba>1) && (total_prueba>0))// val. cruzada
{ //
//////////// selecci¢n de patrones de prueba ////////////////
//
while (contador2<total_prueba)//
{ //
  //if (patronborrado[patron]==0) //
 {//
 //Selecciona de forma aleatoria los patrones de prueba sin repetirlos y cuando elige//
//uno marca con una 'p' su posici¢n en la tabla "marcado_completo".//
  elegido=rand() % (taman_ficheromissing-(acumulados)-contador2);//
  //cout <<"quedan: " <<taman_ficheromissing-(acumulados)-contador2-1;//
  elegido_real=-1;//
   for (cont=0;cont<=elegido; cont++)//
  {//
  elegido_real=elegido_real+1;//
  while ((patronborrado[elegido_real]==1) || (marcado_completo[elegido_real]=='p')) //
   elegido_real=elegido_real+1;//
  }//
//cout <<"\ner:" <<elegido_real <<"el:" << elegido;  
if (elegido_real>=taman_fichero) {cout <<"fuera de tabla"; exit(0);}
marcado_completo[elegido_real]='p';//
  marcado[elegido_real]='p';//
//  cout <<"Marcado patron:" <<elegido_real;//
contador2=contador2+1;//
}//
 //patron=patron+1;//
 }//
}//
 taman_ficheromissingp=0; //
 taman_ficheromissingt=0;  //
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==0) //
   if (marcado[patron]=='p') taman_ficheromissingp=taman_ficheromissingp+1;//
   else taman_ficheromissingt=taman_ficheromissingt+1;//
//cout <<"\ntamprueba: " <<taman_ficheromissingp;
//cout <<"tamantrenamiento: " <<taman_ficheromissingt;
acumulados=acumulados+total_prueba;
}//
/////////////////////////////////////
void red::marcar_prueba(unsigned int total_training)//
//marca con una "p" los £ltimos total_taining# patrones de prueba en la tabla "marcado_completo" y con "t" los//
// de entrenamiento.//
{ //
 unsigned int elegido, patron;//
// tabla tabla_enteros;//
 tabla_caracteres.iniciar ('t', taman_fichero, marcado);//
 ////////////    selecci¢n de patrones de prueba //////////////7//
//
 for (patron=taman_fichero; patron > total_training; patron--)//
 { //
  elegido=patron;//
  while (patronborrado[elegido]==1) // elegido=elegido+1;//
  marcado_completo[elegido]='p';//
  marcado[elegido]='p';//
 }//
}//
/////////////////////////////////////
void red::restaurarmissing(void)//
//Vuelve a usar los patrones con atributos desconocidos//
{ //
 int patron, atributo, encontrado, tope;//
 encontrado=0; //
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==1) //
  {//
  for (atributo=0; atributo<total_atributos; atributo++) //
   if (atributos[atributo].seleccionado==1)
  {//
   tope=atributos[atributo].total_modalidades;//
	  if (((atributos[atributo].tipo_distancia<2) &&    //
	  (intervalo(patrones[patron*total_atributos+atributo], atributo, //
   atributos[atributo])==tope)) || //
   ((atributos[atributo].tipo_distancia==2) && //
   ((float)patrones[patron*total_atributos+atributo]==(float)maxreal))) //
	  {//
		encontrado=1;//
		incompletosorig[atributo]=1;//
	  }//
  }//
   patronborrado[patron]=0;//
 }//
  for (atributo=0; atributo<total_atributos; atributo++) //
   if (atributos[atributo].seleccionado==1)
//   if ((incompletos[atributo]==0) && (incompletosorig[atributo]==1)) //
  if (incompletosorig[atributo]==1)//
   {//
	  atributos[atributo].total_modalidades=atributos[atributo].total_modalidades+1;//
  }//
   if (encontrado==1) incompletaorg=1;//
 taman_ficheromissing=taman_fichero;//
 }//
////////
/////////////////////////////
void red::restaurarmissing2(void)//
//Vuelve a usar los patrones con atributos desconocidos//
{ //
 int patron, atributo;//  encontrado;//
// encontrado=0; //
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==1) //
  {//
  for (atributo=0; atributo<total_atributos; atributo++) //
  {//
	  if (((atributos[atributo].tipo_distancia<2) &&    //
	  (intervalo(patrones[patron*total_atributos+atributo], atributo, //
   atributos[atributo])==atributos[atributo].total_modalidades)) || //
   ((atributos[atributo].tipo_distancia==2) && //
   ((float)patrones[patron*total_atributos+atributo]==(float)maxreal))) //
   {//
		incompletos[atributo]=1; //
   }//
  }//
   patronborrado[patron]=0;//
 }//
 taman_ficheromissing=taman_fichero; //
// cout <<"TAMFICHMISSrestaurado:" <<taman_ficheromissing;//
 }//
///////////
void red::restaurardeterioro(unsigned int tipomissing, unsigned int total_training) //
{//
unsigned int cont, num_atributo, patron;//
//cout <<"totatrib:" << total_atributos;//
for (cont=0; cont<(total_training*(total_atributos-1)); cont++) //
 if (cambiados[cont]==1) //
 {//
  patrones[cambiadosexactos[cont]]=valorescambiados[cont];//
//  cout <<"\nPOSbasedevuelto: " <<cont;//
//  cout <<"\npatrondevuelto:" << cambiadosexactos[cont]/total_atributos<<", atrib: " <<cont%total_atributos <<", valor: " << valorescambiados[cont];//
 if (tipomissing==3)//
{//
   patronborrado[cambiadosexactos[cont]/total_atributos]=0;//
   if (marcado[cambiadosexactos[cont]/total_atributos]=='p')//
   cout <<"ERROR";//
//
// cout <<"\npatr:" << cambiadosexactos[cont]/total_atributos;//
   }//
 } //
if (tipomissing==1) //
for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
 if (atributos[num_atributo].seleccionado==1)
 if (incompletos[num_atributo]==1) //
 {//
  incompletos[num_atributo]=0; //
  if (incompletosorig[num_atributo]==0)//
  if (atributos[num_atributo].tipo_distancia<2)//
  atributos[num_atributo].total_modalidades=atributos[num_atributo].total_modalidades-1;//
//  cout <<"\natributo incompleto:" << num_atributo <<"totmods:" <<atributos[num_atributo].total_modalidades;//
 }//
if (tipomissing==3)//
{//
 taman_ficheromissing=taman_fichero-tabla1.suma(0, taman_fichero, patronborrado);//
 taman_ficheromissingp=0; //
 taman_ficheromissingt=0;  //
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==0) //
   if (marcado[patron]=='p') taman_ficheromissingp=taman_ficheromissingp+1;//
   else taman_ficheromissingt=taman_ficheromissingt+1;//
}//
}//
/////////////////////////////////////
void red::deteriorar(unsigned int missing, //
unsigned int total_training)//
//Elimina o cambia (seg£n tipomissing) un missing% de los valores  de forma aleatoria//
{ //
 unsigned int elegido, aleatorio, p, valor, totalmissing, atrib, patr, patron;//

 totalmissing=missing*total_training*(total_atributos-1)/100;//
// cout <<"totalmissing: " <<totalmissing; //
 for (valor=0; valor<totalmissing;valor++) //
 {//
  do //
  {//
  elegido=rand() % (total_training*(total_atributos-1));//
  if (elegido >= (total_training*(total_atributos-1))) //
  { //
   cout <<"Error, fuera de rango"; //
   exit(0); //
  } //
  }//
  while (cambiados[elegido]==1); //
  cambiados[elegido]=1;//
//  cout <<"\nPOSbase: " <<elegido;//
  atrib=elegido%(total_atributos-1);//
  patron=elegido/(total_atributos-1);//
  patr=0;//
  for(p=0; p < (patron+1); p++) //
  {//
   while ((marcado[patr]=='p') || (patronborrado[patr]==1))  //
   {//
	patr=patr+1;//
   }//
  if (p<patron) //
   patr=patr+1;//
  }//
  if ((marcado[patr]=='p') || (patronborrado[patr]==1)) cout <<"ERROR";//
  cambiadosexactos[elegido]=total_atributos*patr+atrib;//
  valorescambiados[elegido]=patrones[patr*total_atributos+atrib];//
//  cout <<"\nPATRON: " <<patr <<", atrib: " << atrib <<"valor:" <<valorescambiados[elegido];//
   do //
	aleatorio=rand()%taman_fichero;//
   while ((patronborrado[aleatorio]==1) || (marcado[aleatorio]=='p'));//
   if ((marcado[aleatorio]=='p') || (patronborrado[aleatorio]==1)) cout <<"ERROR";//
   patrones[patr*total_atributos+atrib]=patrones[aleatorio*total_atributos+atrib];//
//cout <<"\nP: " << patr*total_atributos+atrib;//
//cin >>a;//
  }//
}//
/////////////////////////////////////
void red::perder(unsigned int missing, unsigned int tipomissing, //
unsigned int total_training)//
//Elimina o cambia (seg£n tipomissing) un missing% de los valores de forma aleatoria//
{ //
 unsigned int elegido, p, num_atributo, valor, totalmissing, patr, cont, patron;//
//cout <<"HH"<<"total-tainf:" <<total_training <<", totlatrib:" <<total_atributos;//
//cout <<"TT:" << total_training;//
 tabla1.iniciar(0, total_training*(total_atributos-1), cambiados);//
 tabla1.iniciar(0, total_training*(total_atributos-1), cambiadosexactos);//
 tabla1.iniciar(0, total_training*(total_atributos-1), valorescambiados);//
 totalmissing=missing*total_training*(total_atributos-1)/100;//
// cout <<"totalmissing: " <<totalmissing; //
 for (valor=0; valor<totalmissing;valor++) //
 {//
  do //
  {//
  elegido=rand() % (total_training*(total_atributos-1));//
  if (elegido >= (total_training*(total_atributos-1))) //
  { //
   cout <<"Error, fuera de rango"; //
   exit(0); //
  } //
  }//
  while (cambiados[elegido]==1); //
  cambiados[elegido]=1;//
//  cout <<"\nPOSbase: " <<elegido;//
  num_atributo=elegido%(total_atributos-1);//
  patron=elegido/(total_atributos-1);//
  patr=0;//
  for(p=0; p < (patron+1); p++) //
  {//
   while ((marcado[patr]=='p') || (patronborrado[patr]==1))  //
   {//
	patr=patr+1;//
   }//
  if (p<patron) //
   patr=patr+1;//
  }//
  if ((marcado[patr]=='p') || (patronborrado[patr]==1)) cout <<"ERROR";//
  cambiadosexactos[elegido]=total_atributos*patr+num_atributo;//
  valorescambiados[elegido]=patrones[patr*total_atributos+num_atributo];//
//  cout <<"\nP: " <<patr <<"pos:" << elegido;//
//
  if ((tipomissing==1) || (tipomissing==3))//
  {//
  incompletos[num_atributo]=1;//
  if (atributos[num_atributo].tipo_distancia<2) //
{//
   patrones[patr*total_atributos+num_atributo]=(float)atributos[num_atributo].total_modalidades;//
//cout <<"patron:" << patr;//
}//
  else//
  patrones[patr*total_atributos+num_atributo]=(float)maxreal;//
  }//
  if (tipomissing==2) //
  {//
   patrones[patr*total_atributos+num_atributo]=red::cuentaatributo(num_atributo, 'p');//
//   cout <<"\natrb:" <<num_atributo << ", val: " << patrones[patr*total_atributos+num_atributo];//
  incompleta=0; //
  }//
//cin >>a;//
  }//
//
//
for (cont=0; cont<(total_training*(total_atributos-1)); cont++) //
 if (cambiados[cont]==1) //
//  if (marcado[cambiadosexactos[cont]/(total_atributos)]=='t') //
 {//
//  patrones[cambiadosexactos[cont]]=valorescambiados[cont];//
if (tipomissing==3)//
{//
//   patronborrado[cambiadosexactos[cont]/total_atributos]=0;//
  if (marcado[cambiadosexactos[cont]/total_atributos]=='p') //
   cout <<"ERROR";//
//
// cout <<"\npatron:" << cambiadosexactos[cont]/total_atributos <<"pos:" << cont;//
   }//
 } //
//
 if ((tipomissing==1) || (tipomissing==3)) //
 {//
  for (num_atributo=0;num_atributo<total_atributos_entrada;num_atributo++) //
   if (incompletos[num_atributo]==1)//
	if (atributos[num_atributo].tipo_distancia<2) //
{//
	  atributos[num_atributo].total_modalidades=atributos[num_atributo].total_modalidades+1;//
//      cout <<"atributo incompleto: " <<num_atributo << "totmods:" <<atributos[num_atributo].total_modalidades;//
} //
  incompleta=1;//
}//
//  for (num_atributo=0;num_atributo<total_atributos;num_atributo++) //
//      cout <<"atributo: " <<num_atributo << "totmods:" <<atributos[num_atributo].total_modalidades;//
//cout <<"HH"; //
//cout <<"incompletaredes:" <<incompleta;//
}//
/////////////////////////////////////
void red::quitarmissing()//
//Elimina los patrones que tengan alg£n valor desconocido //
{ //
 int patron, num_atributo;//
//tabla1.iniciar(0, taman_fichero, patronborrado); //
// cout <<"HHHHHHHO";//
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==0) //
//   if (((tipo=='p') && (marcado[patron]=='t')) || (tipo=='t'))//
 {//
// if (marcado[patron]=='t') //
//  cout <<"\npatron:" <<patron;//
  for (num_atributo=0; num_atributo<total_atributos_entrada; num_atributo++) //
   if (incompletos[num_atributo]==1)//
   { //
//cout <<"valor: " <<   patrones[patron*total_atributos+num_atributo] <<",atrib:" <<num_atributo; //
	if (((atributos[num_atributo].tipo_distancia<2) &&    //
	  (intervalo(patrones[patron*total_atributos+num_atributo], num_atributo, //
   atributos[num_atributo])==(atributos[num_atributo].total_modalidades-1))) || //
   ((atributos[num_atributo].tipo_distancia==2) && //
   ((float)patrones[patron*total_atributos+num_atributo]==(float)maxreal))) //
   {//
//   if (patron<370)//
  //   cout <<"-patronborrado: " << patron;//
	patronborrado[patron]=1;//
   }//
}//
//cout <<"\n"; //
   }//
//exit(0);//
for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
 if (incompletos[num_atributo]==1) //
 {//
// cout <<"\natributo incompleto:" << num_atributo;//
  incompletos[num_atributo]=0; //
  if (atributos[num_atributo].tipo_distancia<2) //
  atributos[num_atributo].total_modalidades=atributos[num_atributo].total_modalidades-1;//
//  total_modalidades_muestra[num_atributo]=total_modalidades_muestra[num_atributo]-1;//
//  cout <<"total_modalidades: " <<atributos[num_atributo].total_modalidades ;//
 }//
 incompleta=0;//
 taman_ficheromissing=taman_fichero-tabla1.suma(0, taman_fichero, patronborrado);//
 taman_ficheromissingp=0; //
 taman_ficheromissingt=0;  //
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==0) //
   if (marcado[patron]=='p') taman_ficheromissingp=taman_ficheromissingp+1;//
   else taman_ficheromissingt=taman_ficheromissingt+1;//
// cout <<"tamanfichero:" <<taman_fichero << "TAMFICHMISS:" <<taman_ficheromissing;//
 }//
/////////////////////////////////////
void red::quitarmissingorg()//
//Elimina los patrones que tengan alg£n valor desconocido //
{ //
 int patron, num_atributo;//
// tabla1.iniciar(0, taman_fichero, patronborrado); //
// cout <<"HHHHHHHO";//
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==0) //
//   if (((tipo=='p') && (marcado[patron]=='t')) || (tipo=='t'))//
 {//
 //if (marcado[patron]=='t') //
//  cout <<"\npatron:" <<patron;//
  for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
   if (atributos[num_atributo].seleccionado==1)
   if (incompletosorig[num_atributo]==1)//
   { //
//cout <<"valor: " <<   patrones[patron*total_atributos+num_atributo] <<",atrib:" <<num_atributo; //
	if (((atributos[num_atributo].tipo_distancia<2) &&    //
	  (intervalo(patrones[patron*total_atributos+num_atributo], num_atributo, //
   atributos[num_atributo])==atributos[num_atributo].total_modalidades-1)) || //
   ((atributos[num_atributo].tipo_distancia==2) && //
   ((float)patrones[patron*total_atributos+num_atributo]==(float)maxreal))) //
   {//
//   if (patron<370)//
//     cout <<"-patronborrado: " << patron;//
	patronborrado[patron]=1;//
   }//
}//
//cout <<"\n"; //
   }//
//exit(0);//
for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
 if (atributos[num_atributo].seleccionado==1)
 if (incompletosorig[num_atributo]==1) //
 {//
// cout <<"\natributo incompleto:" << num_atributo;//
  incompletosorig[num_atributo]=0; //
  if (atributos[num_atributo].tipo_distancia<2) //
  atributos[num_atributo].total_modalidades=atributos[num_atributo].total_modalidades-1;//
//  total_modalidades_muestra[num_atributo]=total_modalidades_muestra[num_atributo]-1;//
//  cout <<"total_modalidades: " <<atributos[num_atributo].total_modalidades ;//
 }//
 incompletaorg=0;//
 taman_ficheromissing=taman_fichero-tabla1.suma(0, taman_fichero, patronborrado);//
// cout <<"tamanfichero:" <<taman_fichero << "TAMFICHMISS:" <<taman_ficheromissing;//
 }//
/////////////////////////////////////
/*void red::quitarmissingsindiscretizar(void)//
//Elimina los patrones que tengan alg£n valor desconocido//
{ //
 int patron, num_atributo;//
 tabla1.iniciar(0, taman_fichero, patronborrado); //
// cout <<"HHHHHHHO";//
 for (patron=0; patron < taman_fichero; patron++)//
   for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
   if (incompletos[num_atributo]==1) //
	if (((atributos[num_atributo].tipo_distancia<2) &&  //
   (intervalo(patrones[patron*total_atributos+num_atributo], num_atributo, //
   atributos[num_atributo])==atributos[num_atributo].total_modalidades)) || //
   ((atributos[num_atributo].tipo_distancia==2) && (patronest[patron*total_atributos+num_atributo]==(float)maxreal))) //
	   patronborrado[patron]=1;//
 for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
 if (incompletos[num_atributo]==1) //
 {//
  incompletos[num_atributo]=0; //
  if (atributos[num_atributo].tipo_distancia<2) //
  {//
  atributos[num_atributo].total_modalidades=atributos[num_atributo].total_modalidades-1;//
//  total_modalidades_muestra[num_atributo]=total_modalidades_muestra[num_atributo]-1;//
  }//
 }//
 incompleta=0;//
 taman_ficheromissingt=taman_ficherot-tabla1.suma(0, taman_ficherot, patronborrado);//
// cout <<"tamanfichero:" <<taman_fichero << "TAMFICHMISS:" <<taman_ficheromissing;//
 }//
 */ //
/*__________________________________________________________*/

unsigned int red::ObtenerTotalMarcados(char tipo)
{
unsigned int marcados=0;
for (int patron=0; patron < taman_fichero; patron++)//
 if (patronborrado[patron]==0) //
 if (((tipo == 'p') && (marcado[patron]==tipo)) || (tipo =='t'))//
	 marcados++;
return marcados;
}

/////////////////////////////////////
void red::ponerruido(unsigned int tipo)//
//Asigna valores aleatorios a los patrones que tengan alg£n valor desconocido //
{ //
// time_t t;//
// srand((unsigned) time(&t));//
 int patron, num_atributo;//
 tabla1.iniciar(0, taman_fichero, patronborrado); //
// cout <<"HHHHHHHO";//
 for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==0) //
 if (((tipo == 'p')&& (marcado[patron]==tipo)) || (tipo =='t'))//
   for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
   if (patrones[patron*total_atributos+num_atributo]!=(float)maxreal) //
   if ((incompletos[num_atributo]==1) && //
   (intervalo(patrones[patron*total_atributos+num_atributo], num_atributo, atributos[num_atributo])==atributos[num_atributo].total_modalidades)) //
	patrones[patron*total_atributos+num_atributo]=patrones[(rand()%taman_fichero)*total_atributos+num_atributo];//
 for (num_atributo=0; num_atributo<total_atributos; num_atributo++) //
  if (incompletos[num_atributo]==1) //
 {//
  incompletos[num_atributo]=0; //
   atributos[num_atributo].total_modalidades=atributos[num_atributo].total_modalidades-1;//
//  total_modalidades_muestra[num_atributo]=total_modalidades_muestra[num_atributo]-1;//
 }//
 incompleta=0;//
 taman_ficheromissing=taman_fichero;//
// cout <<"tamanfichero:" <<taman_fichero << "TAMFICHMISS:" <<taman_ficheromissing;//
 }//


///////////////////////////////////////////////////////////
unsigned int red::c45(char tipo, char texto[63], char discretizado, short int criterio, bool select)
{//
// discretizado vale '0' si no est� discretizado ya
// para eliminar la poda, quitar l�neas 44 y 237 de besttree.h

//discreto vale 0 si no est  prediscretizado, 1 si s� lo estan
// criterio es 1 si no hay que discretizar porque ya lo est  o son todo atributos discretos,
// si no, tiene el criterio a usar para discretizar
unsigned int coincidentes=0;//
char discreto='0';
char *textot, *textop, *texto2; //, FileName[63];//
short Best;//
if ((textot = new char[63])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);}
;//

if ((texto2 = new char[63])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);}
;//
textot[0]='\0';
texto2[0]='\0';
if (discretizado=='1') //
{//
cadena.cambiar_cadena(texto,  texto2, (char*)"name\0", '.');//
CambiarFicheroNombres(texto2, atributos, total_atributos_entrada);//
}

if (select==true)
{
cadena.cambiar_cadena(texto,  texto2, (char*)"nam2\0", '.');//
CambiarFicheroNombres(texto2, atributos, total_atributos_entrada);//
}

////// Construir arbol//
cadena.cambiar_cadena(texto,  textot, (char*)"ttt", '.');//
creararchivoseleccion ('t', textot, discretizado);//
strncpy (FileName, texto, strchr (texto, '.')-texto);//
FileName[strchr (texto, '.')-texto]='\0'; //
GetNames(FileName, discretizado, select); //
GetData((char*)".ttt");// getdata.h
TRIALS=1;//
OneTree(criterio); //   en besttree.h//
Best=0;//
SaveTree (Pruned[Best], (char*)".tree");//

//////// Evaluar//
if (tipo=='p') //
{ //
 if ((textop = new char[strlen(texto)])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);
 };//

cadena.cambiar_cadena(texto,  textop, (char*)"ppp", '.');//
creararchivoseleccion ('p', textop, discretizado);//

GetData ((char*)".ppp");//

coincidentes=Evaluate (true, Best, salida); //  en BestTree
zap (textop);
} //
else
{
coincidentes=Evaluate (true, Best, salida); //
}

zap (textot);
zap (texto2);

return (coincidentes);//
}//
////////////////////////////////////////////////////
////////////////////////////////
void red::eliminar_repetidos(char texto[63])//
{//
double distancia;  //
unsigned   int encontrado,num_atributo, patron, patron2; //
fichero_salida1.abrir(texto);     //
for (patron=0; patron < taman_fichero; patron++)//
  if (patronborrado[patron]==0) //
{ //
   recuento recuento1(patron, ObtenerDependiente(), taman_fichero, //
						patrones, total_atributos, atributos, 1, 0); //
  encontrado=0; //
  for (patron2=patron+1;patron2<taman_fichero;patron2++)//
  if (patronborrado[patron2]==0) //
  { //
   distancia=recuento1.obtener_distancia(patron, patron2);//
   if ((distancia==0) && (intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])!=//
                                 intervalo(patrones[patron2*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])))//
	 cout <<"error no  coincinden las clases";                            //
   if (distancia==0) encontrado=1;//
  }//
  if (encontrado==0)//
	for (num_atributo=0;num_atributo<total_atributos;num_atributo++) //
	{//
	  if (num_atributo==total_atributos_entrada)//
		fichero_salida1 << patrones[patron*total_atributos+num_atributo] <<"\n";//
	  else      //
		fichero_salida1 << patrones[patron*total_atributos+num_atributo] << " ";//
	   }//
	  }//
	fichero_salida1.close();//
}//
////////////////////////////////
unsigned int red::obtener_distintos(void)//
{//
unsigned int distintos=0, patron, patron2;//
tabla_caracteres.iniciar ('t', taman_fichero, marcado_completo);//
distintos=0; //
for (patron=0; patron < taman_fichero; patron++)//
 if (patronborrado[patron]==0) //
  if (marcado_completo[patron]=='t') //
 {//
  for (patron2=0;patron2<taman_fichero;patron2++)//
   if (patronborrado[patron2]==0) //
	if (comprobar_igual_proyeccion(patron, patron2)==1)  //
	marcado_completo[patron2]='e';    //
  distintos=distintos+1; //
 } //
 return (distintos); //
}//
///////////////////////////////////////////////////////////
unsigned int red::knn(char tipo, unsigned int k, unsigned short int discr)//
{//
unsigned int exactos=0, modalidad, clasemayor, coincidentes=0, empate, patron, patron2;//
double distancia_determinantes;//
//printf("Dep:%d", dependiente);
//char texto[63];//
//recuento *rec1;//
//strcpy(texto, "KNN");//
//fichero_salida1.abrir(texto);//
clasemayor=red::cuentaclase(tipo);//

//
for (patron=0; patron < taman_fichero; patron++)//
 if (patronborrado[patron]==0) //
 if (((tipo == 'p')&& (marcado[patron]==tipo)) || (tipo =='t'))//
 {//
   recuento recuento1(patron, ObtenerDependiente(), taman_fichero, patrones, total_atributos, atributos, k, 0); //
//   para cada patr�n
  for (patron2=0;patron2<taman_fichero;patron2++)//
   if (patronborrado[patron2]==0) //
     if (marcado[patron2]=='t')//
   {//
//cout <<" patron2:" << patron2 << " ";//
		distancia_determinantes=recuento1.obtener_distancia(patron, patron2);//
//
	  //  if (distancia_determinantes ==1) {cout <<"patr:" <<patron2 <<"\n"; cin >> ac;  }//
		recuento1.clasificar_distancia(distancia_determinantes, patron2);//
   }//
	 recuento1.recuento_vecinos_mas_cercanos();//
	 // devuelve modalidad m�s frecuente (modalidad), empate si lo hay, y exactos el n� de patrones iguales
	 exactos=recuento1.obtener_exactos(modalidad, empate);//
	// printf("exactos:%d, empate:%d, modalidad:%d", exactos, empate, modalidad);
   if (exactos != 0)//
	{ //  cout <<"exactos:" << exactos << "  ";//
	if (empate==1) //
	{
       //  cout <<"empate";
       if (red::total_clases()==2)
	 modalidad=clasemayor; //
	 }
        if (modalidad==intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])) //
	 coincidentes=coincidentes+1;//
}//
  if (salida==1)
 {// 
   cout << "Patron " << patron <<": " << atributos[ObtenerDependiente()].modalidad[modalidad]; //
   if (modalidad!=intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])) //
    cout <<". Fallo, valor real: " << atributos[total_atributos_entrada].modalidad[intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])];
   cout << "\n";
   }//
	}//
// porcentaje=(float)coincidentes/(float)total_patrones2*(float)100;//
// cout <<"\n coincidentes:" << coincidentes <<" de " <<total_patrones2;//
//fichero_salida1.close();//
return(coincidentes);//
  }//
//Función que crea , entrena y permite probar la red ADALINE . //
//Devuelve el número de aciertos //
//////////////
//////////////

int   red::METBP ( float TasaAprendizaje, char Tipo, //
				   int CriterioParada, long SenalParada,int NeuronasCapaIntermedia)//
// BackProp
{   //
int  j;
//
srand( (unsigned)time( NULL ) );// Semilla generadora de números aleatorios//
double momentum_term=0.9;      // Momentum Term de la red por defecto//
double ToleranciaError=0.45;   // Tolerancia de error para valor de salida por defecto//
double ErrorAcumulado=0; //
int NumeroCapas=3;    // Número de capas de la red en este caso 3 por defecto//
int NodosEntrada=total_atributos_entrada;     // Número de nodos de la capa de entrada//
int NodosSalida=1;      // Número de nodos de la capa de salida//
int *ContNodos;      // Array que almacena el número de nodos en cada capa//
 //
if ((ContNodos=new int[3])==NULL)
{
cout <<"Falta memoria";
exit(0);}
;//
//
ContNodos[0]=NodosEntrada;//
ContNodos[2]=NodosSalida;//
ContNodos[1]=NeuronasCapaIntermedia;   //
//
Patron **Datos;
if ((Datos=new Patron*[taman_fichero])==NULL)
{
cout <<"falta memoria";
exit(0);
};  // Conjunto de patrones//
//
//
//Cargar patrones del vector Patrones de la red marcados con 't'al vector de patrones Datos//
//
int NPatronEntrenamiento=0;//
//
for (int i=0;i<taman_fichero;i++)//
{//
if (patronborrado[i]==0 && marcado[i]=='t')//
{//
if ((Datos[NPatronEntrenamiento]=new Patron( NodosEntrada,NodosSalida,i, patrones))==NULL)
{
cout <<"Falta memoria";
exit(0);}
;//
NPatronEntrenamiento++;//
}//
}   //
//
//
//
// Crear Red Backpropagation//
RedBackprop REDBP(TasaAprendizaje, momentum_term, NumeroCapas, ContNodos);//
//
// Entrenar la  Red Backpropagation//
long NumPasadas=0;//
int Aciertos=0;//
int Parar=0;//
while (!Parar) // Entrena hasta que se cumpla el criterio de parada//
{//
Aciertos=0;//
//
for (int i=0; i<NPatronEntrenamiento; i++)//
{//
REDBP.TomarValor(Datos[i]);//
// Toma valores de nodos de entrada//
REDBP.Usar();              // Recorrido hacia adelante//
REDBP.TomarError(Datos[i]);//
//Almacena valores salida patrones//
// por cálculo del error//
//
REDBP.Aprender();         // Recorrido hacia atras//
int SalidasAcertadas=0;//
//
//Prueba si la salida de la red está por debajo de  ToleranciaError//
for (j=0; j<NodosSalida; j++)//
{//
if (fabs(REDBP.AsignarValor(j)-Datos[i]//
->Out(j))<ToleranciaError)//
SalidasAcertadas++;//
ErrorAcumulado+=fabs(REDBP.AsignarError(j));//
}//
if (SalidasAcertadas==NodosSalida)//
{//
 Aciertos++;//
// if (Tipo=='t') cout <<"\nacierto atrib: " <<i;//
							  }//
// else cout <<"\nfalo patron: " <<i;//
//
}//
//
NumPasadas++;//
if ((CriterioParada==1 && NumPasadas>=SenalParada) ||//
(CriterioParada==2 && //
(1-(float(Aciertos)/NPatronEntrenamiento))*100<SenalParada)     )//
//
Parar=1;    //
}   // while//
//
zap (Datos);//
 //
if (Tipo=='t')//
return Aciertos;//
else//
{//
//Cargar patrones del vector Patrones de la red marcados con 'p'al vector de patrones Datos//
 //
int NPatronPrueba=0;//
 //
for (int i=0;i<taman_fichero;i++)//
{//
if (patronborrado[i]==0)//
if (((Tipo=='p') && (marcado[i]==Tipo))|| (Tipo=='t'))//
{//
 if ((Datos[NPatronPrueba]=new Patron( NodosEntrada,NodosSalida,i, patrones))==NULL)
 {
 cout <<"Falta memoria";
 exit(0);}
;//
NPatronPrueba++;//
		}//
	}   //
			//
//
	   //
// Probar la Red Backpropagation//
Aciertos=0;//
for(int i=0; i<NPatronPrueba; i++)//
{//
 //
REDBP.TomarValor(Datos[i]);    // Toma valores de los nodos de entrada//
//
 REDBP.Usar();           // Recorrido hacia adelante//
REDBP.TomarError(Datos[i]);//
 int SalidasAcertadas=0;//
//
//Prueba si la salida de la red está por debajo de  ToleranciaError//
for (int j=0; j<NodosSalida; j++)
{//
 if (fabs(REDBP.AsignarValor(j)-Datos[i]->Out(j))<ToleranciaError)//
										SalidasAcertadas++;//
							  ErrorAcumulado+=fabs(REDBP.AsignarError(j));//
					 }//
if (SalidasAcertadas==NodosSalida)//
Aciertos++;//
//
//
//
		  //
				}//
	zap (Datos);//
//
	  return Aciertos;//
	 }//fin else//
				//
}   //
//
//////////
int   red::METADALINE ( float TasaAprendizaje, char Tipo, //
				   int CriterioParada, long SenalParada)//
{   //
int NodosEntrada=total_atributos_entrada; //
int NodosSalida=1;     //
int *ContNodos;      // Array que almacena el número de nodos en cada capa//
 if ((ContNodos=new int[2])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);}
 ;//
ContNodos[0]=total_atributos_entrada;//
ContNodos[1]=1;//
//
NodosSalida=1;//
Patron **Datos;

if ((Datos=new Patron*[taman_fichero])==NULL)
{
cout << "falta memoria";
exit(0);
}; //
//Cargar patrones del vector Patrones de la red marcados con 't'al vector de patrones Datos//
	 int NPatronEntrenamiento=0;//
//cout <<"tasmfich:" <<taman_fichero;      //
for (int i=0;i<taman_fichero;i++)//
{//
if (patronborrado[i]==0) //
if (marcado[i]=='t')//
{//
//   cout <<"\npatron : " <<i; //
if ((Datos[NPatronEntrenamiento]=new Patron( NodosEntrada,NodosSalida,i, patrones))==NULL)
 {
 cout <<"Falta memoria";
 exit(0);}
						;//
//cout <<Datos[NPatronEntrenamiento]->Out(0);//
//Datos[NPatronEntrenamiento]->Imprimir();//
NPatronEntrenamiento++;//
}//
}//
			//
//exit(0);//
//
// Crear Red ADALINE//
RedADALINE RedADA(ContNodos[0],TasaAprendizaje);//
//
// Entrenar la  Red ADALINE//
long NumPasadas=0;//
int Aciertos=0;//
int Parar=0;//
while (!Parar) // Entrena hasta que se cumpla el criterio de parada//
{//
Aciertos=0;//
//
for (int i=0; i<NPatronEntrenamiento; i++)//
{//
RedADA.TomarValor(Datos[i]);//
// Toma valores de nodos de entrada//
RedADA.Usar();              // Uso de la red//
if (Datos[i]->Out(0)!=RedADA.AsignarValor())//
{//
RedADA.Aprender();//
//break;   //??//
}//
else//
{//
Aciertos++;//
// if (Tipo=='t')cout <<"\nacierto patron" << i;//
}//
}//
//
NumPasadas++;//
if ((CriterioParada==1 && NumPasadas>=SenalParada) ||//
(CriterioParada==2 && //
(1-(float(Aciertos)/NPatronEntrenamiento))*100<SenalParada)     )//
//
Parar=1;//
//
}  // fin de while//
//
//        zap (Datos);//
//exit(0); //
if (Tipo=='t') //En esta pasada solo se entrena//
return Aciertos;//
else//
{//
//
//Cargar patrones del vector Patrones de la red marcados con 'p'al vector de patrones Datos//
int NPatronPrueba=0;//
//
for (int i=0;i<taman_fichero;i++)//
{//
if (patronborrado[i]==0) //
if (((Tipo=='p') && (marcado[i]==Tipo))|| (Tipo=='t'))//
{//
if ((Datos[NPatronPrueba]=new Patron( NodosEntrada,NodosSalida,i, patrones))==NULL)
{
cout <<"Falta memoria";
exit(0);}
;//
NPatronPrueba++;//
}//
}   //
//
// Probar  la red  ADALINE//
//
Aciertos=0;//
for (int i=0; i<NPatronPrueba; i++)//
{//
RedADA.TomarValor(Datos[i]);//
// Toma valores de nodos de entrada//
RedADA.Usar();              // Uso de la red//
if (Datos[i]->Out(0)==RedADA.AsignarValor())//
//
Aciertos++;//
}//
//
//
zap (Datos);//
//exit(0);//
return Aciertos;//
}  //fin else de la prueba//
//
}//
////////////////////////////////////////////////////////////
unsigned int red::m1nn(char tipo, unsigned short int disc)//
// algoritmo AH: no es m s que el algoritmo 1nn bien aplicado. Es decir, si t//
//patrones presentan la misma distancia aun siendo t > k, se tienen en cuenta//
//los t patrones//
//la diferencia con el 1nn no se notar  apenas con atributos continuos pero s¡ con los discretos//
{//
//char texto[63], a;//
unsigned int exactos=0, modalidad, empate, clasemayor, coincidentes=0, patron, patron2;//
//unsigned int num_atributo;//
double distancia_determinantes;//
double salto=0;//
double distancia;//
//strcpy (texto, "//home//mmabad//proyecto//BT\0");//
//strcpy (texto, "//vldisks//lsi//disk1//mabad//c//BT\0");//
//fichero_salida1.abrir(texto);//
//char a;//
clasemayor=red::cuentaclase(tipo);//
//salto=(double)1/(double)total_seleccionados; //
if (cualitativos==1) //
salto=1.0; //
else //
//salto=(double)1/((double)maximo_modalidades_ord-(double)1); //
salto=0.125; //          //
salto=sqrt(salto/(double)total_seleccionados);//
// estaba puesto salto=
//salto=salto/sqrt((double)total_seleccionados);
//cout <<"totsel:" << total_seleccionados;
//exit(0);

for (patron=0; patron < taman_fichero; patron++)//
if (patronborrado[patron]==0) //
 if (((tipo == 'p')&& (marcado[patron]==tipo)) || (tipo =='t'))//
 {//
  distancia=salto; //
//  cout <<"patron1: " <<patron;

  do //
   {//
   recuento recuento1(patron, ObtenerDependiente(), taman_fichero, //
	       patrones, total_atributos, atributos, 0, 0); //
   for (patron2=0;patron2<taman_fichero;patron2++)//
    if (patronborrado[patron2]==0) //
     if (marcado[patron2]=='t')//
     {    //
//     cout <<"\npatron2:" << patron2;
      distancia_determinantes=recuento1.obtener_distancia_saltos(patron, patron2);//
//cout <<"\ndistdet:" <<distancia_determinantes <<"versus distancia:" << distancia;
      if (distancia_determinantes<=distancia)//
     {
//  cout <<"\npatron2 " << patron2 << "distaigual al patron1 " << patron;
	    recuento1.recuento_resto_patrones(patron2);//
//       cout <<"elegido con dist:" << distancia_determinantes;
//cout <<",atrib: 0 ,p1: " << patrones[patron*total_atributos+0]
//<<",p2:" <<patrones[patron2*total_atributos+0];
//cout <<",atrib: 1 ,p1: " << patrones[patron*total_atributos+1]
//<<",p2:" <<patrones[patron2*total_atributos+1];
       }
     } //

   exactos=recuento1.obtener_exactos(modalidad, empate);//
 //empate=0; 
 //modalidad=0;
 //if (clasemayor>1) {cout <<"error"; exit(0);}
   if (exactos != 0) //
   { //
 //  cout <<"exac:" << exactos; 
   if (empate==1)  //
   {
    modalidad=clasemayor; //
//    cout << "empate";
    }
  //  cout <<"mod:" << modalidad << " , int:" <<intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()]);
     if (modalidad==intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])) //
     coincidentes=coincidentes+1;//
//    coincidentes=0; 
   }//
   distancia=distancia+salto;//
  }//
 // while ((distancia<=(total_atributos-1))&& (exactos == 0)); //
while ((distancia<=1) && (exactos == 0)); //

//  fichero_salida1 << atributos[total_atributos_entrada].modalidad[modalidad] << "\n"; //
  if (salida==1)
 {// 
   cout << "Patron " << patron <<": " << atributos[total_atributos_entrada].modalidad[modalidad]; //
   if (modalidad!=intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])) //
    cout <<". Fallo, valor real: " << atributos[total_atributos_entrada].modalidad[intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])];
   cout << "\n";
   }//
  if (modalidad>1) fichero_salida1 << "error";//
//  exit(0);
}//
// fichero_salida1.close();//
 return(coincidentes);//
 }//
//////////////////
void red::obtenerintervalos(unsigned int *bases, //
unsigned int *indices, unsigned   int //
*dimensiones_condicionantes, unsigned int * pads, unsigned   int condicionado, //
unsigned int patron, int *nmax, int *nmin, //
struct frecuencia *total_condicionantes, int total_distribuciones, //
unsigned int *topedesbordamiento, char tipo, unsigned int tamanfrecs, unsigned int tamanfrecsampliado) //
{//
enteros enter;
int mod_condicionantes, lugar;//
unsigned int *swap, *binario, rechazado; //
int variaciones;//
if ((swap=new unsigned int [*padres])==NULL)
{
cout <<"falta memoria";
exit(0);
}; 
if ((binario=new unsigned int [*padres])==NULL)
{
cout <<"falta memoria";
exit(0);
}; 
mod_condicionantes=tabla1.obtener_posicion (indices, dimensiones_condicionantes,//
*padres); //
//calcula n(?/padres)//
lugar=red::obtenerlugar(total_condicionantes, mod_condicionantes, total_distribuciones, topedesbordamiento, condicionado, bases, tipo,
tamanfrecs, tamanfrecsampliado); //
//cout <<"D";//
//cout <<"atrib:::" <<condicionado;//
if (incompletos[condicionado]==1) //
*nmax=bases[atributos[condicionado].total_modalidades*lugar+//
atributos[condicionado].total_modalidades-1];//
//intervalo(patrones[patron*total_atributos+ //
//(atributos[condicionado].total_modalidades-1)], //
//condicionado, atributos[condicionado])]; //
//intervalo(patrones[patron*total_atributos+ //
//condicionado], //
//condicionado, atributos[condicionado])]; //
//exit(0);//
//calcula n(?/?), n(x/?) y n(padres?)//
variaciones=(int)pow((double)2, (int)*padres);//
for (int i=1; i <= variaciones; i++)//
{//
 rechazado=1; //
 enter.calcularbinario (i, binario, *padres);//
 tabla1.iniciar (0, *padres, swap);//
 for (int i2=0; i2<*padres;i2++) //
  if (binario[i2]==1) //
   if (incompletos[padres[i2+1]]==1) //
   {//
   swap[i2]=indices[i2];//
   indices[i2]=atributos[padres[i2+1]].total_modalidades-1;//
   rechazado=0; //
   }//
 if (rechazado==0) //
 { //
 mod_condicionantes=tabla1.obtener_posicion (indices, dimensiones_condicionantes, *padres);//
 lugar=red::obtenerlugar(total_condicionantes, mod_condicionantes, total_distribuciones, topedesbordamiento, condicionado, bases, tipo,
 tamanfrecs, tamanfrecsampliado); //
//cout <<"S";//
 //calcula n(?/?)//
// *nmax=*nmax+bases[atributos[condicionado].total_modalidades*lugar+//
// intervalo(patrones[patron*total_atributos+(atributos[condicionado].total_modalidades-1)],//
//  condicionado, atributos[condicionado])];//
// *nmin=*nmax+bases[atributos[condicionado].total_modalidades*lugar+//
// intervalo(patrones[patron*total_atributos+(atributos[condicionado].total_modalidades-1)], //
//  condicionado, atributos[condicionado])];//
// *nmax=*nmax+bases[atributos[condicionado].total_modalidades*lugar+//
// intervalo(patrones[patron*total_atributos+condicionado],//
//  condicionado, atributos[condicionado])];//
// *nmin=*nmax+bases[atributos[condicionado].total_modalidades*lugar+//
// intervalo(patrones[patron*total_atributos+condicionado], //
//  condicionado, atributos[condicionado])];//
if (incompletos[condicionado]==1) //
{//
 *nmax=*nmax+bases[atributos[condicionado].total_modalidades*lugar+//
 atributos[condicionado].total_modalidades-1];//
  *nmin=*nmax+bases[atributos[condicionado].total_modalidades*lugar+//
 atributos[condicionado].total_modalidades-1];//
}//
 //calcula n(x/?)//
 *nmax=*nmax+bases[atributos[condicionado].total_modalidades*lugar+//
 intervalo(patrones[patron*total_atributos+condicionado], condicionado, //
 atributos[condicionado])];//
   //calcula n(y<>x/?)//
 for (int i2=0; i2<(atributos[condicionado].total_modalidades-1); i2++) //
  if (i2!=intervalo(patrones[patron*total_atributos+condicionado], condicionado, atributos[condicionado]))//
   *nmin=*nmin+bases[atributos[condicionado].total_modalidades*lugar+i2];//
 for (int i2=0; i2<*padres;i2++) //
  if (binario[i2]==1) //
   if (incompletos[padres[i2+1]]==1)//
   indices[i2]=swap[i2];//
  }//
 }//
zap (binario);
zap (swap);
}//
/////////   //
unsigned int red::obtenerlugar (struct frecuencia *frecs,  //
int mod_condicionante, int total_distribuciones, //
unsigned int *topedesbordamiento, unsigned int condicionado, unsigned //
int *bases, char tipo, unsigned int tamanfrecs, unsigned int tamanfrecsampliado) //
{//
unsigned int total_modalidades;
unsigned int desplazamiento, encontrado=0, nuevo=0, i2, total;//, ampliado=1;//
long int lugar;//
//cout <<"\nMod_cond: " <<mod_condicionante;//
if (tipo=='p') total=taman_ficheromissingt;//
else total=taman_ficheromissing;//
/*if (total_distribuciones>total) //
if 
tamanfrecs=total;//
else tamanfrecs=total_distribuciones;////
if (total_distribuciones>total) //

tamanfrecsampliado=tamanfrecs*tamanfrecs;//
*/
//cout << "TFA:" << tamanfrecsampliado; //
//cout << "TF:" << tamanfrecs; //
lugar=mod_condicionante%tamanfrecs;//
desplazamiento=tamanfrecs;//
//cout <<"topedesb:" <<*topedesbordamiento;//
if ((*(frecs+lugar)).posicion==mod_condicionante) //
 encontrado=1; //
 else //
  {//
 if ((*(frecs+lugar)).condicionante==-1) //
  nuevo=1; //
 else //
 if (tabla1.desborde(tamanfrecsampliado, desplazamiento)==0)//
  {//
	do //
	{//
	if ((*(frecs+desplazamiento)).posicion==mod_condicionante) //
		 {//  //
		  lugar=desplazamiento; //
		  encontrado=1;//
		 }//
	 else desplazamiento=desplazamiento+1;//
	 }//
	 while (((*(frecs+desplazamiento-1)).posicion!=mod_condicionante) && //
		 (desplazamiento<*topedesbordamiento) && (encontrado==0)); //
   //      if (desplazamiento==tamanfrecsampliado)  //
//          {cout << "tabla1.desbordamiento en bayes"; exit(0);}//
   }//
  }//
if (encontrado==0) //
{//
// cout <<"ERROR no encontrado" <<"pos: " <<mod_condicionante;//
//unsigned int total_modalidades;//
total_modalidades=atributos[condicionado].total_modalidades;//
if (incompletos[condicionado]==1) //
total_modalidades=total_modalidades-1;//
if (nuevo==0) // posicion ocpada por otro, a�adir al final
{//
// cout <<"NUEVO";//
 lugar=*topedesbordamiento;//
 if (tabla1.desborde(tamanfrecsampliado,lugar)==1) //
  {//
  cout <<"lugar:" <<lugar <<"tamanfrecs:" << tamanfrecsampliado;//
  cout <<"ERROR DESB";//
  exit(0);//
   }//
 *topedesbordamiento=*topedesbordamiento+1;//
};//
 (*(frecs+lugar)).posicion=mod_condicionante;//
 (*(frecs+lugar)).condicionante=total_modalidades;//
 for (int i2=0; i2 < total_modalidades; i2++) //
  bases[total_modalidades*lugar+i2]=1;////
 }//
// if (encontrado==1) cout <<"enc:"; else cout << "nonec";
return(lugar);  //
}//
////////////////////
/////////   //
/*
unsigned int red::obtenerlugarmayo2003 (struct frecuencia *frecs,  //
int mod_condicionante, int total_distribuciones, //
unsigned int *topedesbordamiento, unsigned int condicionado, unsigned //
int *bases, char tipo) //
{//
unsigned int desplazamiento, encontrado=0, nuevo=0, i2, total;//, ampliado=1;//
long int lugar;//
//cout <<"\nMod_cond: " <<mod_condicionante;//
if (tipo=='p') total=taman_ficheromissingt;//
else total=taman_ficheromissing;//
if (total_distribuciones>total) //
tamanfrecs=total;//
else tamanfrecs=total_distribuciones;////
tamanfrecsampliado=tamanfrecs*8;//
//cout << "TFA:" << tamanfrecsampliado; //
//cout << "TF:" << tamanfrecs; //
lugar=mod_condicionante%tamanfrecs;//
desplazamiento=tamanfrecs;//
//cout <<"topedesb:" <<*topedesbordamiento;//
if ((*(frecs+lugar)).posicion==mod_condicionante) //
 encontrado=1; //
 else //
  {//
 if ((*(frecs+lugar)).condicionante==-1) //
  nuevo=1; //
 else //
 if (tabla1.desborde(tamanfrecsampliado, desplazamiento)==0)//
  {//
	do //
	{//
	if ((*(frecs+desplazamiento)).posicion==mod_condicionante) //
		 {//  //
		  lugar=desplazamiento; //
		  encontrado=1;//
		 }//
	 else desplazamiento=desplazamiento+1;//
	 }//
	 while (((*(frecs+desplazamiento-1)).posicion!=mod_condicionante) && //
		 (desplazamiento<*topedesbordamiento) && (encontrado==0)); //
   //      if (desplazamiento==tamanfrecsampliado)  //
//          {cout << "tabla1.desbordamiento en bayes"; exit(0);}//
   }//
  }//
if (encontrado==0) //
{//
// cout <<"ERROR no encontrado" <<"pos: " <<mod_condicionante;//
//unsigned int total_modalidades;//
//total_modalidades=atributos[condicionado].total_modalidades;//
//if (incompletos[condicionado]==1) //
//total_modalidades=total_modalidades-1;//
// (*(frecs+lugar)).condicionante=0;//
// for (i2=0; i2 < total_modalidades; i2++) //
//  bases[total_modalidades*lugar+i2]=0;////
 }//
 return(lugar);  //
}//
*/
///////////////////////////////////////////////
void red::LeerFrecuencias(
char tipo,
unsigned int *topedesbordamiento,
unsigned int **dimensiones_condicionantes,
unsigned int **bases,
int *total_distribuciones,
int *total_distribuciones_condicionantes,
struct frecuencia **total_condicionantes,
unsigned int *tf,
unsigned int *tfa,
unsigned int *tp)
{

unsigned int coincidentes=0, *condicionantes;//
unsigned int total; //
unsigned int condicionante;//

if (tipo=='t') total=taman_ficheromissing; //
else total=taman_ficheromissingt; //


//////////////////////////// copia frecuencias de la clase //////////////////
frecuencias *objetofrecuencia; // 
if ((objetofrecuencia = new frecuencias((unsigned int)1, &dependiente, (unsigned int)0, NULL, patrones, marcado, patronborrado, tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL) exit(0);

//////////////////////////////////////////////////////////////////////////////////////
/////////////////////// reserva memoria para /////////////////////////////////////////
////// dimensiones_condicionantes[dependiente], bases[dependiente], ////////////////// 
////// y total_condicionantes[dependiente] ///////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

if ((dimensiones_condicionantes[ObtenerDependiente()]=new unsigned int[1])==NULL) exit(0);//

if ((bases[ObtenerDependiente()]=new unsigned int [atributos[ObtenerDependiente()].total_modalidades*objetofrecuencia->tamanfrecsampliado])==NULL) exit(0);//

if ((total_condicionantes[ObtenerDependiente()]=new struct frecuencia[objetofrecuencia->tamanfrecsampliado])==NULL) exit(0);

//////////////// asigna valores a la clase a partir de las frecuencias /////////////////

for (int cont=0; cont<objetofrecuencia->tamanfrecsampliado;cont++) //
{//
comprobar (total_condicionantes[ObtenerDependiente()], cont, objetofrecuencia->tamanfrecsampliado, "b1");
total_condicionantes[ObtenerDependiente()][cont].posicion=(*(objetofrecuencia->frecs+0)).posicion;//
total_condicionantes[ObtenerDependiente()][cont].condicionante=(*(objetofrecuencia->frecs+0)).condicionante;//
}//
comprobar (dimensiones_condicionantes, ObtenerDependiente(), total_atributos, "b2");
comprobar (objetofrecuencia->dimensiones_condicionantes, 0, 1, "b3");
dimensiones_condicionantes[ObtenerDependiente()][0]=objetofrecuencia->dimensiones_condicionantes[0];//
//la clase no tiene dimensiones condicionantes//
comprobar (total_distribuciones, ObtenerDependiente(), total_atributos, "b4");
total_distribuciones[ObtenerDependiente()]=objetofrecuencia->total_distribuciones;//

for(int cont=0; cont< objetofrecuencia->tamanfrecsampliado; cont++) //
{
comprobar (atributos, ObtenerDependiente(), total_atributos, "b5");
for (int cont2=0; cont2<atributos[ObtenerDependiente()].total_modalidades;cont2++) //
{//
comprobar (bases[ObtenerDependiente()], atributos[ObtenerDependiente()].total_modalidades*cont+cont2, 
atributos[ObtenerDependiente()].total_modalidades*objetofrecuencia->tamanfrecsampliado, "b6");
comprobar (objetofrecuencia->base, cont*atributos[ObtenerDependiente()].total_modalidades+cont2, objetofrecuencia->tamanfrecsampliado*objetofrecuencia->total_distribuciones_primeros, "b7");
bases[ObtenerDependiente()][atributos[ObtenerDependiente()].total_modalidades*cont+cont2]=objetofrecuencia->base[cont* //
atributos[ObtenerDependiente()].total_modalidades+cont2];//
}//
}

 zap (objetofrecuencia);

//////////////////////////////////////////////////////////////////////////////////////
/////////////////// lee frecuencias para cada atributo de entrada seleccionado ///////
//////////////////////////////////////////////////////////////////////////////////////

for(unsigned int i=0;i<total_atributos;i++)// para cada atributo de entrada seleccionado//
 if (i!=ObtenerDependiente())//
 {
 comprobar (atributos, i, total_atributos, "b8");
 if (atributos[i].seleccionado==1)//
 {//
 comprobar (padres, i*(total_atributos+1), total_atributos_entrada*(total_atributos_entrada+2), "b9");
 condicionante=padres[i*(total_atributos+1)];// guarda el n£mero de padresde cada atributo de entrada, incluyendo a la clase//
 if (condicionante!=0)//  si hay alg£n padre, los guarda en condicionantes//
 {//
 if ((condicionantes=new unsigned int[condicionante])==NULL) exit(0);//
 int i3=0;//
 for (int i2=0; i2< (total_atributos); i2++)//
 { //
  comprobar (atributos, i2, total_atributos, "b10");
  comprobar (padres, i*(total_atributos+1)+(i2+1), total_atributos_entrada*(total_atributos_entrada+2), "b11");
  if (atributos[i2].seleccionado==1)//
   if (padres[i*(total_atributos+1)+(i2+1)]==1)//
   {//
    comprobar (condicionantes, i3, condicionante, "b12");
    condicionantes[i3]=i2;//
    i3=i3+1;//
   }//
}// fin for//
}// fin si tiene padres//

if ((objetofrecuencia= new frecuencias((unsigned int)1, &i, condicionante,condicionantes, patrones, marcado, patronborrado, tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL) exit(0);

if (condicionante!=0)//  si hay alg£n padre, guarda el total de dimensiones de cada atributo padre en dimensiones_condicionantes[i]//
{
zap(condicionantes);
if ((dimensiones_condicionantes[i]=new unsigned int[condicionante])==NULL) exit(0);

for (int cont=0; cont<condicionante; cont++)
{ 
comprobar (dimensiones_condicionantes[i], cont, condicionante, "b13");
comprobar (objetofrecuencia->dimensiones_condicionantes, cont, condicionante, "b14");
dimensiones_condicionantes[i][cont]=objetofrecuencia->dimensiones_condicionantes[cont];//
}
}

tf[i]=objetofrecuencia->tamanfrecs;
tfa[i]=objetofrecuencia->tamanfrecsampliado;
tp[i]=objetofrecuencia->total_distribuciones_primeros;



comprobar (topedesbordamiento, i, total_atributos-1, "b20");
topedesbordamiento[i]=objetofrecuencia->topedesbordamiento;//
comprobar (total_distribuciones_condicionantes, i, total_atributos-1, "b21");
total_distribuciones_condicionantes[i]=objetofrecuencia->obtener_total_distribuciones_condicionantes();//
comprobar (total_distribuciones, i, total_atributos, "b22");
total_distribuciones[i]=objetofrecuencia->total_distribuciones;//


if ((total_condicionantes[i]=new struct frecuencia[objetofrecuencia->tamanfrecsampliado])==NULL) exit(0);
if ((bases[i]=new unsigned int[objetofrecuencia->tamanfrecsampliado*objetofrecuencia->total_distribuciones_primeros])==NULL) exit(0);

for(int i2=0; i2< objetofrecuencia->tamanfrecsampliado; i2++) //
{//
comprobar (total_condicionantes[i], i2, objetofrecuencia->tamanfrecsampliado, "b15");
comprobar (objetofrecuencia->frecs, i2, objetofrecuencia->tamanfrecsampliado, "b16");
total_condicionantes[i][i2].posicion=(*(objetofrecuencia->frecs+i2)).posicion;//
total_condicionantes[i][i2].condicionante=(*(objetofrecuencia->frecs+i2)).condicionante;//
for (int i3=0; i3<objetofrecuencia->total_distribuciones_primeros; i3++) //
{//
 comprobar (objetofrecuencia->total_distribuciones_primeros, i3, atributos[i].total_modalidades, "b16");
 comprobar (bases[i], i2*objetofrecuencia->total_distribuciones_primeros+i3, objetofrecuencia->tamanfrecsampliado*objetofrecuencia->total_distribuciones_primeros, "b18");
 comprobar (objetofrecuencia->base, i2*objetofrecuencia->total_distribuciones_primeros+i3, objetofrecuencia->tamanfrecsampliado*objetofrecuencia->total_distribuciones_primeros, "b19");
 bases[i][i2*objetofrecuencia->total_distribuciones_primeros+i3]=objetofrecuencia->base[i2*objetofrecuencia->total_distribuciones_primeros+i3];//
}//
}//
zap (objetofrecuencia);
} // fin si esta seleccionado
}//fin para cada atributo
}
/////////////
unsigned int red::ContarAciertosBayes(
char tipo, 
bool bayesiano,
bool convex,
unsigned int *topedesbordamiento,
unsigned int **dimensiones_condicionantes,
unsigned int **bases,
int *total_distribuciones,
int *total_distribuciones_condicionantes,
struct frecuencia **total_condicionantes,
unsigned int *tf,
unsigned int *tp,
unsigned int *tfa)

{
unsigned int total_clases, nx, inc, total, marginal, coincidentes=0;//
double alpha, alphaj;

if (tipo=='t') total=taman_ficheromissing; //
else total=taman_ficheromissingt; //



total_clases=red::total_clases();//
//cout <<"TC:" <<total_clases;
 double *probclase, *probclasemax, *probclasemin, *pmin, *pmax;
 double **probmax, **probmin, probmaxtot=0.0, probmintot=0.0; //

if ((probclase = new double[total_clases])==NULL) exit(0);//
if ((probclasemax = new double[total_clases])==NULL) exit(0);//
if ((probclasemin = new double[total_clases])==NULL) exit(0);//
//if ((pmaxtemp = new double[total_clases])==NULL) exit(0);//
if ((pmax = new double[total_clases])==NULL) exit(0);//
if ((pmin = new double[total_clases])==NULL) exit(0);//

if ((probmax = new double*[total_clases])==NULL) exit(0);//
if ((probmin = new double*[total_clases])==NULL) exit(0);//


for (int numclas=0; numclas<total_clases; numclas++) //
 {//
  if ((probmax[numclas] = new double[total_atributos])==NULL) exit(0);//  -1
  if ((probmin[numclas] = new double[total_atributos])==NULL) exit(0);//  -1
 }//

//cout <<"totalc:" << total_clases << ", totalatrb:" << total_atributos;

if ((!bayesiano) || (convex)) alpha=0.0; //
 else if (!convex) alpha=5.0;//
comprobar (incompletos, ObtenerDependiente(), total_atributos, "s1");
comprobar (bases, ObtenerDependiente(), total_atributos, "s2");
if (incompletos[ObtenerDependiente()])//
 nx=bases[ObtenerDependiente()][total_clases]; //
else nx=0;
if (convex) nx=nx+1;//
// pra wue sirve?






unsigned int clase_elegida;



for (int patron=0; patron < taman_fichero; patron++)//
 if (patronborrado[patron]==0) //
 if (((tipo == 'p') && (marcado[patron]==tipo)) || (tipo =='t'))//
 {
  tabla1.iniciar(1.0, total_clases, probclase);//
  tabla1.iniciar(1.0, total_clases, pmin);//
  tabla1.iniciar(1.0, total_clases, pmax);//
 
  for (int numclas=0; numclas<total_clases; numclas++) //
  {
   tabla1.iniciar(1.0, total_atributos, probmin[numclas]);//
   tabla1.iniciar(1.0, total_atributos, probmax[numclas]);//
  }
  //

 
////////////////////
///para cada clase
//////////////////////
 
  unsigned int *indices, i3;
  long int lugar, mod_condicionantes;//
  int nmin, nmax;

  for(int numclas=0; numclas<total_clases; numclas++)//
  {//
 //Calcula la p(k)//
   comprobar (probclasemax, numclas, total_clases, "s4");
   probclasemax[numclas]=((double)bases[ObtenerDependiente()][numclas]+((double)alpha/(double)total_clases)+(double)nx)/((double)total+(double)alpha+(double)nx); //
   if (incompletos[ObtenerDependiente()]) probclasemax[numclas]=probclasemax[numclas]*((double)bases[ObtenerDependiente()][numclas]/(double)total); 
   comprobar (probclasemin, numclas, total_clases, "s6");
   probclasemin[numclas]=((double)1-((double)bases[ObtenerDependiente()][numclas]/(double)total))*((double)bases[ObtenerDependiente()][numclas]+((double)alpha/(double)total_clases)) /((double)total+(double)alpha+(double)nx); ////    probclasemin[numclas]=//
   inc=0;//
   for (int i=0; i < total_atributos; i++)//
    if (i!=ObtenerDependiente())
    if (atributos[i].seleccionado==1)//
	{//
     inc=0;
	 nmax=0;//
	 nmin=0;//
	 if (incompletos[i]==1) inc=1; //
     comprobar (padres, i*(total_atributos+1), (total_atributos+2)*(total_atributos-1), "s8");
	 if (padres[i*(total_atributos+1)]!=0) //  si tiene padres//
	 {//
      if ((indices=new unsigned int[padres[i*(total_atributos+1)]])==NULL) exit(0);
      //guarda los valores de los padres, incluida la clase, del ejemplo dado//
      tabla1.iniciar(0, padres[i*(total_atributos+1)], indices);//
      i3=0;//
      for (int i2=0; i2 < total_atributos; i2++)//
       if (atributos[i2].seleccionado==1)//
		{//
	 comprobar (padres, i*(total_atributos+1)+(i2+1), (total_atributos+2)*(total_atributos-1), "s8");
		 if (padres[i*(total_atributos+1)+(i2+1)]==1)// si i2 es un padre//
		 {//
		 if (incompletos[i2]==1) inc=1;//
                  if (i2!=ObtenerDependiente())// si no se trata de la clase//
		   indices[i3]=intervalo(patrones[patron*total_atributos+i2], i2, //
			atributos[i2]);//
		  else  indices[i3]=numclas;// si es la clase//
		  i3=i3+1;//
		 }//
		}//

	 mod_condicionantes=tabla1.obtener_posicion(indices,dimensiones_condicionantes[i],padres[i*(total_atributos+1)]);//

	 lugar=red::obtenerlugar(total_condicionantes[i], mod_condicionantes,total_distribuciones[i], &(topedesbordamiento[i]), i,bases[i], tipo, tf[i], tfa[i]); //      //obtiene la configuraci¢n condicionante dentro de la tabla//
	  //dimensiones_condicionantes que corresponde con el ejemplo dado//
	  if (inc==1) //
	   {//
		red::obtenerintervalos(bases[i], indices,dimensiones_condicionantes[i], padres+(i*(total_atributos+1)),i, patron, &nmax, &nmin, total_condicionantes[i], total_distribuciones[i], &(topedesbordamiento[i]), tipo, tf[i], tfa[i]);//
		// nmax guarda el n§ de ejemplos cuyas modalidades del atributo //
		//     condicionado//
		//y de sus padres coinciden con las del ejemplo dado pero con al menos alguno//
		// de ellos desconocido//
		//si no hay padres, nmax=nmin y es n(?)//
	    }

       zap(indices);//
	  }// fin tiene padres//
	  else //caso sin padres//
	  {//
	   lugar=0;//
	   if (inc==1) //
	   {//
		nmax=bases[i][atributos[i].total_modalidades-1]; //
		nmin=nmax;//
	   }//
	  }//
/////exit(0);//


	 if (convex) 
	 {
	  nmax=nmax+1;
// valor s
	  nmin=nmax;
	  alphaj=0.0;
	  alpha=0;
	 }
	 if (!bayesiano) alphaj=0.0;//
	 else // si bayesiano//
	 { //
	  marginal=0;//
	  for (int contador=0; contador < topedesbordamiento[i]; contador++) //
	   marginal=marginal+bases[i][contador*atributos[i].total_modalidades+intervalo(patrones[patron*total_atributos+i], i, atributos[i])];//
	 alphaj=(double)alpha*(double)marginal/(double)total;//
	 }// fin bayesiano//

	 if ((double)((total_condicionantes[i][lugar]).condicionante+alpha+nmax)!=(double)0)//calcula prob condicionada por los padres//
	 {
	  probmax[numclas][i]=((double)bases[i][atributos[i].total_modalidades*lugar+intervalo(patrones[patron*total_atributos+i], i, atributos[i])]+(double)alphaj+(double)nmax)/((double)(total_condicionantes[i][lugar]).condicionante+(double)alpha+(double)nmax);//
//     printf("\nprobmax atrib %d clase %d: .4%f", i, numclas+1, probmax[numclas][i]);
	  // para funciones complejas (al menos un atributo padre ademas de la clase)
     // si la frecuencia es 0 se aproxima mediante la marginal dividida entre 2
     if (padres[i*(total_atributos+1)]>1)
      if (probmax[numclas][i]==0.0) probmax[numclas][i]=(double)1/(2*((total_condicionantes[i][lugar]).condicionante+(double)alpha+nmax));
	 }
     else probmax[numclas][i]=0.0;// poniendo 1.0 es como ignorar ese atributo pero los resultados son peores
						
//if (probmax[numclas]==NULL) exit(0);
//else//
 {//
 comprobar (total_condicionantes[i], lugar, tfa[i], "b12b");
 comprobar (probmin[numclas], i, total_atributos-1, "b13");
 comprobar (bases[i], atributos[i].total_modalidades*lugar+intervalo(patrones[patron*total_atributos+i], i, atributos[i]),tp[i]*tfa[i], "b14");
 if ((double)((total_condicionantes[i][lugar]).condicionante+alpha+nmin)!=(double)0)//calcula prob condicionada por los padres//
 {
 probmin[numclas][i]=((double)bases[i][atributos[i].total_modalidades*lugar+intervalo(patrones[patron*total_atributos+i], i, atributos[i])]+(double)alphaj)/((double)(total_condicionantes[i][lugar]).condicionante+(double)alpha+(double)nmin);//
 if (probmin[numclas][i]==0) probmin[numclas][i]=(double)1/(2*((total_condicionantes[i][lugar]).condicionante+alpha+nmin));
 }
 else probmin[numclas][i]=0.0; 
}// fin clases//

}// fin atributos seleccionados//


}// fin clases//


 for (int numclas=0; numclas< total_clases; numclas++) //
  if (incompleta==0) //
 {//
  probclase[numclas]=probclasemax[numclas];//
  // printf("probclase %d: %.4f", numclas+1, probclase[numclas]);
  for (int i=0; i< (total_atributos-1); i++) //
   if (atributos[i].seleccionado==1) //
   {//
	  probclase[numclas]=probclase[numclas]*probmax[numclas][i];//
   }//
   // printf("\nprobclase %d: %.4f", numclas+1, probclase[numclas]);
 }//
 else //
  {//
  // este bucle para mi mtodo (y quitando el anterior if incompleta)//
  for (int i=0; i< (total_atributos-1); i++) //
   if (atributos[i].seleccionado==1) //
   {//
   probclasemax[numclas]=probclasemax[numclas]*probmax[numclas][i];//
   // lo quito porque da default error 
   probclasemin[numclas]=probclasemin[numclas]*probmin[numclas][i];//
   }//
  probclase[numclas]=probclasemax[numclas];//
  }//

if (incompleta==1) //
{//
 for (int numclas=0; numclas< total_clases; numclas++) //
 {//
  probmintot=probmintot+probclasemin[numclas];//
  probmaxtot=probmaxtot+probclasemax[numclas];//
 }//
 for (int numclas=0; numclas< total_clases; numclas++) //
 {//
  probclasemax[numclas]=probclasemax[numclas]/probmaxtot;//
  probclasemin[numclas]=probclasemin[numclas]/probmintot;//
  probclase[numclas]=probclasemax[numclas];//
 }// 
}//
 
 if (tabla1.empatemaximo(total_clases, probclase)==1) clase_elegida=tabla1.maximo(total_clases, bases[ObtenerDependiente()]);//
 else clase_elegida=tabla1.maximo(total_clases, probclase);//
 if (clase_elegida==intervalo(patrones[patron*total_atributos+ObtenerDependiente()],ObtenerDependiente(), atributos[ObtenerDependiente()])) 
  coincidentes=coincidentes+1;//
  if (salida==1)
  {// 
   cout << "Patron " << patron <<": " << atributos[total_atributos_entrada].modalidad[clase_elegida]; //   if (modalidad!=intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])) //
   if (clase_elegida!=intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])) //
    cout <<". Fallo, valor real: " << atributos[total_atributos_entrada].modalidad[intervalo(patrones[patron*total_atributos+ObtenerDependiente()], ObtenerDependiente(), atributos[ObtenerDependiente()])];
  // cout <<"valor atrib 0: " << patrones[patron*total_atributos];
   cout << "\n";
  }//

}// fin patrones//


//cout <<"ttotcla:" << total_clases;

for (int numclas=0; numclas<total_clases;numclas++)//
{//
 zap(probmax[numclas]);//
 zap(probmin[numclas]);//
}//

zap (probmax);//
zap (probmin);//


zap (probclase); //

zap (probclasemax);//
zap (probclasemin);//

zap (pmax);//
zap (pmin);//

return(coincidentes);
}
/////////////
unsigned int red::bayes(char tipo, bool bayesiano, bool convex=false)//
// tipo es el tipo de algoritmo (NB, TAN, SAN, ...)
// bayesiano true si se aplica Bayes theorem
// convex=true si conjuntos convexos (intervalos de probabilidad),  
// Algoritmo basado en el paradigma de la muestra//
// devuelve el n�mero de aciertos (en coincidentes)
{
//////////////////////////////////////////////////////////////////////////////////////
/////////////////////// declara y reserva memoria para /////////////////////////////////////////
////// topedesbordamiento, dimensiones_condicionantes, bases, total_distribuciones, //
////// total_distribuciones_condicionantes, total_condicionantes /////////////////////
//////////////////////////////////////////////////////////////////////////////////////

unsigned int *topedesbordamiento, **dimensiones_condicionantes, **bases;  //
int *total_distribuciones, *total_distribuciones_condicionantes; //
struct frecuencia **total_condicionantes;   //


if ((topedesbordamiento=new unsigned int[total_atributos])==NULL) exit(0);//-1

//guarda cada una de las modalidades de cada atributo de su conjunto de padres//
if ((dimensiones_condicionantes=new unsigned int*[total_atributos])==NULL) exit(0);//

if ((bases=new unsigned int*[total_atributos])==NULL) exit(0);//

if ((total_distribuciones=new int[total_atributos])==NULL) exit(0);//-1

//guarda para cada atributo el total de configuraciones del conjunto de padres//
if ((total_distribuciones_condicionantes=new int[total_atributos])==NULL) exit(0);//-1

//guarda para cada atributo las frecuencias absolutas de cada configuraci¢n de su conjunto de padres//
if ((total_condicionantes=new struct frecuencia*[total_atributos])==NULL) exit(0);// 

//////////////////

unsigned int *tf, *tp, *tfa;

if ((tf=new unsigned int[total_atributos-1])==NULL) exit(0);
if ((tp=new unsigned int[total_atributos-1])==NULL) exit(0);
if ((tfa=new unsigned int[total_atributos-1])==NULL) exit(0);

LeerFrecuencias(tipo, topedesbordamiento, dimensiones_condicionantes, bases, total_distribuciones, total_distribuciones_condicionantes, total_condicionantes, tf, tfa, tp);

unsigned int coincidentes=0;
coincidentes=ContarAciertosBayes(tipo, bayesiano, convex, topedesbordamiento, dimensiones_condicionantes, bases, total_distribuciones, total_distribuciones_condicionantes, total_condicionantes, tf, tp, tfa);

for  (int cont=0; cont < total_atributos; cont++) //
if (atributos[cont].seleccionado==1) //
{//
  zap (bases[cont]);//
  zap (dimensiones_condicionantes[cont]);//
  if (cont!=ObtenerDependiente())
    zap (total_condicionantes[cont]);// 
}//

zap (topedesbordamiento);//
zap (dimensiones_condicionantes);//
zap (bases);//
zap (total_distribuciones); //
zap (total_distribuciones_condicionantes);//
zap (total_condicionantes);//
zap(tf);
zap(tp);
zap(tfa);

return(coincidentes);//
}//
////////////////////////////////////////////////
unsigned int red::obtener_configuracion()//
/* Obtiene el n£mero de patrones distintos posibles considerando todas las modalidades//
de todos los atributos marcados con 1 en lista_atributos*///
{//
unsigned int conf;//
conf = 1;//
 for (int i=0; i < total_atributos; i++)//
  if (atributos[i].seleccionado==1)//
 {  conf = conf*atributos[i].total_modalidades;//
//cout <<"conf: " <<conf << " ";//
}//
 return(conf);//
}//
/////////////////////////////////////////////////
unsigned int red::DependenciaFuncional(char tipo, unsigned int clase, unsigned int condicionantes, unsigned int* TablaCondicionantes)//
/*obtiene el ¡ndice de dependencia de los atributos seleccionados//
sobre el atributo dependiente  
//devuelve el n£mero de patrones cuya clase se clasifica bien.
*///
{

unsigned int total;	
if (tipo=='t') //
total=taman_ficheromissing; //
else total=taman_ficheromissingt; //


unsigned int errores=0, i=0, TotalPrueba;

if (tipo=='p')
TotalPrueba=taman_ficheromissing-taman_ficheromissingt;
else 
TotalPrueba=taman_ficheromissing;

/*
for (int patron=0; patron < taman_fichero; patron++)//
 if (patronborrado[patron]==0) //
 if (((tipo == 'p') && (marcado[patron]==tipo)) || (tipo =='t'))//
 {
  for (int num_atributo=0;num_atributo<total_atributos; num_atributo++)//
//     if (atributos[num_atributo].seleccionado==1) //
  {
  patrones2[i*total_atributos+num_atributo]=patrones[patron*total_atributos+num_atributo];
 // cout << patrones2[i*total_atributos+num_atributo] << ",";
  }
 // cout <<"\n";
  i++;

 }
   SampleFrequencies frecuencias1(1, &clase, (unsigned int)condicionantes, TablaCondicionantes, patrones2, //
   TotalMarcados, total_atributos, atributos, &error); //
   */
   frecuencias frecuencias1(1, &clase, (unsigned int)condicionantes, TablaCondicionantes, patrones, //
   marcado, patronborrado, tipo, taman_fichero, total, total_atributos, atributos, &error, salida); //

 // exit(0);
  if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //

    errores=frecuencias1.error(); //
	// cout <<"errores:" << errores;
 
	if (errores>TotalPrueba) cout <<"error en DepedenciaFuncional: encontrados " << errores << " errores de " << TotalPrueba;
     //cout <<"errores:" << errores << "tamfich:" << taman_ficheromissing;

	return (TotalPrueba-errores);
};//
/////////////////////////////////////////////////
double red::IMC(unsigned int primero, unsigned int segundo, unsigned int condicionante, //
unsigned int *condicionantes, char tipo)//
/*obtiene el ¡ndice de informaci¢n mutua condicionada//
del par de atributos introducido con respecto al tercero//
// si el tercero es 0, entonces calcula la informacion mutua 
*///
{//
//cout <<"\n\nNUUUUEVO\n";//
unsigned int juntos[2], total; //
int il; //
double resultado=0.0, logaritmo=0.0, cociente1=0.0, cociente2=0.0; //
juntos[0]=primero;//
juntos[1]=segundo;//
frecuencias *frecuencias1, *frecuenciasprimero, *frecuenciassegundo;
//for (i=0; i<total_atributos; i++) //
// cout <<"atrib: " << i <<", totmods:" <<atributos[i].total_modalidades <<"\n"; //
if (tipo=='t') //
total=taman_ficheromissing; //
else total=taman_ficheromissingt; //
//cout <<"total:" <<total;//
//exit(0);//

if ((frecuencias1=new frecuencias((unsigned int)2, juntos, condicionante, condicionantes, patrones,//
marcado, patronborrado, tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL)
{ cout <<"falta memoria"; exit(0); } //
//cout <<":  " << frecuencias1.obtener_base(0,0);//
//exit(0);//
//cout <<"Cond: "<<condicionante <<",condicionantes: " <<condicionantes[0];//

if ((frecuenciasprimero= new frecuencias((unsigned int)1, &primero, condicionante, condicionantes, patrones,//
marcado, patronborrado, tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL)
{cout <<"falta memoria"; exit(0);};//
if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //
//cout <<"primero:" << primero; //
//cout <<"segundo:" << segundo; //
//exit(0);//
if ((frecuenciassegundo=new frecuencias((unsigned int)1, &segundo, condicionante, condicionantes, patrones,//
marcado, patronborrado,tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL)
{cout <<"falta memoria"; exit(0);};//
if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //
//cout <<"totconds: " <<frecuencias1->total_distribuciones_condicionantes <<", tot1: " //
//<<atributos[primero]->total_modalidades <<", tot2: " <<atributos[segundo].total_modalidades ; //
//cout <<":  " << frecuencias1.obtener_base(1,0);//

for (int il=0; il<frecuencias1->total_distribuciones_condicionantes; il++)//
for (int i2=0; i2<atributos[primero].total_modalidades;i2++)//
for (int i3=0; i3<atributos[segundo].total_modalidades; i3++)//
{//
//cout <<"totconds: " << frecuencias1->total_distribuciones_condicionantes <<", totprims:"//
//<< atributos[primero].total_modalidades <<", totsegs:" << atributos[segundo].total_modalidades;//
//cout <<"base:" << i3*atributos[primero].total_modalidades+i2 <<"i:" << i; //
if (frecuencias1->obtener_base(i3*atributos[primero].total_modalidades+i2,il)>0)//
{//
//cout <<"SI";//
 if  ((frecuencias1->obtener_total_condicionantes(il)>0) && //
(frecuenciasprimero->obtener_base(i2,il)>0) &&//
(frecuenciassegundo->obtener_base(i3,il)>0))//
//resultado=0;//
{//
//cout <<"SI";//
// se calcula de forma que se obtengan primero un n�mero racional para comprobar si es igual a 1 y
// evitar errores de c�lculo en el logaritmo (si vale 1, el logaritmo a veces sale un n�mero negativo de m�dulo
// muy grande, en vez de 0
cociente1=(double)frecuencias1->obtener_base(i3*atributos[primero].total_modalidades+i2,il)*
		   (double)frecuenciasprimero->obtener_total_condicionantes(il)*(double)frecuenciassegundo->obtener_total_condicionantes(il);
cociente2= (double)frecuencias1->obtener_total_condicionantes(il)*(double)frecuenciasprimero->obtener_base(i2,il)*
(double)frecuenciassegundo->obtener_base(i3,il);
if (cociente1==cociente2) logaritmo=0;
else logaritmo=(double)numreal.log_2(cociente1/cociente2);
resultado=resultado+((double)frecuencias1->obtener_base(i3*atributos[primero].total_modalidades+i2,il) / //
 (double)taman_ficheromissing) *logaritmo;
//(double)numreal.log_2(((double)frecuencias1->obtener_base(i3*atributos[primero].total_modalidades //
 //+i2,i)/(double)frecuencias1->obtener_total_condicionantes(i))//
 // / //
//(((double)frecuenciasprimero->obtener_base(i2,i)/ //
//(double)frecuenciasprimero->obtener_total_condicionantes(i)) *  ///
//(((double)(frecuenciassegundo->obtener_base(i3,i)/ //
//(double)frecuenciassegundo->obtener_total_condicionantes(i))))));//
//if (primero==0 && segundo==110)
//cout <<"\ni2: " << i2 <<", i3: " << i3 <<", basei2:" << 
//frecuenciasprimero->obtener_base(i2,i) <<", totalcondenbasei2: " << 
//frecuenciasprimero->obtener_total_condicionantes(i) << ", basei3: "  <<
//frecuenciassegundo->obtener_base(i3,i) << ", totalcondenbase3: "
//<< frecuenciassegundo->obtener_total_condicionantes(i) <<"res; "<<resultado
//<<"todos:" << frecuencias1->obtener_base(i3*atributos[primero].total_modalidades+i2,i);
//resultado=resultado+resultado2;
}//
}//
}//
//if (primero==0 && segundo==110)
//exit(0);
//cout <<"r:" <<resultado;
//resultado=0;
zap (frecuencias1);
zap (frecuenciasprimero);
zap (frecuenciassegundo);
return((double)resultado);//
};//

/////////////////////////////////////////////////
/////////////////////////////////////////////////
void red::independencia_parcial(char texto[63])//
{//
unsigned int  atributo_a_comprobar,*base, *total_class, patron, patron2;//
//
/*Los valores de atributos parcialmente independientes son cambiados a MAX INT en cada patrón//
en donde sean independientes.//
Tambi�(c)n en la tabla "marcas" con tantas filas como patrones y celdas como atributos, se pone//
un "-" para cada uno que se elimine (el resto están con un ".").//
Para que un atributo sea parcialmente independiente el indice de independencia (indice)//
debe ser 0 o un valor próximo.//
Cada patrón inicialmente tiene una "marca" a 0. Cuando se le detecta algún atributo sup�(c)rfluo,//
marca pasa a valer "1". Eso sólo se hace para saber al final cuántos patrones han sido podados.*///
char *marca;//
if ((marca = new char [taman_fichero])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
  int posicion;//
//fichero_salida fichero_salida1;//
fichero_salida1.anadir(texto);//
  int *recorrido;//
unsigned int cont, cont2=0, k=0;//
double indice, fiabilidad;//
if ((recorrido = new   int [taman_fichero])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((base = new unsigned int[maximo_modalidades*(numero_clases+1)])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((total_class = new unsigned int [numero_clases])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
tabla1.iniciar('n', taman_fichero, recorrido);//
int i=0;//
do//
 atributo_a_comprobar=i;//
while (atributos[i].seleccionado==1);//
 for (patron=0;patron<taman_fichero;patron++)//
  if (patronborrado[patron]==0) //
   if (recorrido[patron]!='-')//
  {//
   recuento recuento1(patron, ObtenerDependiente(), taman_fichero, //
	 patrones, total_atributos, atributos, k, 0); //
	tabla1.iniciar('n', taman_fichero, marca);//
   cont=1;//
   tabla1.iniciar(0,maximo_modalidades*(numero_clases+1),base);//
   tabla1.iniciar(0,numero_clases,total_class);//
   posicion=(unsigned int)patrones[(patron+1)*total_atributos]; //
   total_class[posicion]=1; //
	base[intervalo(patrones[patron*total_atributos+atributo_a_comprobar], atributo_a_comprobar, atributos[atributo_a_comprobar])*(numero_clases+1)+posicion]=1;//
	base[intervalo(patrones[patron*total_atributos+atributo_a_comprobar], atributo_a_comprobar, atributos[atributo_a_comprobar])*(numero_clases+1)+numero_clases]=1; //
 //
   for (patron2=patron+1;patron2<taman_fichero;patron2++)    //
	if (patronborrado[patron2]==0) //
	if (recorrido[patron2]=='n')     //
	   if (recuento1.obtener_distancia(patron, patron2)==((//
		double)1/(double)total_atributos))//
	  {//
	   cont=cont+1;//
				posicion=(unsigned int)patrones[(patron2+1)*total_atributos]; //
	  //  cadena.buscarcadena (cad, clase);//
	   total_class[posicion]=total_class[posicion]+1; //
		base[intervalo(patrones[patron2*total_atributos+atributo_a_comprobar], atributo_a_comprobar, atributos[atributo_a_comprobar])*(numero_clases+1)+posicion]=//
		base[intervalo(patrones[patron2*total_atributos+atributo_a_comprobar], atributo_a_comprobar, atributos[atributo_a_comprobar])*(numero_clases+1)+posicion]+1;//
		base[intervalo(patrones[patron2*total_atributos+atributo_a_comprobar], atributo_a_comprobar, atributos[atributo_a_comprobar])*(numero_clases+1)+numero_clases]=//
		base[intervalo(patrones[patron2*total_atributos+atributo_a_comprobar], atributo_a_comprobar, atributos[atributo_a_comprobar])*(numero_clases+1)+numero_clases]+1;//
		marca[patron2]='s'; //
	   recorrido[patron2]='s';//
	  }//
	  indice = red::obtener_indice_por_combinacion(atributos[atributo_a_comprobar].total_modalidades,//
					numero_clases, total_class, cont, 0, base);  //
	  fiabilidad = (double) cont /( (double) atributos[atributo_a_comprobar].total_modalidades); //
	  if (indice!=0)  fiabilidad=0;//
	   if (fiabilidad ==1) //
	{//
	 cout << "Patron:" << patron << ". Elimin. " <<atributo_a_comprobar <<"\n";//
	 cont2=cont2+1;//
	 fichero_salida1 <<patron << " " <<atributo_a_comprobar <<"\n";//
		 patrones[patron*total_atributos+atributo_a_comprobar]=(float)maxreal;//
	 for (patron2=patron+1;patron2<taman_fichero;patron2++)    //
	 if (patronborrado[patron2]==0) //
	  if (marca[patron2]=='s')//
		{//
		 cout << "Patron:" << patron2 << ". Elimin. " <<atributo_a_comprobar <<"\n";//
		 cont2=cont2+1;//
		 fichero_salida1 <<patron2 << " " <<atributo_a_comprobar <<"\n";//
				 patrones[patron2*total_atributos+atributo_a_comprobar]=(float)maxreal;//
		} //
	 }//
   }//
cout << "\n" <<cont2 <<" filas de poda parcial.\n";//
fichero_salida1.close();//
zap (marca);//
zap (recorrido); //
zap (base);//
zap (total_class);//
}//
//
//////////////////////////////////////////////////////////
double red::obtener_indice_por_combinacion(int maxmods,//
int numclase, unsigned int *total_clase, unsigned int base_rest,//
int poda_simple, unsigned int *base)//
{//
  int  N_A, N_K,N_X, numclas, modalidad;//
double ind, F_z, F_ixz;//
par_enteros par_e;//
N_K=numclase;//
N_A=maxmods;//
//
ind = 0; //
for (numclas=0;numclas<numclas;numclas++)//
{//
 if (total_clase[numclas]!=0)//
 {//
	F_z=(double)  total_clase[numclas] / (double) base_rest;//
	for (modalidad=0;modalidad<maximo_modalidades;modalidad++)//
   { //
	if (base[modalidad*(numclas+1)+numclas] == 0)//
	 N_A=N_A-1;//
	else//
	{//
	  F_ixz= (double) base[modalidad*(numclas+1)+numclas]/ (double) base[modalidad*//
			(numclas+1)+numclas];   //
	  ind=ind+fabs (F_ixz - F_z)*fabs(F_ixz-F_z); //
	} //end  else//
 } //end for//
} // end if//
}//
N_X = par_e.max(N_A, N_K);//
ind = ((ind) / (double) N_X);//
if (poda_simple==1) ind = ind *(double) base_rest/(double)taman_ficheromissing;//
// o sea, si se ha hecho el mtodo DSML//
return(ind);//
}//
//////////
double red::obtenermaximofichero (unsigned int dependient) //
{ //
double total;//
total=1;//
for (int  i=0; i < total_atributos; i++) //
{ //
if ((i!= dependient) && (atributos[i].seleccionado==1)) //
total=total*(double)atributos[i].total_modalidades;//
}//
return(total);//
}//
//////////
double red::obtenermaximofichero2 (unsigned int dependient) //
{ //
double total;//
total=1;//
//cout <<"atrib depen:" <<ObtenerDependiente(); //
for (int i=0; i < total_atributos; i++) //
{ //
if (i!= dependient) //
total=total*(double)atributos[i].total_modalidades;//
}//
return(total);//
}//
/////////////////////////////////////////////////
unsigned int red::podar(unsigned int dependient)//
{//
// mtodo de poda usando dpendencia funcional (es poda/MRE) //
unsigned int seguir, acum, distintos,  inconsistentes, num_atributo, resto; //
  int eliminado, recorrido;//
double maximofichero;//
double *lista_independencias, umbral; //
if ((lista_independencias = new double[total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
//entrada_caracter caracter;//
umbral=0,1;//
acum=0;//
  cout << "\n Comprobando todos los atts.\n"; //
  //cout << "Error con todos: " << red::DependenciaFuncional(tipo, dependient, i, condicionantes);
								
do//
{ //
 seguir=0;//
 tabla1.iniciar((float)maxreal, total_atributos, lista_independencias);//
//
 num_atributo=0;//
eliminado=-1;//
 do//
 {//
  if ((atributos[num_atributo].seleccionado==1) && (num_atributo!=dependient))//
  {//
  atributos[num_atributo].seleccionado=0;//
  cout << "\n Comprobando el att. " << num_atributo  <<"\n"; //
//  lista_independencias[num_atributo]=taman_ficheromissing-red::DependenciaFuncional(tipo, dependient, i, condicionantes);
  atributos[num_atributo].seleccionado=1;//
 }//
 num_atributo=num_atributo+1;//
  }//
 while ((num_atributo < total_atributos)&& (lista_independencias[num_atributo-1]>0));//
  eliminado=tabla1.minimo(total_atributos, lista_independencias);//
  for (recorrido=0; recorrido < total_atributos; recorrido++)//
  if (eliminado != recorrido)//
   if (lista_independencias[recorrido]==lista_independencias[eliminado])//
	 eliminado=recorrido;  //
  if (eliminado < total_atributos)//
  {//
 cout << "El menor error corresponde al atributo " << eliminado <<"\n" << //
			   " y es: " <<lista_independencias[eliminado] //
			  << " y el num. de modalidades: " << atributos[eliminado].total_modalidades << ".";//
 maximofichero=red::obtenermaximofichero(ObtenerDependiente());//
 //cout <<"maxfich2:" << maximofichero;//
 // if (maximofichero<taman_ficheromissing)//
// maximofichero=red::obtenermaximofichero2(ObtenerDependiente());//
// cout <<"maxfich2:" << maximofichero;//
 cout <<"porcentaje:" <<(double)taman_ficheromissing/(double)maximofichero;//
  cout <<"\n El umbral es: " << 1-((1-umbral)*sqrt((double)taman_ficheromissing/maximofichero));//
  carac=caracter.leer_sn((char*)"Eliminar atributo (s/n)? ", 's');//
  if (carac=='n') //
  {//
  carac=caracter.leer_sn((char*)"Eliminar otro atributo (s/n)? ", 's');//
  if (carac=='s') //
   eliminado=entero.leer ((char*)"Introduzca atributo a eliminar: ", 0);//
  }//
  if (carac=='s') //
   {//
	 acum=acum+1;//
	 atributos[eliminado].seleccionado=0;//
	 seguir=1;//
   }//
else cout << "Ning£n atributo sera eliminado.\n";//
}//
}//
while ((seguir==1) && (acum<total_atributos-1)); //
//cout <<"Los atributos seleccionados han sido: \n";//
resto = 0;//
for(num_atributo=0; num_atributo<total_atributos; num_atributo++)//
 if ((atributos[num_atributo].seleccionado==1) && (num_atributo!=dependient))//
  {//
//  cout << num_atributo <<" ";//
  resto=resto+1;//
  } //
//cout <<"\n";//
zap (lista_independencias);//
return (resto+1);//
}//
//
/////////////////////////////////////////////////
unsigned int red::podarsesgo2(unsigned int dependient)//
{//
unsigned int eliminados, repetidos, inconsistentes, repetidosactuales, num_atributo, resto; //
  int eliminado, vueltas, actualizado;//
double configuraciones, configuracionesactuales, configuracionestotales;//
double riesgo, riesgototal, riesgoactual; //
//riesgototal =1-red::DependenciaFuncional(tipo, dependient, i, condicionantes)/(double)taman_ficheromissing;
riesgoactual=riesgototal; //
cout <<"\n Riesgo total:" <<riesgototal <<"\n"; //
configuracionestotales=red::obtenermaximofichero(dependient);//
configuracionesactuales=configuracionestotales;//
eliminados=0;//
repetidosactuales=repetidos;//
vueltas=0;//
do//
{ //
 actualizado=0;//
 for (num_atributo=0; num_atributo<(total_atributos-1);num_atributo++) //
  if ((atributos[num_atributo].seleccionado==1) && (num_atributo!=dependient))//
  {// //
  atributos[num_atributo].seleccionado=0;//
  cout << "\n Comprobando el att. " << num_atributo  <<"\n"; //
//  riesgo=1-red::DependenciaFuncional(tipo, dependient, i, condicionantes)/(double)taman_ficheromissing;//
  configuraciones=red::obtenermaximofichero(dependient);//
  cout <<"config:" <<configuraciones;//
 // cout <<"  config actuales:" <<configuracionesactuales;//
 cout <<"\n totalrepetidos:" << repetidos;//
  if (((riesgo==riesgoactual) && //
  ((configuraciones<configuracionesactuales)//
  || ((configuraciones==configuracionesactuales) && (repetidos<repetidosactuales))))//
  ||//
  (riesgo<riesgoactual) ||//
  ((riesgo>riesgoactual) && (actualizado==0) &&//
  (configuraciones<configuracionesactuales))//
  )//
   { //
 //  cout <<"escogido con riesgo:" << riesgo <<", repetidos:" <<repetidos;//
	riesgoactual=riesgo; //
	eliminado=num_atributo;//
	configuracionesactuales=configuraciones;//
	repetidosactuales=repetidos;//
	actualizado=1;//
	} //
  atributos[num_atributo].seleccionado=1;//
  }//
	cout << "El menor riesgo corresponde al atributo " << eliminado <<"\n" << //
			   " y es: " <<riesgoactual //
			  << " y el num. de modalidades: " << atributos[eliminado].total_modalidades << ".";//
	cout <<"porcentaje:" <<(double)(taman_ficheromissing)/(double)configuracionesactuales;//
   atributos[eliminado].seleccionado=0;//
   eliminados=eliminados+1; //
   vueltas=vueltas+1;//
  }//
while ((vueltas<total_atributos-1) && //
((configuracionesactuales>taman_ficheromissing) || (riesgoactual==riesgototal)));// //
//cout <<"Los atributos seleccionados han sido: \n";//
resto = 0;//
for(num_atributo=0; num_atributo<total_atributos;num_atributo++)//
 if ((atributos[num_atributo].seleccionado==1) && (num_atributo!=dependient))//
  {//
//  cout <<num_atributo <<" ";//
  resto=resto+1;//
  } //
//cout <<"\n";//
return (resto+1);//
}//

/////////////////////////////////////////////////
void red::podaMRE(unsigned int dependient)//
{//
//dobles largo;//
//char a;//
unsigned int num_atributo, seleccionado, *elegido,//
*condicionantes; //
 double riesgoactual, *riesgoprov; //
if ((elegido=new unsigned int [total_atributos-1])==NULL)
{
cout <<"falta memoria";
exit(0);
}if ((condicionantes=new unsigned int [total_atributos-1])==NULL)
{
cout <<"falta memoria";
exit(0);
}if ((riesgoprov=new double [total_atributos])==NULL)
{
cout <<"falta memoria";
exit(0);
}

tabla1.iniciar(maxreal, total_atributos, riesgoprov);//
tabla1.iniciar(0, total_atributos-1, elegido);//
for(int i=0; i<total_atributos_entrada;i++) //
{//
 atributos[i].seleccionado=1;//
 condicionantes[i]=i; //
 }//
frecuencias frecuencias1((unsigned int)1, &dependient, total_atributos-1, condicionantes, patrones, //
marcado, patronborrado,'t', taman_fichero, taman_ficheromissing, total_atributos, atributos, &error); //
if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //
			

riesgoprov[0]=frecuencias1.error(); //




//cout <<"\n Riesgo base:" <<riesgoprov[0]; //
for (int i=0; i<total_atributos_entrada;i++)//
{//
riesgoprov[i+1]=maxreal;//
 for (num_atributo=0; num_atributo<total_atributos_entrada;num_atributo++) //
  if ((elegido[num_atributo]==0) && (num_atributo!=dependient))//
  {//
//cout <<"\ncompronado atrb " <<num_atributo;//
  condicionantes[i]=num_atributo;//
//  cout << "\n Comprobando el att. " << num_atributo  <<"\n"; //
   frecuencias frecuencias1((unsigned int)1, &dependient, i+1, condicionantes,patrones, //
   marcado, patronborrado,'t', taman_fichero, taman_ficheromissing, total_atributos, atributos, &error); //
   if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //

riesgoactual=frecuencias1.error(); //




//   cout <<"Riesgo: " <<riesgoactual;//
//cin >>a;//
		if (riesgoactual<=riesgoprov[i+1]) //
   { //
//    cout <<"\nescogido con riesgo:" << riesgoactual;//
		riesgoprov[i+1]=riesgoactual; //
		seleccionado=num_atributo;//
	} //
  }//
	   cout << "\n El menor riesgo corresponde al atributo " << seleccionado <<"\n" << //
						   " y es: " <<riesgoprov[i+1]; //
   elegido[seleccionado]=1;//
   condicionantes[i]=seleccionado;//
  }//
total_seleccionados=tabla1.minimo (total_atributos, riesgoprov); //
//cout <<"\n Los atributos seleccionados son " << total_seleccionados <<" y son: \n";//
for(num_atributo=0; num_atributo<total_seleccionados;num_atributo++)//
  {//
//  cout <<condicionantes[num_atributo] <<" ";//
  atributos[condicionantes[num_atributo]].seleccionado=1;//
  } //
//cout <<"\n";//
//exit(0);//
total_seleccionados=total_seleccionados+1;// incluye la clase//
atributos[total_atributos-1].seleccionado=1;//
//cin >>a;//
zap (elegido);
zap (condicionantes);
zap (riesgoprov);
}//

////////////
unsigned short int red::espadre (unsigned int pred, unsigned int numatrib) //
{//
unsigned short int padre=0;
if (padres[(total_atributos_entrada+2)*numatrib+pred+1]==1) //
 padre=1;
return (padre);
}//
////////////
int red::PosicionNodo (unsigned int nodo, bool tipo)
{
// tipo=0 si nodo mayor, 1 si nodo menor)
bool encontrado=0;
unsigned int i=0;
do
{
 if (tablanodo[i].menor == nodo)
  encontrado=true;
 else ++i;
// cout <<"i:" << i <<", enc:" << encontrado;
 }
while ((i<total_atributos_entrada-1) && !encontrado);


if (!encontrado)
{
cout << "Error, no encontrada la posicion del nodo " << nodo;
exit(0);
}

 return i;
}
///////////////
bool red::EsAscendiente (unsigned int pred, unsigned int numatrib) //
{//
int ascendiente=0;
bool encontrado;

int i=PosicionNodo (numatrib, 1);

encontrado=false;
do
{
 if (tablanodo[i].mayor==pred)
  encontrado=true;
 else
  if (i>0 && tablanodo[0].mayor!=tablanodo[i].mayor)
   i=PosicionNodo (tablanodo[i].mayor, 1);
}
while ((!encontrado) && (i>0) && (tablanodo[0].mayor!=tablanodo[i].mayor));

if (!encontrado && tablanodo[i].mayor==pred)
 encontrado=true;

return (encontrado);
}//
///////////////
bool red::EsPadreTAN (unsigned int pred, unsigned int numatrib) //
{//
int ascendiente=0;
bool encontrado;

int i=PosicionNodo (numatrib, 1);

if (tablanodo[i].mayor==pred)
return true;
else return false;
}//

///////////////////////////
double red::obtenermargenSRM (unsigned short int is, unsigned short int numatrib,
double taman_medio, double long *serie, unsigned int modclase, float proba, 
double &total_parametros, double &total_parametros2)
{
double d=0.0;//
int muestra;
////////////
if (is==0) //
{//
//total_parametros=0.0;
//if (incompletos[numatrib]==0) //
 total_parametros=(double)
 *(serie+(maximo_modalidades-1)*(taman_ficheromissing-1)+atributos[numatrib].total_modalidades-1);

//total_parametros=taman_ficheromissing*log((double)atributos[numatrib].total_modalidades);//
//for (int muestra=0;muestra<taman_ficheromissing; muestra++)
//{

// total_parametros=total_parametros+
// (double)*(serie+muestra*(maximo_modalidades-1)+atributos[numatrib].total_modalidades-2)
// *(taman_ficheromissing+1-muestra);
//cout <<"fil:" << atributos[numatrib].total_modalidades-2;
//cout <<"col:" << muestra;
//cout <<"valor:" <<
// *(serie+muestra*(maximo_modalidades-1)+atributos[numatrib].total_modalidades-2);
// cout <<"\n";
//}
//else //
// total_parametros=(double)
// *(serie+(maximo_modalidades-1)*(taman_ficheromissing-1)+atributos[numatrib].total_modalidades-1);

//total_parametros=taman_ficheromissing*log((double)atributos[numatrib].total_modalidades-(double)1);//
//for (int muestra=0;muestra<=taman_ficheromissing; muestra++)
// total_parametros=total_parametros+
// (double)*(serie+muestra*(maximo_modalidades-1)+atributos[numatrib].total_modalidades-3)
// *(taman_ficheromissing+1-muestra);
//cout <<"tp." << total_parametros;
total_parametros=log ((double)total_parametros);
//exit(0);
}//
if (is==1) //
{//
total_parametros2=0;
for (int muestra=0; muestra<=taman_ficheromissing; muestra++)
 total_parametros2=total_parametros2+
 (double)*(serie+muestra*(maximo_modalidades-1)+modclase-2)
 *(taman_ficheromissing+1-muestra);
total_parametros2=log ((double)total_parametros2);
total_parametros=total_parametros+total_parametros2;
//cout <<"tp:" << total_parametros;
//if (incompletos[numatrib]==0) //
//total_parametros=(double)modclase*log((double)
//pow (atributos[numatrib].total_modalidades, taman_ficheromissing));//
//else //
//total_parametros=(double)modclase*log((double)
//pow (atributos[numatrib].total_modalidades-1, taman_ficheromissing));//
}//
if (is>1) //
{//
//cout <<"tammedio:" <<taman_medio;//
//if (tots<1) cout <<"tots:" <<tots;//

//if (incompletos[numatrib]==0) //
//total_parametros=log((double)numeromuylargo.comb(total_seleccionados-2, i-1))+//
//((double)pow(taman_medio,i-1)*(double)modclase*log ((double)
//pow (atributos[numatrib].total_modalidades, taman_ficheromissing)));//
//else //
//total_parametros=log((double)numeromuylargo.comb(total_seleccionados-2, i-1))+//
//((double)pow(taman_medio,i-1)*(double)modclase*log ((double)
//pow (atributos[numatrib].total_modalidades-1, taman_ficheromissing)));//
if (is==2)
{
total_parametros2=0;
//cout <<"tammed:" << taman_medio;
//cout <<"tammed:" << (unsigned int)taman_medio;
//exit(0);
for (int muestra=0;muestra<=taman_ficheromissing; muestra++)
{
//cout << "fils:" << (unsigned int)(taman_medio-2);
//cout << "cols: " << muestra;
 total_parametros2=total_parametros2+
 (double)*(serie+muestra*(maximo_modalidades-1)+numreal.redondear(taman_medio-2))
 *(taman_ficheromissing+1-muestra);
//cout << "fils:" << numreal.redondear(taman_medio-2);
//cout << "cols: " << muestra;
//cout << "res:" << numeromuylargo.seriebidimensional (numreal.redondear(taman_medio-2), muestra);
}
//exit(0);
total_parametros2=log ((double)total_parametros2);
//total_parametros2=(double)pow (total_parametros2, i-1);
}
total_parametros=total_parametros+total_parametros2;
total_parametros=log((double)numeromuylargo.comb(total_seleccionados-2, is-1))+
total_parametros;
//probar esto otro:
//total_parametros=log((double)numeromuylargo.comb(total_seleccionados-2, i-1)); 
}//
d=(total_parametros-(double)log (1-proba))/((double)2*(double)taman_ficheromissing);// red1.obtenermaximofichero2(condicionado));//
//cout <<"tp:" << total_parametros <<",tm:" <<taman_ficheromissing <<",i:" << i;

return (d);
}
/////////////////////////////////////////////////
void red::seleccionvariospadres(unsigned int dependient, char tipo,
unsigned short int modo, bool intervalos, bool tan)//
// modo: 
//0: SRM
//1: ERM
//2: LDM
//3: Entropia
{//     
//cout <<"VE";
char a;
double total_parametros, total_parametros2;
frecuencias *frecuencias1;
unsigned int seleccionados, numatrib, *elegido, total, //
*condicionantes, modclase, topepadre=0, contador=0, configuraciones=1; //
int seleccionado, pred;//
double long *serie;

int i=0;
if (tan) topepadre=2;
if (topepadre==0)
{
topepadre=1;
do
{
if (atributos[contador].seleccionado==1)
{
configuraciones=configuraciones*atributos[contador].total_modalidades;
topepadre=topepadre+1;
}
contador=contador+1;
}
while (configuraciones<taman_ficheromissing);
}

if ((elegido=new unsigned int [total_atributos])==NULL)
{
cout <<"falta memoria";
exit(0);
}if ((condicionantes=new unsigned int [total_atributos-1])==NULL)
{
cout <<"falta memoria";
exit(0);
}


if ((serie = new double long [(maximo_modalidades-1)*(taman_ficheromissing+1)])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);}
;
float proba=0.9;//
double riesgo, riesgoactual, *margen, taman_medio, d; //


if ((margen=new double [total_atributos])==NULL)
{
cout <<"falta memoria";
exit(0);
}
if (tipo=='t') //
total=taman_ficheromissing; //
else total=taman_ficheromissingt; //
if (incompletos[dependient]==0) modclase=atributos[dependient].total_modalidades; //
else modclase=atributos[dependient].total_modalidades-1;//

numeromuylargo.construirseriebidimensional (serie, maximo_modalidades-1, taman_ficheromissing+1);
//exit(0);
taman_medio=2;
// esto debi ponerlo para el intento de cambiar el calculo de d
// despues de escribir el articulo de discretizacion
for (numatrib=0; numatrib < total_atributos_entrada; numatrib++) //
if (atributos[numatrib].seleccionado==1) //
if ((!tan) || (numatrib!=tablanodo[0].mayor))
if (numatrib!=dependient) //
{//
/*
taman_medio=0.0;//
for (int i2=0; i2<total_atributos; i2++)//      total_combinaciones//
 if ((atributos[i2].seleccionado==1) && (i2!=condicionantes[0]) && (i2!=numatrib)) //
  if (incompletos[i2]==0) //
   taman_medio=taman_medio+(double)atributos[i2].total_modalidades;//
  else //
   taman_medio=taman_medio+(double)atributos[i2].total_modalidades-(double)1;//
taman_medio=taman_medio/(double)(total_seleccionados-2);//
*/
i=0;//
seleccionados=0;//
tabla1.iniciar(0, total_atributos-1, condicionantes);//
tabla1.iniciar(0, total_atributos, elegido);//
tabla1.iniciar(maxreal, total_atributos, margen);//
do //
{//
 if (i<2) //
 {//
condicionantes[0]=dependient;//
elegido[dependient]=1;//
if ((frecuencias1=new frecuencias((unsigned int)1, &numatrib, (unsigned int)i, condicionantes, patrones, //
marcado, patronborrado, tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL)
{cout <<"falta memoria"; exit(0);}; //
if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //

riesgo=frecuencias1->error(); //


zap (frecuencias1);

riesgoactual=riesgo; //
seleccionados=i;//
 }//
 else //
 {//
 riesgoactual=maxreal;//
 for (pred=0; pred<total_atributos;pred++) //
  if ((atributos[pred].seleccionado==1) && (pred!=dependient) && (pred!=numatrib)  && //
  (elegido[pred]==0) && (espadre(numatrib, pred)==0))//  espadre nos evita bucles simples
  if (!tan || (tan && i==2 & EsPadreTAN(pred, numatrib)) ||
  (tan && i>2 &&  EsAscendiente (pred, numatrib)))
//if ((modo==0) || (modo==2) || (pred>numatrib)) // evita cualquier bucle en estructuras que seran complejas
// como seleccion MRE o Entropia
  if (tan || pred>numatrib) // evita cualquier bucle en cualquier algoritmo excepto en gtan pure
  {//
  condicionantes[i-1]=pred;//
//if ((i<3) || ((i==3) && (pred<12)) )
{

   if ((frecuencias1=new frecuencias((unsigned int)1, &numatrib, i, condicionantes,patrones, //
  marcado, patronborrado,tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL)
  {cout <<"falta memoria"; exit(0);}; //
  if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //
riesgo=frecuencias1->error(); //
zap(frecuencias1);//
}
//else
//{
//cout <<"hola";
//cin >>a;
//}
//cout <<"riesgo atrb " << pred <<": " <<riesgo;

  if (riesgo<riesgoactual) //
   { //
   riesgoactual=riesgo; //
   seleccionado=pred;//
   } //
  }// end for//
   elegido[seleccionado]=1; //
   condicionantes[i-1]=seleccionado;//
}// fin nivel//

switch (modo)
{
case 0://SRM
d=obtenermargenSRM(i, numatrib, taman_medio, serie, modclase, proba, total_parametros, total_parametros2);
margen[i]=riesgoactual+ (d/(double)2)*((double)1+sqrt((double)1+(double)4*riesgoactual/d));//
//cout <<"margen para :" << i << " padres: " << margen[i];
//cout << ", d: " << d <<", riesgoactual: " << riesgoactual <<"\n";
//cin >>a;
//exit(0);
break;
case 1: //MRE
margen[i]=riesgoactual;//
break;
case 2:
; // LDM
break;
case 3: // Entropia
;
break;
}
i=i+1;//
//cin >> a;//
  }//
//  while ((i<(numatrib+2)) && (margen[i-1]<2));//
//  while ((i<total_seleccionados) && (margen[i-1]<2));//
while (i<=topepadre);
//cout <<"fin";
//while ((i<total_atributos) && (i<5) && (margen[i-1]<2));//
//while ((i<5) || (margen [i-1]<margen[i-2]) || (margen [i-2]<margen[i-3]));//
seleccionados=tabla1.minimo(total_atributos, margen);//
for(pred=0; pred<seleccionados;pred++)//
 padres[(total_atributos_entrada+2)*numatrib+condicionantes[pred]+1]=1;//
//exit(0);
if (seleccionados==0) //  se incluye al menos la clase �por qu�?
//if (seleccionados>0) //  lo cambio para incluirla solo si se ha seleccionado
{//
 padres[(total_atributos_entrada+2)*numatrib+dependient+1]=1;//
 seleccionados=1;//
}//
padres[(total_atributos_entrada+2)*numatrib]=seleccionados;//  el total de padres//
}// fin para cada numatrib//
zap (serie);
zap (elegido);
zap (condicionantes);
zap (margen);
}//
/////////////////////////////////////////////////
void red::seleccionvariospadres2(unsigned int dependient, char tipo,
unsigned short int modo, bool intervalos, bool tan)//
// modo: 
//0: SRM
//1: ERM
//2: LDM
//3: Entropia
{//     
//cout <<"VE";
char a;
double total_parametros, total_parametros2;
frecuencias *frecuencias1;
unsigned int seleccionados, numatrib, *elegido, total, //
*condicionantes, modclase, topepadre=0, contador=0, configuraciones=1; //
int seleccionado, pred;//
double long *serie;
int i=0;
if (tan) topepadre=1;
if (topepadre==0)
{
topepadre=1;
do
{
if (atributos[contador].seleccionado==1)
{
configuraciones=configuraciones*atributos[contador].total_modalidades;
topepadre=topepadre+1;
}
contador=contador+1;
}
while (configuraciones<taman_ficheromissing);
}

if ((elegido=new unsigned int [total_atributos])==NULL)
{
cout <<"falta memoria";
exit(0);
}if ((condicionantes=new unsigned int [total_atributos-1])==NULL)
{
cout <<"falta memoria";
exit(0);
}


if ((serie = new double long [(maximo_modalidades-1)*(taman_ficheromissing+1)])==NULL)
 {
 cout <<"Falta memoria";
 exit(0);}
;
float proba=0.9;//
double riesgo, riesgoactual, *margen, taman_medio, d; //


if ((margen=new double [total_atributos])==NULL)
{
cout <<"falta memoria";
exit(0);
}
if (tipo=='t') //
total=taman_ficheromissing; //
else total=taman_ficheromissingt; //
if (incompletos[dependient]==0) modclase=atributos[dependient].total_modalidades; //
else modclase=atributos[dependient].total_modalidades-1;//

numeromuylargo.construirseriebidimensional (serie, maximo_modalidades-1, taman_ficheromissing+1);
//exit(0);
taman_medio=2;
// esto debi ponerlo para el intento de cambiar el calculo de d
// despues de escribir el articulo de discretizacion
for (numatrib=0; numatrib < total_atributos_entrada; numatrib++) //
if (atributos[numatrib].seleccionado==1) //
if ((!tan) || (numatrib!=tablanodo[0].mayor))
if (numatrib!=dependient) //
{//
/*
taman_medio=0.0;//
for (int i2=0; i2<total_atributos; i2++)//      total_combinaciones//
 if ((atributos[i2].seleccionado==1) && (i2!=condicionantes[0]) && (i2!=numatrib)) //
  if (incompletos[i2]==0) //
   taman_medio=taman_medio+(double)atributos[i2].total_modalidades;//
  else //
   taman_medio=taman_medio+(double)atributos[i2].total_modalidades-(double)1;//
taman_medio=taman_medio/(double)(total_seleccionados-2);//
*/
i=0;//
seleccionados=0;//
tabla1.iniciar(0, total_atributos-1, condicionantes);//
tabla1.iniciar(0, total_atributos, elegido);//
tabla1.iniciar(maxreal, total_atributos, margen);//
do //
{//
 if (i==0) //
 {//
condicionantes[0]=dependient;//
elegido[dependient]=1;//
if ((frecuencias1=new frecuencias((unsigned int)1, &numatrib, (unsigned int)i, condicionantes, patrones, //
marcado, patronborrado, tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL)
{cout <<"falta memoria"; exit(0);}; //
if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //

riesgo=frecuencias1->error(); //


zap (frecuencias1);

riesgoactual=riesgo; //
seleccionados=i;//
 }//
 else //
 {//
 riesgoactual=maxreal;//
 for (pred=0; pred<total_atributos;pred++) //
  if ((atributos[pred].seleccionado==1) && (pred!=dependient) && (pred!=numatrib)  && //
  (elegido[pred]==0) && (espadre(numatrib, pred)==0))//  espadre nos evita bucles simples
  if (!tan || (tan && i==1 & EsPadreTAN(pred, numatrib)) ||
  (tan && i>1 &&  EsAscendiente (pred, numatrib)))
//if ((modo==0) || (modo==2) || (pred>numatrib)) // evita cualquier bucle en estructuras que sean complejas
// como seleccion MRE o Entropia
  if (tan || pred>numatrib) // evita cualquier bucle en cualquier algoritmo excepto en gtan pure
  {//
  condicionantes[i-1]=pred;//
//if ((i<3) || ((i==3) && (pred<12)))
{

   if ((frecuencias1=new frecuencias((unsigned int)1, &numatrib, i, condicionantes,patrones, //
  marcado, patronborrado,tipo, taman_fichero, total, total_atributos, atributos, &error))==NULL)
  {cout <<"falta memoria"; exit(0);}; //
  if (error==1) { cout <<"ERROR desbordamiento"; exit(0); } //
riesgo=frecuencias1->error(); //
zap(frecuencias1);//
}
//else
//{
//cout <<"hola";
//cin >>a;
//}
//cout <<"riesgo atrb " << pred <<": " <<riesgo;

  if (riesgo<riesgoactual) //
   { //
   riesgoactual=riesgo; //
   seleccionado=pred;//
   } //
  }// end for//
   elegido[seleccionado]=1; //
   condicionantes[i-1]=seleccionado;//
}// fin nivel//

switch (modo)
{
case 0://SRM
d=obtenermargenSRM(i, numatrib, taman_medio, serie, modclase, proba, total_parametros, total_parametros2);
margen[i]=riesgoactual+ (d/(double)2)*((double)1+sqrt((double)1+(double)4*riesgoactual/d));//
//cout <<"margen para :" << i << " padres: " << margen[i];
//cout << ", d: " << d <<", riesgoactual: " << riesgoactual <<"\n";
//cin >>a;
//exit(0);
break;
case 1: //MRE
margen[i]=riesgoactual;//
break;
case 2:
; // LDM
break;
case 3: // Entropia
;
break;
}
i=i+1;//
//cin >> a;//
  }//
//  while ((i<(numatrib+2)) && (margen[i-1]<2));//
//  while ((i<total_seleccionados) && (margen[i-1]<2));//
while (i<=topepadre);
//cout <<"fin";
//while ((i<total_atributos) && (i<5) && (margen[i-1]<2));//
//while ((i<5) || (margen [i-1]<margen[i-2]) || (margen [i-2]<margen[i-3]));//
seleccionados=tabla1.minimo(total_atributos, margen);//
for(pred=0; pred<seleccionados;pred++)//
 padres[(total_atributos_entrada+2)*numatrib+condicionantes[pred]+1]=1;//
//exit(0);
if (seleccionados==0) //  se incluye al menos la clase �por qu�?
//if (seleccionados>0) //  lo cambio para incluirla solo si se ha seleccionado
{//
 padres[(total_atributos_entrada+2)*numatrib+dependient+1]=1;//
 seleccionados=1;//
}//
padres[(total_atributos_entrada+2)*numatrib]=seleccionados;//  el total de padres//
}// fin para cada numatrib//
zap (serie);
zap (elegido);
zap (condicionantes);
zap (margen);
}//


/////////////////////////////////////////////////
void red::inclusion2(unsigned int dependient)//
{//
unsigned int seleccionados, inconsistentes, repetidos,  num_atributo; //
  int seleccionado, vueltas, *lista_seleccionados;//
double riesgo, riesgototal, margenactual, *margen; //
if ((lista_seleccionados=new   int [total_atributos-1])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((margen=new double [total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
tabla1.iniciar(0, total_atributos-1, lista_seleccionados);//
//riesgototal =1-red::DependenciaFuncional(tipo, dependient, i, condicionantes)/(double)taman_ficheromissing;
margen[0]=riesgototal; //
margenactual=margen[0];//
//inconsistentesactual=taman_ficheromissing;//
cout <<"\n Riesgo total:" <<riesgototal; //
seleccionados=0;//
//repetidosactuales=repetidos;//
vueltas=0;//
for (int i=0; i<(total_atributos-1);i++)//
{//
 margenactual=2;//
 for (num_atributo=0; num_atributo<(total_atributos-1);num_atributo++) //
  if ((atributos[num_atributo].seleccionado==0) && (num_atributo!=dependient))//
  {//
  atributos[num_atributo].seleccionado=1;//
//  cout << "\n Comprobando el att. " << num_atributo  <<"\n"; //
 // riesgo=1-DependenciaFuncional(tipo, dependient, i, condicionantes)/(double)taman_ficheromissing;
//cout <<"riesgo:" << riesgo;//
//  configuraciones=red::obtenermaximofichero(dependient);//
//  cout <<"config:" <<configuraciones;//
// cout <<"\n totalrepetidos:" << repetidos;//
// cout <<"VALOR:" <<  (double)configuraciones/(double)taman_ficheromissing;             //
// cout <<"VALOROLD:" <<  (double)configuracionesactuales/(double)taman_ficheromissing;//
//  cout <<"\n INCONS:" <<(double)inconsistentes;//
//  cout <<"\n INCONSOLD:" <<(double)inconsistentesactual;//
   margen[i+1]=riesgo;//+configuraciones/(double)taman_ficheromissing;//
	 if ((margen[i+1]  < margenactual)) //
//  ||  ((margen[i+1] == margenactual) && (repetidos>repetidosactuales)))  //
   { //
//   cout <<"escogido con riesgo:" << riesgo;// <<", repetidos:" <<repetidos <<", configuraciones:" << configuraciones //
//   <<"inconsistentes:" << inconsistentes;//
	seleccionado=num_atributo;//
//    repetidosactuales=repetidos;//
//    inconsistentesactual=inconsistentes;//
//    actualizado=1;//
	margenactual=margen[i+1];//
	lista_seleccionados[i]=seleccionado;//
	} //
  atributos[num_atributo].seleccionado=0;//
  }//
//        cout << "\n El menor margen corresponde al atributo " << seleccionado <<"\n" << //
//                           " y es: " <<margenactual; //
//              << " y el num. de modalidades: " << atributos[seleccionado].total_modalidades << ".";//
//    cout <<"porcentaje:" <<(double)(taman_ficheromissing)/(double)configuracionesactuales;//
   atributos[seleccionado].seleccionado=1;//
   seleccionados=seleccionados+1; //
   vueltas=vueltas+1;//
   margen[i+1]=margenactual;//
};//
//total=tabla1.minimo (total_atributos, margen); //
//cout <<"\n Los atributos seleccionados han sido: \n";//
//for(num_atributo=0; num_atributo<total;num_atributo++)//
//  cout <<lista_seleccionados[num_atributo] <<" ";//
//cout <<"\n";//
zap (lista_seleccionados);//
zap (margen);//
}//
/////////////////////////////////////////////////
unsigned int red::podarsesgo(unsigned int dependient)//
{//
unsigned int eliminados, inconsistentes, inconsistentesactual, repetidos, repetidosactuales, num_atributo, resto; //
  int eliminado, vueltas, actualizado;//
double configuraciones, configuracionesactuales, configuracionestotales;//
double riesgo, riesgototal, riesgoactual; //
//riesgototal =1-red::DependenciaFuncional(tipo, dependient, i, condicionantes)/(double)taman_ficheromissing;
riesgoactual=riesgototal; //
inconsistentesactual=inconsistentes;//
// cout <<"\n Riesgo total:" <<riesgototal <<"\n"; //
configuracionestotales=red::obtenermaximofichero(dependient);//
configuracionesactuales=configuracionestotales;//
eliminados=0;//
repetidosactuales=repetidos;//
vueltas=0;//
do//
{ //
 actualizado=0;//
 for (num_atributo=0; num_atributo<(total_atributos-1);num_atributo++) //
  if ((atributos[num_atributo].seleccionado==1) && (num_atributo!=dependient))//
  {//
  atributos[num_atributo].seleccionado=0;//
//  cout << "\n Comprobando el att. " << num_atributo  <<"\n"; //
//  riesgo=1-red::DependenciaFuncional(tipo, dependient, i, condicionantes)/(double)taman_ficheromissing;
  configuraciones=red::obtenermaximofichero(dependient);//
//  cout <<"config:" <<configuraciones;//
// cout <<"\n totalrepetidos:" << repetidos;//
// cout <<"VALOR:" <<  (double)configuraciones/(double)taman_ficheromissing;             //
// cout <<"VALOROLD:" <<  (double)configuracionesactuales/(double)taman_ficheromissing;//
//  cout <<"\n INCONS:" <<(double)inconsistentes;//
//  cout <<"\n INCONSOLD:" <<(double)inconsistentesactual;//
	 if (((inconsistentes+(configuraciones/(double)taman_ficheromissing))//
  < (inconsistentesactual+(configuracionesactuales/(double)taman_ficheromissing))) //
  ||//
  (((inconsistentes+(configuraciones/(double)taman_ficheromissing))//
  == (inconsistentesactual+(configuracionesactuales/(double)taman_ficheromissing))) && //
  (repetidos<repetidosactuales)))  //
   { //
  // cout <<"\n escogido con riesgo:" << riesgo <<" repetidos:" <<repetidos <<", configuraciones:" << configuraciones;//
	riesgoactual=riesgo; //
	eliminado=num_atributo;//
	configuracionesactuales=configuraciones;//
	repetidosactuales=repetidos;//
	inconsistentesactual=inconsistentes;//
	actualizado=1;//
	} //
  atributos[num_atributo].seleccionado=1;//
  }//
	cout << "\n El menor riesgo corresponde al atributo " << eliminado <<"\n" << //
			   " y es: " <<riesgoactual //
			  << " y el num. de modalidades: " << atributos[eliminado].total_modalidades << ".";//
	cout <<"porcentaje:" <<(double)(taman_ficheromissing)/(double)configuracionesactuales;//
   atributos[eliminado].seleccionado=0;//
   eliminados=eliminados+1; //
   vueltas=vueltas+1;//
  }//
while ((vueltas<total_atributos-1) && (actualizado==1));// //
//cout <<"Los atributos seleccionados han sido: \n";//
resto = 0;//
for(num_atributo=0; num_atributo<total_atributos;num_atributo++)//
 if ((atributos[num_atributo].seleccionado==1) && (num_atributo!=dependient))//
  {//
//  cout <<num_atributo <<" ";//
  resto=resto+1;//
  } //
//cout <<"\n";//
return (resto+1);//
}//
/////////////////////////////////////////////////
void red::inclusion3(unsigned int dependient)//
{//
unsigned int seguir, acum, contador, recorrido, inconsistentes,//
repetidos, num_atributo, resto; //
  int incluido;//
double maximofichero;//
double *lista_dependencias, *fiabilidad, *lista_absolutas, umbral; //
if ((lista_dependencias = new double[total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((lista_absolutas = new double[total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
if ((fiabilidad = new double[total_atributos])==NULL) //
 {//
 cout <<"Falta memoria";//
 exit(0);//
 }//
//entrada_caracter caracter;//
acum=0;//
umbral=0.1;//
for (contador=0; contador<total_atributos_entrada; contador++) //
 atributos[contador].seleccionado=0; //
tabla1.iniciar (0, total_atributos, lista_absolutas);//
do//
{ //
 seguir=0;//
 tabla1.iniciar(0, total_atributos, lista_dependencias);//
 tabla1.iniciar(0, total_atributos, fiabilidad);//
//
 num_atributo=0;//
incluido=-1;//
 do//
 {//
	if ((atributos[num_atributo].seleccionado==0) && (num_atributo!=dependient))//
  {//
  atributos[num_atributo].seleccionado=1;//
  //cout << "\n Comprobando el att. " << num_atributo  <<"\n"; //
//  lista_dependencias[num_atributo]=1-DependenciaFuncional(tipo, dependient, i, condicionantes)/(double)taman_ficheromissing;
   atributos[num_atributo].seleccionado=0;//
   if (acum==0) lista_absolutas[num_atributo]=lista_dependencias[num_atributo];//
 }//
 num_atributo=num_atributo+1;//
  }//
 while ((num_atributo < total_atributos) && (lista_dependencias[num_atributo-1] < 1));//
// (fiabilidad[num_atributo-1] != 1));//
  incluido=tabla1.maximo(total_atributos, lista_dependencias);//
//  cout <<"incluido:" << incluido <<"dependencia:" <<lista_dependencias[incluido];//
  for (recorrido=0; recorrido < total_atributos; recorrido++)//
  if (incluido != recorrido)//
   if (lista_dependencias[recorrido]==lista_dependencias[incluido])//
	if (lista_absolutas[recorrido] > lista_absolutas[incluido])//
	 incluido=recorrido;  //
  if (incluido != dependient)//
  {//
				cout << "\n" << "La mayor dependencia corresponde al atributo " << incluido <<"\n" << //
			   " y es: " <<lista_dependencias[incluido] //
			  << " y el num. de modalidades: " << atributos[incluido].total_modalidades << ".\n";//
 maximofichero=red::obtenermaximofichero(dependient);//
// if (maximofichero<taman_ficheromissing)//
// maximofichero=red::obtenermaximofichero2(dependient);//
 //cout <<"maxfich:" << maximofichero;//
  cout <<"porcentaje:" <<(double)taman_ficheromissing/(double)maximofichero;//
  cout <<"  total configuraciones muestra:" <<  //
  cout <<"El umbral es: " << 1-((1-umbral)*sqrt((double)taman_ficheromissing/maximofichero))<<"\n";//
				  //  carac=caracter.leer_sn("šIncluir atributo (s/n)? ", 's');//
							 carac='s';//
				 if (carac=='n') //
					   {//
						 carac=caracter.leer_sn((char*)"Incluir otro atributo (s/n)? ", 's');//
						 if (carac=='s') //
						   incluido=entero.leer ((char*)"Introduzca atributo a incluir: ", 0);//
						 }//
				 if (carac=='s') //
						 {//
						   acum=acum+1;//
						   atributos[incluido].seleccionado=1;//
						   seguir=1;//
						  }//
				  else cout << "Ningun atributo sera incluido.\n";//
	 }//   //
else cout <<"ERROR"; //
}//
while ((seguir==1) && (acum<total_atributos-1)); //
//cout <<"Los atributos seleccionados han sido: \n";//
resto = 0;//
for(contador=0; contador<total_atributos;contador++)//
 if ((atributos[contador].seleccionado==1) && (contador!=dependient))//
  {//
//  cout <<contador <<" ";//
  resto=resto+1;//
  } //
//cout <<"\n";//
zap (lista_dependencias);//
zap (lista_absolutas); //
zap (fiabilidad); //
//return (resto+1);//
}//
////////
void red::ImprimirArbol ()
{
unsigned int total=red::obtener_total_seleccionados();
//if (total!=total_atributos)
// cout <<"\nSeleccionados " << total <<" atributos";
for (int enodo=0; enodo<total-2; enodo++)
 cout << "\nArista " << enodo << ":" << tablanodo[enodo].mayor << "-" << tablanodo[enodo].menor << ": " << tablanodo[enodo].peso;
}
/////////
void red::encontrarpadres (unsigned int atributo) //
 {//
// asigna el padre que no es la clase a una atributo en el algoritmo TAN
//cout <<"Buscando padre a " << atributo;
//exit(0);
//char b; cin >>b;
 unsigned int arco=0; //
 bool encontrado=false;//
 
 while (!encontrado && (arco<red::obtener_total_seleccionados()-2))
 {
//       cout <<"arco:" << arco <<"menor:" << tablanodo[arco].menor;
  if (tablanodo[arco].menor==atributo) //
 {//
 encontrado=true;
//cout <<"enc" << encontrado; char a; cin >>a;
 comprobar (tablanodo, arco, total_atributos_entrada-1, "tc0");
 padres[(total_atributos_entrada+2)*atributo+tablanodo[arco].mayor+1]=1;//
 padres[(total_atributos_entrada+2)*atributo]=1;//  tiene 1 padre//
 //cout <<"encon padre del atrib " << atributo <<": " << tablanodo[arco].mayor;
 }
 arco=arco+1;
 } // fin while

// cout <<"el padre de " << atributo <<" es " << tablanodo[arco-1].mayor;
// cin >> b;
 if (!encontrado)
 {
 cout <<"error, no se encuentra el padre del atributo " << atributo <<"\n"; 
 if (atributos[atributo].seleccionado==1) cout <<"sel";
 else cout << "nosel";
 cout <<"total seleccionados es : " << obtener_total_seleccionados();
exit(0);
 };//

 }
///////////////////////////
void red::asignaIMC (char tipo, unsigned int clase=1)
{
//si clase vale 1 se usa IMC (informacion mutua condicionada por la clase)
//si vale 0, se usa informacion mutua

for (int i=0; i<(total_atributos-1); i++)//
 for (int i2=0; i2<(total_atributos-1); i2++)//no bastar�a con la mitad de la tabla?
  if (i2!=i)
   if (((i!=ObtenerDependiente()) && (atributos[i].seleccionado==1)) // revisar para que dependiente sea siempre el �ltimo valor
 // ya que la IMC es simetrica
 && ((i2!= ObtenerDependiente()) && (atributos[i2].seleccionado==1)))//
//cout <<"i: " << i <<" con i2: " << i2;
 tablacon[i*(total_atributos-1)+i2]= IMC(i,i2,clase,&dependiente, tipo);//

}

///////////////////////////
void red::ImprimirIMC (unsigned int clase)
{
if (clase==1)
 cout << "\nTabla de valores IMC (informacion mutua condicionada) dada la clase";
else 
 cout << "\nTabla de valores IM (informacion mutua) entre cada par de variables de entrada";

for (int i=0; i<(total_atributos-1); i++)//
if (i!=ObtenerDependiente()) // revisar para que dependiente sea siempre el ultimo valor
 if (atributos[i].seleccionado==1) //
 for (int i2=0; i2<(total_atributos-1); i2++)//no bastaria con la mitad de la tabla?
 // ya que la IMC es simetrica
  if (i2>i)
 if ((i2!= ObtenerDependiente()) && (atributos[i2].seleccionado==1))//
  cout << "\n Var: " << i << " (" << atributos[i].nombre <<") con var " << i2 <<" (" << atributos[i2].nombre << "): " << tablacon[i*(total_atributos-1)+i2];//
}
////////////////////
void red::BuscaArcoGanador ()
{
// busca el arco de m ximo peso
unsigned int aristamaxima[2];
struct nodo enodo;
double pesomaximo=-1.0;//
//cout <<"dep: " << ObtenerDependiente();
for (int i=0; i<(total_atributos-1); i++)//
if (i!=ObtenerDependiente()) // revisar para que dependiente sea siempre el �ltimo valor
 if (atributos[i].seleccionado==1) //
 for (int i2=(i+1); i2<(total_atributos-1); i2++)//no bastar�a con la mitad de la tabla?
 // ya que la IMC es sim�trica
 if ((i2!= ObtenerDependiente()) && (atributos[i2].seleccionado==1))//
if (tablacon[i*(total_atributos-1)+i2]>pesomaximo) //
{//
 pesomaximo=tablacon[i*(total_atributos-1)+i2];//
 aristamaxima[0]=i;//
 aristamaxima[1]=i2;//
// cout <<"\naristamax: " <<aristamaxima[0] <<"-" <<aristamaxima[1] <<", peso: " <<pesomaximo;//
}



if (pesomaximo==-1) 
 {
cout << "\nError en BuscarGanador";
exit(0);
}
 // se guarda como primer nodo el que corresponde a la pareja con mayor dependencia
 tablanodo[0].menor=aristamaxima[0];//
 tablanodo[0].mayor=aristamaxima[1];//
 tablanodo[0].peso=pesomaximo;//
if (aristamaxima[0]>total_atributos)
 cout <<"aristamax: " <<aristamaxima[0] <<"-" <<aristamaxima[1] <<", peso: " <<pesomaximo;//
//cin >>a;//
}
//////////////
void red::CrearArbolMaximo (unsigned int haplotypes=0)
// crea el  rbol con m ximo peso a partir de un grafo totalmente conexo con
//los pesos almacenados en tablacon. El arbol se guarda en tablanodo
{
bool *EnArbol; // tabla que contiene para cada atributo
// si ya est  en el arbol
double peso; 
unsigned int nodomaximofuera, nodomaximodentro;

if ((EnArbol=new bool [total_atributos_entrada])==NULL)
{
cout <<"falta memoria";
exit(0);
}


tabla1.iniciar(false, total_atributos_entrada, EnArbol); //


//a los nodos de m ximo IMC no se les asigna ninguno
EnArbol[tablanodo[0].mayor]=true;//
EnArbol[tablanodo[0].menor]=true;//


// ahora hay que ordenar los atributos
bool QuedanAtributosFuera=true;
if (obtener_total_seleccionados()<=3) QuedanAtributosFuera=false;
unsigned short int contador=1;
//cout <<"nodo0mayor:" <<tablanodo[0].mayor;
//cout <<"nodo0menor:" <<tablanodo[0].menor;
while (QuedanAtributosFuera)
{
peso=-1.0;
//en cada ciclo incluir  en el  rbol
// un nuevo arco, ya hay 1 incluido por eso se da una vuelta menos
 for (int i=0; i<total_atributos_entrada; i++) //busca el atributo aun fuera del arbol
  // que tenga el maximo peso con algun atributo del arbol
 if (atributos[i].seleccionado==1) //
  if (!EnArbol[i])//si aun no est  en el  rbol
     //busca entre los atributos del arbol
    for (int i2=0; i2<total_atributos_entrada; i2++)
     if (i2!=i)
     if (atributos[i2].seleccionado==1) //
     if (((haplotypes>0) && (abs(i-i2)<haplotypes)) || (haplotypes==0))
     if (EnArbol[i2])//si ya est  en el  rbol
      if (tablacon[i*(total_atributos-1)+i2]>peso)//
      {//
	peso=tablacon[i*(total_atributos-1)+i2];//
	nodomaximofuera=i;//
	nodomaximodentro=i2; //
      }//
    comprobar (tablanodo, contador, total_atributos_entrada-1, "tc1");
    tablanodo[contador].mayor=nodomaximodentro;//
    tablanodo[contador].menor=nodomaximofuera; //
    tablanodo[contador].peso=peso;//
    EnArbol[nodomaximofuera]=true;//
    contador=contador+1;//
    //cout <<"majot: " << nodomaximodentro;
    //cout <<"menot: " << nodomaximofuera;

    // el m ximo valor para contador debe ser total_atributos_entrada-1 o
    // total_atributos-2
    if (contador>(obtener_total_seleccionados()-3)) QuedanAtributosFuera=false;
  } // fin para cada nuevo arco
zap (EnArbol); //

}
///////////
void red::ObtenerRaiz ()
{

double *Lista_atribs;
unsigned int raiz;

if ((Lista_atribs=new double [total_atributos-1])==NULL)
{
cout <<"falta memoria";
exit(0);
}

// calcula para cada atributo el n�mero de veces que aparece en el
//arbol como criterio para elegir el ra�z
tabla1.iniciar(0, total_atributos-1, Lista_atribs);//

for (int i=0; i< (total_atributos_entrada); i++)    //
if (atributos[i].seleccionado==1)
 for (int i2=0; i2< (total_atributos_entrada); i2++)    //
  if (atributos[i2].seleccionado==1)
 Lista_atribs[i]=Lista_atribs[i]+tablacon[i*total_atributos_entrada+i2];


//selecciona y devuelve el ra�z 
raiz=tabla1.maximo(total_atributos-1, Lista_atribs);//raiz//

if ((raiz!=tablanodo[0].mayor) && (raiz!=tablanodo[0].menor))
 if (Lista_atribs[tablanodo[0].mayor]<Lista_atribs[tablanodo[0].menor])
  {
  raiz=tablanodo[0].menor;
  tablanodo[0].menor=tablanodo[0].mayor;
  tablanodo[0].mayor=raiz;
}
zap (Lista_atribs);
}
///////////////
void red::seleccionpadresTAN (unsigned int dependient, char tipo, unsigned int haplotypes, bool extendido) //
{//
//char a;//
unsigned int i2, m, alguno=0, contador,
nodomaximo, encontrado, ts=obtener_total_seleccionados(); //
double peso, pesomaximo;//

//char a;
//cout <<"previo"; cin >>a; 

//cout <<"DEPEND:" <<dependient;//


tabla1.iniciar(0.0, total_atributos_entrada*total_atributos_entrada, tablacon); //


for (int i=0; i< (total_atributos_entrada-1); i++)// 
{//
 comprobar (tablanodo, i, total_atributos_entrada-1, "tc2");
 tablanodo[i].peso=0;//
 tablanodo[i].mayor=0;//
 tablanodo[i].menor=0;//
}//


if (ts==1)
{
	cerr << "ningun atributo ha sido seleccionado";
	exit(0);
}
else
if (ts==2)
{
for (int i=0; i< (total_atributos_entrada); i++)    //
if (atributos[i].seleccionado==1)
{
  tablanodo[0].menor=i;
  tablanodo[0].mayor=i;
}
}
else
{
asignaIMC (tipo,1); // los valores se guardan en tablacon
BuscaArcoGanador ();
ObtenerRaiz();
CrearArbolMaximo (haplotypes);
}

if (salida==2) ImprimirArbol ();

bool tan=true;
unsigned short int MRS=0;

if (extendido)
{
 seleccionvariospadres2 (dependient, tipo, MRS, false, tan); //MRS//
for (int i=0; i<total_atributos_entrada; i++)
 if (atributos[i].seleccionado==1)
  if (i==tablanodo[0].mayor) // si es el raiz
 {
 padres[(total_atributos_entrada+2)*i+dependient+1]=1;//
 padres[(total_atributos_entrada+2)*i]=1;//  el total de padres//
 };
}
else
{

if (ts>2)
{
for (int i=0; i<total_atributos_entrada; i++)
 if (atributos[i].seleccionado==1)
 if (i!=tablanodo[0].mayor) // si no es el raiz
  encontrarpadres(i); //
}
// a�ade la clase
for(int i=0; i<total_atributos_entrada; i++) //
if (atributos[i].seleccionado==1) //
{//
 padres[(total_atributos_entrada+2)*i+dependient+1]=1;//
 padres[(total_atributos_entrada+2)*i]++;//  el total de padres//
} //
 //
}

}//
//////////
void red::obtener_padres(unsigned int dependient, unsigned int tipo, char tipo2,
unsigned int haplotypes)//
{//
const short unsigned int MRE=1;
const short unsigned int MRS=0;
unsigned int cont, cont2;//
tabla1.iniciar(0, (total_atributos_entrada*(total_atributos_entrada+2)), padres);//
//char a;//
switch (tipo) //
{ //
case 0:
//case 1:
//case 2: //

for (cont=0; cont < total_atributos-1; cont++)//
if (atributos[cont].seleccionado==1) //
if (cont!=dependient) //
{//
// cout <<"\n Atributo " <<cont; //
   padres[(total_atributos_entrada+2)*cont+dependient+1]=1;//
// cout <<", padre " <<total <<": " <<atrib <<" igual a posicion: " <<(total_atributos_entrada+2)*cont+(atrib+1);//
 padres[(total_atributos_entrada+2)*cont]=1;//  el total de padres//
 }//

/*for(cont=1; cont<total_atributos_entrada; cont++) //
if (atributos[cont].seleccionado==1) //
{//
 padres[(total_atributos_entrada+2)*cont+1]=1;//
// padres[(total_atributos_entrada+2)*cont+2]=1;//
 padres[(total_atributos_entrada+2)*cont+dependient+1]=1;//
 padres[(total_atributos_entrada+2)*cont]=2;//  el total de padres//
 } //

 padres[dependient+1]=1;//
 padres[0]=1;//  el total de padres//
*/
break;//
case 1: seleccionpadresTAN (dependient, tipo2, haplotypes, false); break;// tan y btan
case 2: seleccionpadresTAN (dependient, tipo2, haplotypes, true); break;// gtan y bgtan
case 3: seleccionvariospadres (dependient, tipo2, MRS, false, false); break; //MRS smag y bsmag
case 4: // libre


 padres[0]=3;// padres para el atributo 0
 padres[3]=1;//
 padres[4]=1;//
 padres[5]=1;// clase

 padres[6]=3;// padres para el atributo 1
 padres[9]=1;//
 padres[10]=1;//
 padres[11]=1;// clase

	

//seleccionvariospadres (dependient, tipo2, MRE, false, false);
break; //MRE convex y bconvex//
}//

//if (tipo==1) exit(0);//
//cout <<"DEPEND:" << dependient;//
//
//cout <<"salidar:" << salida;

if (salida==2)
{
for (cont=0; cont < total_atributos_entrada; cont++)//
if (atributos[cont].seleccionado==1) //
 if (cont !=dependient) //
 {//
 cout <<"\n Atributo " <<cont; //
 for (cont2=0; cont2<total_atributos; cont2++) //
  if (atributos[cont].seleccionado==1) //
  if (cont2!=cont) //
   if (padres[(total_atributos_entrada+2)*cont+cont2+1]==1) //
 cout <<", padre " <<cont2; // igual a posicion: " <<(total_atributos_entrada+2)*cont+(atrib+1);//
 cout <<"\nTotal padres: " <<padres[(total_atributos_entrada+2)*cont];//
 }//
}
//exit(0);
//  cin >>a;//
}//
#endif
