/*_________________________________________________________________________*/

// This program computes test accuracy and sd for a set of samples in filename given:
// - a discretization algorithm 
// - a classification algorithm


#include "MLComparison.h"//

//using namespace std;

//using namespace UTILS;

using namespace BIOS;

int main(int argc, char *argv[]) {

MLComparison *mLComparison;

mLComparison=new MLComparison(argc, argv);

};






