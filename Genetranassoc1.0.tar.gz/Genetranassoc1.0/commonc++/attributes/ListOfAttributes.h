/* File: ListOfAttributes.h */


#ifndef __ListOfAttributes_h__
#define __ListOfAttributes_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

//#include "../../../commonc++/ListOfPointers.cpp"
//#include "../../../commonc++/ficheros.cpp"
//#include "selection/SelMode.h"

//#include "Sample.h"
//#include "Selection.h"


//using namespace UTILS;


namespace BIOS
{



  /************************/
  /* ListOfAttributes DEFINITION */
  /************************/


  /**
          @memo ListOfAttributes 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */

// template <class T, template <class T> class Cont> class ListOfAttributes: public Set<Attribute, ListOfAttributes>

//template <class T, template <class T> class Cont> class Sample: public ListOfPointers<Container<T, Cont> >

//template <Attribute, ListOfPointers> class ListOfAttributes
// template <class T> class vector
//template <class T, template <class T> class Cont> class ListOfAttributes
//template <> Container<Attribute, ListOfPointers> class ListOfAttributes

//template<class T, template<class T> class Cont> class ListOfAttributes<Attribute, ListOfPointers>


class VerbosityClass;

  class ListOfAttributes: public Container<vector<Attribute*>, Attribute*>
  {

    // T can be Attribute, InputAttribute or ClassAttribute


    /* PUBLIC FUNCTIONS (INTERFACE) */

  private:


    // char* readID(ifstream* is, int i);

   // Set<Attribute, ListOfPointers>* vectorOfAttributes;
    void setDistance(Attribute* attribute, char* buffer);
    void setName(Attribute* attribute, char* buffer);
    void setModalidades(Attribute* attribute, char* buffer);

    void readAttributesFromData(char* texto);
  
  public:

    //floatList* positionsVector;
    int getTotalModalidades(int att);

    float getAlphaDenominator(BayesType bayesType, float alpha, intList *varList, intList *conditionalVarList);

//floatList* getAlphaNumerator(BayesType bayesType, float alpha, intList *varList, intList *conditionalVarList, int size);
   //virtual Attribute* Pop(){Container<set, Attribute*>::Pop();};
     ListOfAttributes* select();
  intList* getSelection();
virtual float getDistance(int att, int att2){};
//vi   void readPositions(char* filename);

   // bool hasID;
    intList* getDiscretePositions(floatList* attPattern);
    floatList* getValues(stringList* attPattern);
  intList* convertToDiscretePositions(floatList* attPattern);

   // intList* getDiscretePositions(stringList* attPattern);
  virtual ListOfAttributes* copyAttributesWithPositionsIn(intList* columns, bool isThis=true);
  floatList* getPositions(stringList* attPattern);
   // bool itHasID(){return hasID;};
    bool allSelected();
    bool isDiscretized();
    template <class T> stringList* getStringPattern(Container<vector<T>,T>* attPattern);
    ListOfAttributes(char* texto);
    ListOfAttributes(ListOfAttributes & vectorOfAttributes);
    ListOfAttributes(int totalAtts, int totalMods);
    virtual ListOfAttributes* clone();
    ListOfAttributes();
    Container<set<AttPattern*>, AttPattern*>* getSetOfAttPattern(intList* pattern);
    template <class T> bool isMissing(Container<vector<T>, T>* l);
    virtual ~ListOfAttributes();
    unsigned int GetTotalAttributes();
    float getDistance(Container<vector<string>, string> * pattern1, Container<vector<string>, string> * pattern2, bool useMissing, bool noclass, DistanceMethodClass *distanceMethodClass, int classPosition, doubleList* weights=NULL);    

  virtual float getDistance(Container<vector<float>, float> * pattern1, Container<vector<float>, float> * pattern2, bool useMissing, bool noclass, DistanceMethodClass* distanceMethodClass, int classPosition, doubleList* weights=NULL);    

       vector<bool>* setMissingPositions(floatList* pattern);
    unsigned int getTotalSelectedAttributes();
    void readAttributes(char* fileMas, bool verbosity=false);
  //  int GetClassAttribute();
    bool* getSelected();
    bool* getDiscrete();
    bool isContinuous();
    void crearFicheroMas (char texto[256]);
    void CrearFicheroNombres (char texto[1000], int classNumber=-1, bool discretized=false, bool select=false);
   // ListOfAttributes* getDiscreteListOfAttributes();
    virtual void getDiscreteListOfAttributes(ListOfAttributes* vectorOfDiscreteAttributes);
     ListOfAttributes* getSelection(intList* attList);

bool allAttributesAreOrdinalOrCategorical();
    void removeIntervals();
    void removeSelection();
    void selectAll();
    virtual void select(intList* attList);
    intList* getDimensionList(intList* vars);
    virtual float getWeight(int att, int att2){cout <<"Error in ListOfAttributes::getWeight"; end();};
    virtual float getBasicDistance(int att, int att2){cout <<"Error in ListOfAttributes::getBasicDistance, check whether .pos file exists"; end();};
    virtual float getMaxBasicDistance(int att){cout <<"Error in ListOfAttributes::getMaxBasicDistance"; end();};
    virtual Pair<int> getExtremes(int att, float maxDistance){cout <<"Error in ListOfAttributes::getExtremes"; end();};
    virtual string getName();


     };  // End of class ListOfAttributes

/*______________________________________________________*/

 ostream& operator<<(ostream& out, ListOfAttributes& vectora);

}
;  // Fin del Namespace

#endif
//#include "ListOfAttributes.cpp"

/* Fin Fichero: ListOfAttributes.h */
