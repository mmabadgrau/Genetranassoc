#ifndef __FachadeAttributes_h__ 
#define __FachadeAttributes_h__ 

//#include "../probabilities/FachadeProbabilities.h"

#include "DistanceMethodClass.h"
#include "Attribute.h"
#include "ListOfAttributes.h"
#include "ListOfOrderedAttributes.h"
#include "ListOfOrderedAttributesTreeDistances.h"

// end namespace

//#include "Front.cpp"
#endif
