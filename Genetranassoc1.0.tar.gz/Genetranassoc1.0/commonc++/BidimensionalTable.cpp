/* File: BidimensionalTable.h */


#ifndef __BidimensionalTable_cpp__
#define __BidimensionalTable_cpp__


using namespace std;

namespace BIOS
{

 

     template <class T> BidimensionalTable<T>::BidimensionalTable()
    {
     throw NonImplemented("Error in BidimensionalTable<T>::BidimensionalTable()");
    };
/*______________________________________________________*/

     template <class T> BidimensionalTable<T>::BidimensionalTable(BidimensionalTable<T>& other):MultidimensionalTable<T>(other)
    {
    };
/*______________________________________________________*/


   template <class T> BidimensionalTable<T>::~BidimensionalTable(){};
/*______________________________________________________*/
/*
     template <class T> void BidimensionalTable<T>::set()
    {
      this->totalDimensions=2;
      MultidimensionalTable<T>::set();
      
      this->table=NULL;
      this->dimensionList=NULL;
      this->size=0;
      this->totalCounts=0;
      
    };

  /*______________________________________________________*/

     template <class T> BidimensionalTable<T>::BidimensionalTable(intList* dimensionList):MultidimensionalTable<T>()
    {
    this->set(dimensionList);
    };

 /*______________________________________________________*/

     template <class T> BidimensionalTable<T>::BidimensionalTable(const char* filename, bool separation):MultidimensionalTable<T>()
    {
    struct VectorSample<T>::Class *sample;
  //  sample =new struct VectorSample<T>::Class(filename);
cout <<"error in BiodimensionaTable.cpp::BidimensionalTable(const char* filename): Line before commented suppresed but should be used. It drew a compilation error";
exit(0);
if (sample->size()==0) {set (0,0); return;}
    set(sample->size(), sample->getFirstElement()->size());
    Container<vector<T>, T>* row;
    T val;
    for (int i=0; i<this->getXDim(); i++)
    {
     row=sample->getElement(i);
     for (int j=0; j<this->getYDim(); j++)
{
val=row->getElementNotReference(j);
       this->setValue(i, j, val);
}
    }
    zap(sample);
    };
 /*______________________________________________________*/

     template <> BidimensionalTable<bool>::BidimensionalTable(const char* filename, bool separation):MultidimensionalTable<bool>()
    {
 intSample *sample=NULL;
    if (separation) sample=new intSample(filename);
    else
    {
    stringList *ssample=new stringList(filename);
    sample=new intSample();
    intList* row;
    string val;
    for (stringList::iterator it=ssample->begin(); it!=ssample->end(); it++)
     {
      row=new intList();
      val=ssample->getElement(it);
     for (int j=0; j<val.length(); j++)
if (val[j]=='0') row->insertElement(0); else row->insertElement(1);
sample->insertElement(row);
}
zap(ssample);
}
    if (sample->size()==0) {set (0,0); return;}
   set(sample->size(), sample->getFirstElement()->size());
    Container<vector<int>, int>* row;
    bool val;
    for (int i=0; i<this->getXDim(); i++)
    {
     row=sample->getElement(i);
     for (int j=0; j<this->getYDim(); j++)
{
val=row->getElement(j);
if (val!=0 && val!=1) throw BadFormat("BidimensionalTable<bool>::BidimensionalTable(const char* filename)");
       this->setValue(i, j, val);
}
    }
    zap(sample);
    }

    /*______________________________________________________*/

     template <class T> BidimensionalTable<T>::BidimensionalTable(int xDim, int yDim):MultidimensionalTable<T>()
    {
    set(xDim, yDim);
    };

/*______________________________________________________*/

 template <class T> void BidimensionalTable<T>::set(int xDim, int yDim)
{
intVector* cDimensionList=NULL;
cDimensionList=new intVector();
cDimensionList->insertElement(xDim);
cDimensionList->insertElement(yDim);
this->MultidimensionalTable<T>::set (cDimensionList);
zap(cDimensionList);
}
/*______________________________________________________*/

 template <class T> void BidimensionalTable<T>::reset(int xDim, int yDim)
{
this->MultidimensionalTable<T>::empty();// delete table
this->MultidimensionalEmptyTable<T>::empty();// delete dimensionList
if (this->table!=NULL || this->dimensionList!=NULL) throw BadFormat("void BidimensionalTable<T>::reset(int xDim, int yDim)");
set(xDim, yDim);
}

/*___________________________________________________*/

 template <class T> void BidimensionalTable<T>::setValue (int i, int j, T value)
{
try
{
int pos[2];
pos[0]=i;
pos[1]=j;
MultidimensionalTable<T>::setValue(pos, value);
}
catch (BasicException& be){be.addMessage("\ncalled from void BidimensionalTable<T>::setValue (int i, int j, T value)"); throw;};
}
/*___________________________________________________*/

 template <class T> void BidimensionalTable<T>::addValue (int i, int j, T value)
{
int pos[2];
pos[0]=i;
pos[1]=j;
MultidimensionalTable<T>::addValue(pos, value);
}
/*___________________________________________________*/

 template <class T> int BidimensionalTable<T>::getXDim()
{
return this->dimensionList->getElement(0);
}
/*___________________________________________________*/

 template <class T> int BidimensionalTable<T>::getYDim()
{
  if( this->dimensionList != NULL)
		return this->dimensionList->getElement(1);
  else
	 	return 0;
}
/*___________________________________________________*/

 template <class T> T BidimensionalTable<T>::getValue (int i, int j)
{
try
{
int* pos=new int[2];
pos[0]=i;
pos[1]=j;
T value=MultidimensionalTable<T>::getValue(pos);
zaparr(pos);
return value;
}
catch (BasicException& be){be.addMessage("\ncalled from T BidimensionalTable<T>::getValue (int i, int j)"); throw;};
}
/*___________________________________________________*/

template <class T> int BidimensionalTable<T>::getPos (int i, int j)
{
int* pos=new int();
pos[0]=i;
pos[1]=j;
int position=this->MultidimensionalTable<T>::getPos(pos);
zaparr(pos);
return position;
}

/*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, BidimensionalTable<T>& p)
  {
  out << "\t\t|\t";
      for (int i=0; i<p.dimensionList->getElement(1);i++)
        out << i << "\t|\t";
      out <<"\n";
      for (int i=0; i<p.dimensionList->getElement(1);i++)
      out <<"_____________________";
out <<"\n";
  for (int j=0; j<p.dimensionList->getFirstElement();j++)
{
out  << "\t" <<  j << "\t|\t";
  for (int i=0; i<p.dimensionList->getElement(1);i++)
   out << p.getValue(j,i) <<"\t|\t";
out <<"\n";
}
out <<"\n";
return out;
  };
}
#endif
