#ifndef __FachadeProbabilities_h__ 
#define __FachadeProbabilities_h__ 



#include "VarsTable.h"
#include "CPT.h"

#include "AlleleCPT.h"
#include "BidimensionalVarsTable.h"
#include "../attributes/FachadeAttributes.h"
#include "PotentialList.h"
#include "PotentialTable.h"
#include "ProbabilityTable.h"
#include "PriorTable.h"
//#include "AlleleCPT.cpp"

#include "ContingencyTable.h"




#endif
