/* File: SampleTable.h */


#ifndef __SampleTable_h__
#define __SampleTable_h__




using namespace std;


namespace BIOS
{


 /*______________________________________________________*/

  template<> void VarsTable<int>::set(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes)  throw (OutOfRange<long long int>) //,   intSample::NodePointer first, intSample::NodePointer last)
  {
   set(varList, 0);
    intSample* filteredSample=sample->copyColumns(varList, false); //copy using the order in the argument
	ListOfAttributes* listA=listOfAttributes->getSelection(varList);
//cout <<"filtedis:" << *filteredSample <<"\n";
    filteredSample->removeMissingPatterns(listA);
//cout <<"after is:" <<  *filteredSample <<"\n";
	zap(listA);
//cout << *varList;
//if (varList->GetFirstElement()==20)
//cout <<"\nvaelist is " << *varList <<" and " << *filteredSample->sample->GetFirstElement();
//end();
    totalSample=filteredSample->size();

    if (totalSample==0)
    {
      cout <<"Error when building probability table for vars " << *varList <<". There are not any complete individual";
      end();
    }
    intSample::iterator p=filteredSample->getFirst();
    int* pos;
    intList* pattern;
    initialize(0);

    int i=0;
long long int p2;
try
{
    while (p!=filteredSample->end())
    {
      pattern=filteredSample->getElement(p);
      pos=pattern->getTable();
p2=getPos(pos);
      this->addValue(p2, 1);
      p=filteredSample->getNext(p);
      zaparr(pos);
      i++;
    }
}
catch (OutOfRange<long long int> & ori){ori.addMessage("\ncalled from VarsTable<int>::set(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes)"); throw;}
   zap(filteredSample);
//    this->setTotalCounts();
   //   cout <<"\nll"<<this->print();

    //  cout <<"totalcounts" << this->getTotalCounts();
  };

/*_______________________________________________________________________*/


typedef VarsTable<int> SampleTable;

};

#endif
