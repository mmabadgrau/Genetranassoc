#ifndef __FachadeML_h__ 
#define __FachadeML_h__ 




#include "classifier/knn/KElement.h"
#include "sample/selection/SelModeClass.h"
#include "sample/selection/SelSubmodeClass.h"
#include "sample/discretization/DiscModeClass.h"
#include "userInterface/VerbosityClass.h"
#include "classifier/LossFunction.h"
#include "sample/MLSample.h"
#include "sample/discretization/FachadeDiscretization.h"
#include "sample/selection/FachadeSelection.h"
#include "sample/MLSample.cpp"
#include "Graphs/FachadeGraphs.h"
#include "BN/FachadeBN.h"
#include "classifier/FachadeClassifier.h"
#include "userInterface/FachadeUserInterface.h"
#include "sample/FachadeSample.h"




#endif
