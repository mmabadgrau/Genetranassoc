/***************************************************************************
 *   Copyright (C) 2005 by M. Mar Abad Grau 				   *
 *   mabad@ugr.es  						           *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/* File: ClassClassAttribute.cpp */


#ifndef __InputMI_UI_h__
#define __InputMI_UI_h__



//using namespace UTILS;

namespace BIOS {

class InputMI_UI: public InputTUI {





public:

InputMI_UI(int argc, char *argv[], char* programName);
~InputMI_UI();
bool isAModifier(char* c);
bool isAValue(char* c);
bool isHelp(char* c);
//void readInputFile();
void readClassPosition();
void readTestMode();
void readMetadata();
string getStringArgument(char a);
int getArgumentPosition(char a);
};



}


#endif





