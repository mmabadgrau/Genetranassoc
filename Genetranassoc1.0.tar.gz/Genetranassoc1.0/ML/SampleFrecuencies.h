class SampleFrequencies
{
private://
	
struct atributo *atributos;	
unsigned int *indices_condicionantes, *indices_primeros, *patronborrado, *condicionantes, *primeros;

unsigned int condicionante, primero, taman_fichero; //
// condicionante es el n£mero de atributos condicionantes//
// primero el n£mero de atributos condicionados//
char tipo, *marcado; //
int total_atributos; //
enteros entero; //
//condicionantes la tabla de atributos condicionantes//
//primeros la tabla de atributos condicionados//
float *patrones;
int contador;//
//total_distribuciones_primeros el total de configuraciones de los atributos//
//condicionados//
tabla tabla1;//
unsigned int  *dimensiones_primeros, desbordamiento; //
dobles largo;//
public://
struct frecuencia *frecs; //
//dimensiones_condicionantes la tabla con las modalidades para cada//
//atributo condicionante//
//dimensiones_primeros la tabla con las modalidades para cada//
//atributo condicionado//
//total_distribuciones_condicionantes es el total de distribuciones para//
//cada atributo condicionante y total_distribuciones el total completo//
//total_distribuciones_condicionantes el total del configuraciones de los//
//atributos condicionantes//
//base son frecuencias condicionadas, total_condicionante frecuencias marginales//
unsigned int *base, topedesbordamiento, *dimensiones_condicionantes, tamanfrecs, tamanfrecsampliado;//
int total_distribuciones_condicionantes, total_distribuciones; //
int total_distribuciones_primeros;//

// primer es el numero de atributos condicionados, primeros la tabla con los atributos,
// condicionant es el numero de atributos condicionantes, condicionantes la tabla con dichos
//atributos. Si condicionante es 0, la tabla puede ser NULL pues no se usara
frecuencias (unsigned int primer, unsigned int *primers,//
unsigned int condicionant, unsigned int *condicionant,//
float *patrons, char *marcad, unsigned int *patronborr, char tip,//
unsigned int tamfich,  unsigned int tamfichmiss,
int total_atribs, struct atributo *atributs, unsigned int *err);//

 unsigned int error();     //
 double probcond(unsigned int*, unsigned int*, float*, char*, struct atributo*, unsigned int*);     //



 int buscarlugar (unsigned int); //
 unsigned int obtener_base(unsigned int, unsigned int);//
 unsigned int obtener_total_condicionantes (int);//
int obtener_total_distribuciones_condicionantes (void);//
// unsigned int* obtener_dimensiones_condicionantes(void);//
 ~frecuencias(); //
 }; //
/////////////////////////////
frecuencias::~frecuencias () {
zap (dimensiones_condicionantes); //
zap (dimensiones_primeros);
zap (frecs);
zap (base);//
zap (indices_condicionantes);
zap (indices_primeros);
}; //
///////////////////
frecuencias::frecuencias (unsigned int primer, unsigned int *primers,//
unsigned int condicionant, unsigned int *condicionants,//
float *patrons, char *marcad, unsigned int *patronborr, char tip,//
unsigned int tamfich,  unsigned int tamfichmiss,
int total_atribs, struct atributo *atributs, unsigned int *err)//
//tip es 't' para todos los patrones, 'p' para los de prueba//
//total_distribuciones_condicionantes: producto de todas las modalidades
// de todas las variables condicionantes
// total_distribuciones_primeros: total de modalidades de la variable condicionada
// indices_primeros
// tamanfrecs es el m�nimo entre el tama�o del fichero y el total de distribuciones
// condicionantes
// tamanfrecs_ampiado es tamanfrecs al cuadrado 
// bases es tamanfrecsampliado por total_distribuciones_primeros
// bases contendr� las frecuencias para cada configuraci�n de variables
// condicionadas y condicionantes. Si hay m�s configuraciones de variables condicionantes
// que ejemplos en la muestra, se reducir� al n�mero de ejemplos en la muestra al cuadrado
//(por las configuraciones de las variables condicionadas)
// frecs es tamanfrecsampliado
// frecs tiene la frecuencia absoluta de cada configuraci�n de variables condicionantes al cuadrado
// si hay demasiadas configuraciones, usar� tantas como el tama�o del fichero
// tiene dos partes: posicion es el n�mero de orden de la configuraci�n
// condicionante es la frecuencia
// posicion se obtiene con obtener_posicion a partir de las configuraciones
// de las variables condicionantes
// la zona de desbordamientos empieza a partir de tamanfrecs, es decir, a partir
// del total de configuraciones condicionantes o del tama�o del fichero si es menor
// Cuando el n�mero de configuraciones condicionantes es muy grande comparado
// con el tama�o del fichero, se usan tamanfichero como tamanfrecs y se usa
// entonces una zona de desbordamiento que es 8 veces mayor que el tama�o
// del fichero por el total de configuraciones de entrada
{//
//char a;//
patrones=patrons;
condicionantes=condicionants;
primeros=primers;
marcado=marcad;
atributos=atributs;
	tipo=tip;//
*err=0; //
//marcado=marc;//
patronborrado=patronborr;//
//atributos=atribs; //
int i, posicion, posicion2; //
unsigned int patron, cont;//
int lugar;//
condicionante=condicionant;//
primero=primer;//
taman_fichero=tamfich;//
taman_fichero_missing=tamfichmiss;//
//patrones=patrs; //
//condicionantes=condicionants;//
//primeros=primers;//
total_atributos=total_atribs;//
//unsigned int *indices_condicionantes, *indices_primeros; //

char a;


if ((indices_condicionantes=new unsigned int[condicionante])==NULL)
{
cout <<"falta memoria";
exit(0);
};//

if ((indices_primeros = new unsigned int [primero])==NULL)
{
cout <<"falta memoria";
exit(0);
};//
total_distribuciones_condicionantes=1;//
total_distribuciones_primeros=1;//
if (condicionante!=0)//
 tabla1.iniciar(0, condicionante, indices_condicionantes);//
tabla1.iniciar(0, primero, indices_primeros);//
if ((dimensiones_primeros = new unsigned int [primero])==NULL)
{
cout <<"Error. Falta memoria";
exit(0);
};//
if ((dimensiones_condicionantes=new unsigned int[condicionante])==NULL)//
{//
cout <<"Error02, no hay memoria"; //
*err=1;
exit(0);
}; //
///////////
for(i=0;i<condicionante;i++) //
{
if (condicionantes[i]>=total_atributos) //
 {//
// cout <<"cond de " <<i <<": " << condicionantes[i];//
 cout <<"ERROR, el " << i <<"-gesimo atributo condicionante es " << condicionantes[i] << ", cuando solo hay " << total_atributos << " atributos.\n"; //
 *err=1;
 exit(0);
 } //


comprobar (condicionantes,i,condicionante, (char*)"f1"); 
comprobar (atributos, condicionantes[i], total_atributos, (char*)"f2");
comprobar (dimensiones_condicionantes,i,condicionante, (char*)"f3"); 
dimensiones_condicionantes[i]=atributos[condicionantes[i]].total_modalidades;//
if (((double)total_distribuciones_condicionantes*(double)atributos[condicionantes[i]].total_modalidades)//
> (double)entero.maxlong()) //
{ //
total_distribuciones_condicionantes=0; //
*err=1;//
cout <<"Error00, rango excedido";//
//frecuencias::~frecuencias(); //
exit(0);
}//
comprobar (condicionantes,i,condicionante, (char*)"f4"); 
comprobar (atributos,condicionantes[i],total_atributos, (char*)"f5"); 
total_distribuciones_condicionantes=total_distribuciones_condicionantes*//
atributos[condicionantes[i]].total_modalidades;//
} //fin para cada i//
//exit(0);
////////////
for(i=0; i<primero; i++) //
{//
comprobar (primeros,i,primero, (char*)"f6"); 
if (primeros[i]>=total_atributos) //
 {//
  cout <<"ERROR01, rango excedido; "; //
 *err=1;
//  frecuencias::~frecuencias();
exit(0);
 } //

comprobar (primeros,i,primero, (char*)"f7"); 
comprobar (dimensiones_primeros,i,primero, (char*)"f8"); 


 comprobar (atributos,primeros[i],total_atributos, (char*)"f9"); 
 dimensiones_primeros[i]=atributos[primeros[i]].total_modalidades;//

 if (((double)total_distribuciones_primeros*(double)dimensiones_primeros[i])//
>(double)entero.maxlong()) //
{//
total_distribuciones_primeros=0; //
*err=1;//
 cout <<"Error02, rango excedido";//
// frecuencias::~frecuencias();
exit(0);
}//
comprobar (primeros,i,primero, (char*)"f10"); 
comprobar (atributos,primeros[i],total_atributos, (char*)"f11"); 
total_distribuciones_primeros=total_distribuciones_primeros* //
atributos[primeros[i]].total_modalidades;//

}//fin para cada i//
///////////
//if ((condicionant>4) || ((condicionant==4) && (condicionantes[condicionant-1]>12)) )
//{
//cout <<"hola";
//cin >> a;
//}

total_distribuciones=total_distribuciones_primeros* //
total_distribuciones_condicionantes;////
if (total_distribuciones_condicionantes>taman_fichero_missing)
{
tamanfrecs=taman_fichero_missing;//
if (taman_fichero_missing<100)
tamanfrecsampliado=tamanfrecs*tamanfrecs;//
else
tamanfrecsampliado=tamanfrecs*8;
}
else
{
tamanfrecs=total_distribuciones_condicionantes;//
tamanfrecsampliado=tamanfrecs*8;//
}

//if ((condicionant>4) || ((condicionant==4) && (condicionantes[condicionant-1]>12)) )
//{
//cout <<"hola2, tamanfrecs: " << tamanfrecs <<", tamaamp:" << tamanfrecsampliado;
//cin >> a;
//}

if (((base=new unsigned int[(tamanfrecsampliado*total_distribuciones_primeros)])==NULL) || //
((frecs=new frecuencia[tamanfrecsampliado])==NULL)) //
{//
cout <<"Error2, no hay memoria"; //
*err=1;
exit(0);
//frecuencias::~frecuencias();
exit(0);
} //
//
//if ((condicionant>4) || ((condicionant==4) && (condicionantes[condicionant-1]>12)) )
//{
//cout <<"hola3";
//cin >> a;
//}

       // segundo

tabla1.iniciar(0,tamanfrecsampliado*total_distribuciones_primeros,base);//
for (cont=0; cont < tamanfrecsampliado; cont++) //
   if (tabla1.desborde (tamanfrecsampliado, cont)!=0) //
 {//
  cout <<"ERROR tabla1.desborde."; //
 *err=1;
// frecuencias::~frecuencias();
exit(0);
 } //
 else
{
 (*(frecs+cont)).posicion=-1;//
 (*(frecs+cont)).condicionante=0; //
}

if (((double)total_distribuciones_primeros*(double)total_distribuciones_condicionantes) //
> (double) entero.maxlong()) //
{//
total_distribuciones_condicionantes=0; //
*err=1;//
 cout <<"Error03, rango excedido";//
// frecuencias::~frecuencias();
exit(0);
}//
desbordamiento=tamanfrecs;//inicio zona desbordamientos//
topedesbordamiento=tamanfrecs;//



for (patron=0;patron<taman_fichero;patron++)//
if (patronborrado[patron]==0) //
if (((marcado[patron]!=tipo) && (tipo=='p')) || (tipo=='t'))//
{//
// cout <<"patron: " <<patron <<", clase: " <<patrones[(patron*total_atributos)+total_atributos-1];//
 for(i=0; i<condicionante; i++)//
 {//
 comprobar (condicionantes,i,condicionante, (char*)"f12"); 
 comprobar (atributos, condicionantes[i], total_atributos, (char*)"f13");
 comprobar (patrones,patron*total_atributos+condicionantes[i],taman_fichero*total_atributos, (char*)"f14"); 
 comprobar (indices_condicionantes,i, condicionante, (char*)"f15");

  indices_condicionantes[i]=intervalo(patrones[patron*total_atributos+condicionantes[i]], condicionantes[i], atributos[condicionantes[i]]);//
  if (indices_condicionantes[i]>=atributos[condicionantes[i]].total_modalidades) //
  {//
   cout <<"Error, valor fuera de rango" <<i <<",valor:" <<indices_condicionantes[i] ;//
   *err=1;//
//   frecuencias::~frecuencias();
exit(0);
  }//
 }//   fin for i//


 posicion=tabla1.obtener_posicion (indices_condicionantes, dimensiones_condicionantes, condicionante);//
//if (patron==14)  cout <<",posicion:" << posicion;//


if (posicion>=total_distribuciones_condicionantes) //
  {//
   cout <<"Error2, valor fuera de rango";//
   *err=1;//
   cout <<"patron:" <<patron <<"pos:" <<posicion <<"totalconds:" <<condicionante <<"cond0: " //
  << condicionantes[0] <<", cond1: " << condicionantes[1] <<"ind0: " << indices_condicionantes[0] //
  <<", ind 1: " <<indices_condicionantes[1] <<"dimcond0: " <<dimensiones_condicionantes[0] //
 <<"dimcond1: " <<dimensiones_condicionantes[1]  ;//
//  frecuencias::~frecuencias();
exit(0);
  } //



  lugar=buscarlugar(posicion); //

  

  if (lugar>-1) //ya estaba//
  {//
// innecesario porque se comprueba cuando se asigna por primera vez un valor a
// esa posici�n (o sea, cuando se devuelve -1,
// quitado mayo 14, 2003
//   if (tabla1.desborde (tamanfrecsampliado, lugar)==0) //
   {//
   (*(frecs+lugar)).condicionante=(*(frecs+lugar)).condicionante+1;//
//   (*(frecs+lugar)).posicion=posicion;//   quitado 14 mayo 2003
   }//
//   else {//
//    cout <<"tabla1.desborde3"; //
//   *err=1;
//exit(0);
//   } //
   }//fin ya estaba
  else //
  if (lugar==-1) // ocupado por otro y no encontrado en zona de desbordamiento
  {//
     lugar=topedesbordamiento;//
     if (tabla1.desborde(tamanfrecsampliado,lugar)==0) //
     {//
     (*(frecs+lugar)).posicion=posicion; //   //
     (*(frecs+lugar)).condicionante=1;//
     topedesbordamiento=topedesbordamiento+1;//
     if (topedesbordamiento>tamanfrecsampliado)
     {//
      cout<<"ERR";//
     *err=1;
//      frecuencias::~frecuencias();
exit(0);
     }//
    }// fin no desborde
  else // desborde
  {//
     cout <<"Topedesb:" <<topedesbordamiento <<", taman:" << tamanfrecsampliado;//
     cout <<"tabla1.desborde4";//
     *err=1;
//     frecuencias::~frecuencias();
exit(0);
     } // fin desborde
   }// fin lugar -1
   else //
 if (lugar==-2) // libre
  {//
     lugar=posicion%tamanfrecs;//
// quitado, no se produce nunca, el 14 mayo 2003
//     if (tabla1.desborde(tamanfrecsampliado,lugar)==0) //
     {//
     (*(frecs+lugar)).posicion=posicion; //
     (*(frecs+lugar)).condicionante=1;//
     }//
//     else // si desborde
//     {//
//      cout <<"tabla1.desborde5"; //
//     *err=1;
//      exit(0);//
//     } //
   } //fin lugar -2


 for(i=0; i<primero; i++)//
 { //
 comprobar (primeros,i,primero, (char*)"f16"); 
 comprobar (atributos,primeros[i],total_atributos, (char*)"f17"); 
 //total_distribuciones_primeros=total_distribuciones_primeros* //
 //atributos[primeros[i]].total_modalidades;//
 comprobar (patrones,patron*total_atributos+primeros[i],taman_fichero*total_atributos, (char*)"f18"); 
 comprobar (indices_primeros,i, primero, (char*)"f19");
 exit(0);
 indices_primeros[i]=intervalo(patrones[patron*total_atributos+primeros[i]], primeros[i], *(atributos+primeros[i]));//
 if (indices_primeros[i]>=atributos[primeros[i]].total_modalidades) //
  {//
  for (int a=0; a<total_atributos-1;a++)
  cout << "\natrb " << a  <<" tam: " << atributos[a].total_modalidades;
    cout <<"Error3, valor fuera de rango, atributo primero:" << primeros[i] <<", valor:" //
   <<indices_primeros[i] <<",patron:" <<patron;//
   *err=1; //
//   frecuencias::~frecuencias();
   exit(0); //
  } //

//cout <<"S2p";//
  
 }// fin for i//


 posicion2=tabla1.obtener_posicion (indices_primeros,//
 dimensiones_primeros, primero);//
 if (posicion2>=total_distribuciones_primeros) //
  {//
   cout <<"Error4, valor fuera de rango";//
   cout <<"indices primeros: " <<indices_primeros[0] //
   <<"totprimero:" <<primero  <<"prim0:" <<primeros[0] <<",prim2:" //
   <<primeros[1]<<",dim0:" <<dimensiones_primeros[0] <<",dim1:" <<dimensiones_primeros[1]//
   <<"pos2:" <<posicion2 <<"totprims:" <<total_distribuciones_primeros;//
   *err=1;//
//   frecuencias::~frecuencias();
   exit(0); //
  } //




 if ((total_distribuciones_primeros*posicion+posicion2)>=total_distribuciones) //
{//
  cout <<"error, base excedida: " <<total_distribuciones_primeros*posicion+posicion2 <<"lim:" <<total_distribuciones; //
  cout <<"\n posicion: " <<posicion <<", pos2: " <<posicion2 <<"condicionante:" <<condicionante <<"dim_cond0: " <<dimensiones_condicionantes[0] <<"dimcom1: " << dimensiones_condicionantes[1]<<"cond0:" <<condicionantes[0] <<", cond1:" <<condicionantes[1];//
  *err=1;//
//  frecuencias::~frecuencias();
exit(0); //
}//
//cout <<"LUGraph:" <<lugar;//
/*if (tabla1.desborde(tamanfrecsampliado*total_distribuciones_primeros, lugar*total_distribuciones_primeros+posicion2)!=0) //
{//
cout << "tabla1.desborde6";//
*err=1;//
//frecuencias::~frecuencias();
exit(0); //
} //
*/
comprobar (base, (lugar*total_distribuciones_primeros)+posicion2, tamanfrecsampliado*total_distribuciones_primeros, (char*)"fb");


 *(base+(lugar*total_distribuciones_primeros)+posicion2)=*(base+(lugar*total_distribuciones_primeros)+posicion2)+1;   //
}//fin para cada patron//


 if (condicionante==0)//
  (*(frecs)).condicionante=taman_fichero_missing;//


}//
///////////
int frecuencias::buscarlugar (unsigned int mod_condicionante) //
{//
// entrada: la posici�n lineal de la configuraci�n de variables condicionantes
// cuando hay muchas variables condicionantes comparado con el tama�o
// del fichero, hay que usar la zona de desbordamientos
//devueve el lugar si se encuentra, aunque sea en desbordamiento//
//devuelve -1 si est  ocupada por otro y no se encuentra tampoco en zona de desbordamiento//
//devuelve -2 si est  libre //
   int lugar, desplazamiento, encontrado=0;//
//cout <<"tamanfrecs" <<tamanfrecs;//
//   frecuencias::~frecuencias(); exit(0);//
   lugar=mod_condicionante%tamanfrecs;//
// si tamanfrecs es el total de configuraciones condicionantes, lugar=mod_condicionante
// si es el tama�o del fichero, lugar devuelve un n�mero entre 0 y tamanfichero-1
//   cout <<"lugar:" << lugar;//
//   frecuencias::~frecuencias(); exit(0);//
   desplazamiento=desbordamiento;//
//   cout <<"-------:" <<lugar<<"modcond:" <<(*(frecs+lugar)).posicion<< //
//   "frecs:" <<(*(frecs+lugar)).condicionante;//
// quitado el if 14 -5-2003
// no se debe producir nunca lugar>tamanfrecsampliado pues lugar<tamanfrecs por
// ser mod_condicionante%tamanfrecs y tamanfrecsampliado es 8 veces mayor que
// tamanfrecs
//   if (tabla1.desborde(tamanfrecsampliado,lugar)==0) //
//   {//
// 
    if ((*(frecs+lugar)).posicion==-1) //
    lugar=-2;//
    else //
   {//
//   cout <<"POS:" <<(*(frecs+lugar)).posicion <<", modcond:" << mod_condicionante//
//   << "condi:" << (*(frecs+lugar)).condicionante  <<", lugar:" << lugar;//
    if (((*(frecs+lugar)).posicion!=mod_condicionante) && //
    ((*(frecs+lugar)).condicionante!=0)) // si est  ocupada por otro//
    {//
     while ((encontrado==0) && //
     (desplazamiento<topedesbordamiento)) //
      { //
      if (tabla1.desborde(tamanfrecsampliado,desplazamiento)==0) //
       {//
        if ((*(frecs+desplazamiento)).posicion==mod_condicionante) //
         {//
          encontrado=1;//
          lugar=desplazamiento;//
//        cout <<"EEEEEEEEEEEE:" <<lugar;//
         }//
         desplazamiento=desplazamiento+1;//
       }//
      else
      {
      cout << "tabla1.desbordex";
      exit(0);
      }//
      } //fin while//
     if (encontrado==0) //
      {//
//      cout <<"desp:" << desplazamiento <<", topedeb:" <<topedesbordamiento;//
      lugar=-1;//ocupada por otro y no se encuentra//
      }//
//   cout <<"lllllll:" <<lugar;//
   }//
    }// fin else
//   }//
//   else {cout <<"tabla1.desborde7";
//   exit(0);} //
//cout <<"LUGraphGGGG:"<<lugar;//
return(lugar);  //
}//
/////////

////////////////////
unsigned int frecuencias::error()//
{//
unsigned int mod_condicionante, mod_primero, patron, i, posicion, errores=0;//
int lugar;//
unsigned int Errores=0;//
tabla1.iniciar(0, condicionante, indices_condicionantes);//
tabla1.iniciar(0, primero, indices_primeros);//
for (patron=0;patron<taman_fichero;patron++)//
 if (patronborrado[patron]==0) //
  if (((marcado[patron]!=tipo) && (tipo=='p')) || (tipo=='t'))//
{  //
 for(i=0; i<condicionante; i++)//
 {//
 
 comprobar (condicionantes,i,condicionante, (char*)"f20"); 
 comprobar (atributos, condicionantes[i], total_atributos, (char*)"f21");
 comprobar (patrones,patron*total_atributos+condicionantes[i],taman_fichero*total_atributos, (char*)"f22"); 
 comprobar (indices_condicionantes,i, condicionante, (char*)"f23");
 indices_condicionantes[i]=intervalo(patrones[patron*total_atributos+condicionantes[i]], condicionantes[i], *(atributos+condicionantes[i]));//
  if (indices_condicionantes[i]>=atributos[condicionantes[i]].total_modalidades) //
  {//
   cout <<"Errorerr, valor fuera de rango";//
   //frecuencias::~frecuencias();
   exit(0);//
  } //
 }// fin para cada i//
 for(i=0; i<primero; i++)//
 {//
 
 comprobar (primeros,i,primero, (char*)"f24"); 
 comprobar (atributos, primeros[i], total_atributos, (char*)"f25");
 comprobar (patrones,patron*total_atributos+primeros[i],taman_fichero*total_atributos, (char*)"f26"); 
 comprobar (indices_primeros,i, primero, (char*)"f27");
 indices_primeros[i]=intervalo(patrones[patron*total_atributos+primeros[i]], //
   primeros[i], *(atributos+primeros[i]));//
  if (indices_primeros[i]>=atributos[primeros[i]].total_modalidades) //
  {//
   cout <<"Errorerror1, valor fuera de rango";//
   //frecuencias::~frecuencias();
   exit(0);//
  } //
 } // fin para cada i//
  if (condicionante!=0)//
  { //
   mod_condicionante=tabla1.obtener_posicion(indices_condicionantes, //
                       dimensiones_condicionantes, condicionante);//
 if (mod_condicionante>=total_distribuciones_condicionantes) //
  {//
   cout <<"Errore2, valor fuera de rango";//
//   *err=1;//
  } //
  else //
  {//
  lugar=buscarlugar(mod_condicionante); //
  if (lugar<0) {cout <<"Errora"<<",patron:" <<patron <<"modconds:" <<mod_condicionante<<",lugar:" <<lugar;
  //frecuencias::~frecuencias();
  exit(0);} //
  } //
  }//
  else //
  {//
  mod_condicionante=0;//
  lugar=0;//
  }//
  if (mod_condicionante>=total_distribuciones_condicionantes) //
  {//
   cout <<"Errorerror2, valor fuera de rango";//
   //frecuencias::~frecuencias();
   exit(0);//
  } //
 mod_primero=tabla1.obtener_posicion(indices_primeros, dimensiones_primeros,//
                        primero);////
 if (mod_primero>=total_distribuciones_primeros) //
  {//
   cout <<"Errorerror3, valor fuera de rango";//
   //frecuencias::~frecuencias();
   exit(0);//
  } //
// cout <<"modclase:" << mod_primero;//
 if ((*(frecs+lugar)).condicionante!=0) //
 {//
    posicion=tabla1.maximo((unsigned int)total_distribuciones_primeros,  //
      base+(lugar*total_distribuciones_primeros));////
    if (posicion!=mod_primero)//
    errores++;//
 }//
 else  errores++;  //
}// fin para cada patr¢n//
//cout <<"riesgo:" <<riesgo <<"ramfich:" <<taman_fichero <<"result:" ;//
//cout << (double)riesgo/(double)taman_fichero;//
//zap indices_condicionantes;
//zap indices_primeros;
return(errores);//
} //

////////////////////
double frecuencias::probcond(unsigned int *patronborrado, //
unsigned int *condicionantes,//
float *patrones, char *marcado,
struct atributo *atributos, unsigned int *primeros)//

// no se usa




{//
unsigned int mod_condicionante, mod_primero, patron, i; //
int lugar;//
double riesgo;//
/*unsigned int *indices_condicionantes, *indices_primeros; //
if ((indices_condicionantes=new unsigned int[condicionante])==NULL)
{
cout <<"falta memoria";
exit(0);
};//
if ((indices_primeros = new unsigned int [primero])==NULL)
{
cout <<"falta memoria";
exit(0);
};//
*/
tabla1.iniciar(0, condicionante, indices_condicionantes);//
tabla1.iniciar(0, primero, indices_primeros);//
riesgo=0;//
for (patron=0;patron<taman_fichero;patron++)//
if (patronborrado[patron]==0) //
if (((marcado[patron]!=tipo) && (tipo=='p')) || (tipo=='t'))//
{//
 for(i=0; i<condicionante; i++)//
 {
 comprobar (condicionantes,i,condicionante, (char*)"f28"); 
 comprobar (atributos, condicionantes[i], total_atributos, (char*)"f29");
 comprobar (patrones,patron*total_atributos+condicionantes[i],taman_fichero*total_atributos, (char*)"f30"); 
 comprobar (indices_condicionantes,i, condicionante, (char*)"f31");
 indices_condicionantes[i]=intervalo(patrones[patron*total_atributos+condicionantes[i]],//
   condicionantes[i], *(atributos+condicionantes[i]));//
}
 for(i=0; i<primero; i++)//
 {
 comprobar (primeros,i,primero, (char*)"f32"); 
 comprobar (atributos, primeros[i], total_atributos, (char*)"f33");
 comprobar (patrones,patron*total_atributos+primeros[i],taman_fichero*total_atributos, (char*)"f34"); 
 comprobar (indices_primeros,i, primero, (char*)"f35");
  indices_primeros[i]=intervalo(patrones[patron*total_atributos+primeros[i]], primeros[i], //
  *(atributos+primeros[i]));//
 }
 mod_condicionante=tabla1.obtener_posicion(indices_condicionantes, dimensiones_condicionantes, condicionante);////
 mod_primero=tabla1.obtener_posicion(indices_primeros, dimensiones_primeros, primero);////
 lugar=buscarlugar(mod_condicionante);//
 if (lugar<0) {cout <<"Errorb";
 //frecuencias::~frecuencias();
 exit(0);} //
 if ((*(frecs+lugar)).condicionante!=0)//
 riesgo=riesgo+log((double)*(base+(lugar*total_distribuciones_primeros)+mod_primero) / //
 (double)(*(frecs+lugar)).condicionante)/(double) taman_fichero_missing;//
} //
//zap indices_condicionantes;
//zap indices_primeros;
return(-(double)riesgo);//
}   //
/////////
unsigned int frecuencias::obtener_base(unsigned int mod_primero, unsigned int //
mod_condicionante) //
{ //
int lugar;//
lugar=frecuencias::buscarlugar(mod_condicionante);//
//frecuencias::~frecuencias();
//exit(0);//
if (lugar>=0)//
return(*(base+lugar*total_distribuciones_primeros+mod_primero));//
else//
return (0);//
}   //
/////////
unsigned int frecuencias::obtener_total_condicionantes (int posicion) //
{ //
int lugar;//
lugar=buscarlugar(posicion); //
if (lugar==-1) return(0); //
else return((*(frecs+lugar)).condicionante);//
}   //
/////////
int frecuencias::obtener_total_distribuciones_condicionantes (void) //
{ //
return(total_distribuciones_condicionantes);//
}   //
////
//unsigned int* frecuencias::obtener_dimensiones_condicionantes (void) //
//{ //
//return (dimensiones_condicionantes);//
//}   //
////
