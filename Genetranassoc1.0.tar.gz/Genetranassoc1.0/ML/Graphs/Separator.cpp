/* File: Separator.h */


#ifndef __Separator_cpp__
#define __Separator_cpp__


using namespace std;


namespace BIOS
{


  /************************/
  /* EnrichedDirectedArc DEFINITION */
  /************************/


  /**
          @memo EnrichedDirectedArc 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */

// We wanted to use:
//template <class T>  typedef typename EnrichedDirectedArc<T, SeparatorContent> DirectedSeparator<T>;
//  template <class T>  EnrichedUndirectedArc<T, SeparatorContent>  UndirectedSeparator<T>;
// As Template Typedef is not allowed we use this trick


 

}
;  // Fin del Namespace

#endif

/* Fin Fichero: EnrichedDirectedArc.h */
