/* File: DAG.h */


#ifndef __DAG_h__
#define __DAG_h__






//using namespace UTILS;


namespace BIOS
{



    /*_______________________________________________________________*/

//  template <>
// AcyclicGraph<UndirectedArc, T, U>* getUGraph()
//template<>  UTree<Node*,Node*>::Class* DAG<Node*, Node*>::Class::getUGraph()
//
//template <template<class T, class U> class Link, class T, class U> 
//template <template<class V, class W> class ULink, class V, class W> 

//AcyclicGraph<ULink, T, U>*  AcyclicGraph<Link, T, U>::getUGraph()

template<class T, class U>  
template<class V, class W> 
   typename UTree<T, U>::Class* DAG<T, U>::Class::getUGraph()
 {
      AcyclicGraph<ULink, T, U> *uG = new AcyclicGraph<ULink, T, U>();
      uG->nodes=this->nodes;
      uG->copyArcs(this);
       return uG;
    }

   /*_______________________________________________________________*/
	/*

template <template<class T> class DLink, class T>
template <template<class U> class ULink, class U>
UGraph<ULink, T>* DAG<DLink, T>::getMoralGraph()
    {
     UGraph<ULink, T> *moralGraph =this->getUGraph();
     typename Set<T>::iterator p=this->nodes->getFirst();
      Set<T>* nodeParents=NULL;
        while (p!=NULL)
      {
         nodeParents = this->getParents(p);
	//cout <<"\nparents for node" << this->nodes->getElement(p)->print() <<" are :" << nodeParents->print();
        moralGraph->complete(nodeParents);
        zap(nodeParents);
        p=this->nodes->getNext(p);
      }
     // cout <<moralGraph->print();
    //  end();
          return moralGraph;

    }
   /*_______________________________________________________________*/

  }
;  // Fin del Namespace

#endif

/* Fin Fichero: DAG.h */
