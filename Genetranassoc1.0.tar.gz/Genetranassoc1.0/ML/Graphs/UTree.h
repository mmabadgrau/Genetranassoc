/* File: UTree.h */


#ifndef __UTree_h__
#define __UTree_h__

namespace BIOS
{
  /************************/
  /* UTree DEFINITION */
  /************************/
  /**
          @memo UTree 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */





// We wanted to use:
//template <class T>  typedef typename SingleAncestorGraph<UndirectedArc, T> UTree<T>;
// As Template Typedef is not allowed we use this trick
template<class T, class U=int>
  struct UTree
  {
    typedef SingleAncestorGraph<UndirectedArc, T, U> Class;
  };

typedef UTree<Node*, int>::Class SimpleUTree;



};  // Fin del Namespace

#endif

/* Fin Fichero: UTree.h */
