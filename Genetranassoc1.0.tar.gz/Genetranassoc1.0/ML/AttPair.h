#ifndef AttPair_h//
#define AttPair_h//

#include "../commonc++/list.h"

namespace BIOS {



/************************/
/* ListOfLists DEFINITION */
/************************/


/**
        @memo AttPair 

	@doc

    @author Maria M. Abad
	@version 1.0
*/

template <class T> class AttPair {

private:

struct 
{
 int pos;
 T value;
} attPair;

public:

AttPair()
{
attPair.pos=-1;
}


AttPair(int position, T val)
{
attPair.pos=position;
attPair.value=val;
}

AttPair(AttPair<T> *ap)
{
attPair.pos=ap->GetPos();
attPair.value=ap->GetValue();
}


int GetPos()
{
return attPair.pos;
}

T GetValue()
{
return attPair.value;
}

};
}// end namespace
#endif
