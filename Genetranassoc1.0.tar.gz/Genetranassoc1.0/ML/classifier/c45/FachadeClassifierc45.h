#ifndef __FachadeClassifierc45_h__ 
#define __FachadeClassifierc45_h__ 




#include "C45.h"
#endif
