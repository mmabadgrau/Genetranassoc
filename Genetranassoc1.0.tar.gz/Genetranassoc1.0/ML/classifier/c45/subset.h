/* File: subset.h */


#ifndef __subset_h__
#define __subset_h__

//#include "defns.h"// C4.5//
//#include "types.h"//
//#include "c4.5.h"//
//#include "extern.h"//
#include "trees.cpp"//
//#include "trees.cpp"//
//#include "stats.cpp"//



namespace BIOS {
	
/*************************************************************************/// 
/*									 */// 
/*      Evaluation of the subsetting of a discrete attribute		 */// 
/*      ----------------------------------------------------		 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
void ComputeFrequencies(AttributeC45, ItemNo, ItemNo);// 
// 
// 
ItemCount// 
	*Slice1,	/* Slice1[c]    = saved values of Freq[x][c] in subset.c */// 
	*Slice2;	/* Slice2[c]    = saved values of Freq[y][c] */// 
// 
Setc45// 
	**Subset;	/* Subset[a][s] = subset s for att a */// 
// 
short// 
	*Subsets;	/* Subsets[a] = no. subsets for att a */// 
// 
/*************************************************************************/// 
/*									 */// 
/*  Combine the distribution figures of discrete attribute values	 */// 
/*  x and y, putting the combined figures in Freq[x][] and		 */// 
/*  ValFreq[x][], and saving old values in Slice1 and Slice2		 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
   void Combine(DiscrValue x, DiscrValue y, DiscrValue Last); 

// 
/*************************************************************************/// 
/*									 */// 
/*  Restore old class distribution figures of discrete attribute	 */// 
/*  values x and y from Slice1 and Slice2				 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
   void Uncombine(DiscrValue x, DiscrValue y); 

// 
/*************************************************************************/// 
/*									 */// 
/*  Print the values of attribute Att which are in the subset Ss	 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
    void PrintSubset(AttributeC45 Att, Setc45 Ss); 

// 
// 
// 
// 
// 
/*************************************************************************/// 
/*									 */// 
/*  Evaluate subsetting a discrete attribute and form the chosen	 */// 
/*  subsets Subset[Att][], setting Subsets[Att] to the number of	 */// 
/*  subsets, and the Info[] and Gain[] of a test on the attribute	 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
   void EvalSubset(AttributeC45 Att, ItemNo Fp, ItemNo Lp, ItemCount Items, int criterion); 

// 
// 
// 
    void SubsetTest(TreeC45 Node, AttributeC45 Att);

}
#endif
