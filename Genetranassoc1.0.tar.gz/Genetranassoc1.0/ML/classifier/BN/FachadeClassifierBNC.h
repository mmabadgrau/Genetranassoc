#ifndef __FachadeClassifierBNC_h__ 
#define __FachadeClassifierBNC_h__ 

#include "BNC.cpp"
#include "NB.cpp"
#include "TAN.cpp"
#include "AN.cpp"
#include "UAN.cpp"



#endif
