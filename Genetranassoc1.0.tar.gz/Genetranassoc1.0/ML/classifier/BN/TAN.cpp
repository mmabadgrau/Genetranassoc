/* File: TAN.cpp */


#ifndef __TAN_cpp__
#define __TAN_cpp__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

#include "TAN.h"






//using namespace UTILS;


namespace BIOS
{



	/************************/
	/* TAN DEFINITION */
	/************************/


	/**
	        @memo TAN
	 
		@doc
	 
	    @author M. Mar Abad Grau
		@version 1.0
	*/



	/*____________________________________________________________________________________ */

	TAN::~TAN()
	{
		zap ( parentalTree );
	};
	/*____________________________________________________________________________________ */

	void TAN::setParents()
	{

		if ( parents==NULL )
		{
			parents=new intList*[totalAttributes];
			for ( int cont=0; cont < totalAttributes; cont++ ) //
			{
				parents[cont]=new intList();
				if ( cont!=classPosition )
					if ( sample->listOfAttributes->getElement ( cont )->isSelected() )
						parents[cont]->insertElement ( classPosition );
//cout <<"\npar2:" << parents[cont]->getElement((int)0);
			}
   int cont;
			if ( sample->listOfAttributes->getTotalSelectedAttributes() >2 )
			{
				if (parentalTree==NULL)	setParentalTree();
				for ( NodeSet::iterator it=parentalTree->nodes->begin(); it!=parentalTree->nodes->end(); it++ )
				{
					cont=parentalTree->nodes->getElement ( it )->getValue();
					if ( sample->listOfAttributes->getElement ( cont )->isSelected() )
						if ( parentalTree->getRoot() !=it )
							if ( getSecondParent ( it ) !=parentalTree->nodes->end() )
								parents[cont]->insertElement ( parentalTree->nodes->getElement ( getSecondParent ( it ) )->getValue() );
				}
			}
		}
	};

	/*____________________________________________________________________________________ */

	NodeSet::iterator TAN::getSecondParent ( NodeSet::iterator it )
	{
		//if  (parentalTree->getParent(att)==-1) {cout <<"error in TAN::getSecondParent for att " << att; cout <<"root: " << parentalTree->getRoot(); cout <<"tree" << parentalTree->print(); exit(0);};
		return parentalTree->getParent ( it );

	}

	/*____________________________________________________________________________________ */

	void TAN::setParentalTree()
	{
		SimpleCompleteUG* mutualConditionalInformation=NULL;
		mutualConditionalInformation=this->getMutualConditionalInformation();
//cout << "mutkis: " << *mutualConditionalInformation << "\n";
//cout << "next\n";


SimpleUTree *mwst=mutualConditionalInformation->getMWST(); // maximum weight spanning tree
zap ( mutualConditionalInformation );
//cout << "mwst is: " << *mwst << "\n";
parentalTree=new SimpleTree();
mwst->getDirectedTree(mwst->getFirstElement()->getFirst(), (SimpleTree*)parentalTree);
//cout << "parentalTree is: " << *parentalTree << "\n";
//exit(0);
		if ( parentalTree->size() ==0 ) { cout <<"ERRR in TAN::setParentalTree"; end();}
//cout << "resul:" << *parentalTree <<  "\n";
//exit(0);
	}
	/*____________________________________________________________________________________ */
	/*
	  void TAN::getOrder(UTree<Arc<Node>, Node>* mWST)
	  {
	    orderedAttributes=new Set<Node>();
	    UTree<Arc<Node>, Node>::iterator p=mWST->getFirst();
	    Arc<Node>* arc;
	    while (p!=NULL)
	    {
	      arc=mWST->getElement(p);
	      orderedAttributes->insertElement(mWST->getFirst(arc));
	      orderedAttributes->insertElement(mWST->getSecond(arc));
	      p=mWST->getNext(p);
	    };
	    if (orderedAttributes->size()!=totalSelectedAttributes-1)
	    {
	      cout <<"Error in TAN::getOrder(), only " <<orderedAttributes->size() <<" attributes out of " <<totalSelectedAttributes-1  << " has been found";
	      end();
	    };
	  }

	  /*____________________________________________________________________________________ */

	SimpleCompleteUG* TAN::getMutualConditionalInformation()
	{
		// It computes a complete undirected graph with weights representing mutualconditionalinformation
		//  between x and y given the class (z).
		SimpleCompleteUG* mutualConditionalInformation=new SimpleCompleteUG();
		floatList* weights=NULL;
  NodeList* nodeList=NULL;
		intList *x=NULL, *y=NULL, *z=new intList();
		z->insertElement ( classPosition );
		Attribute* attribute1=NULL, *attribute2=NULL;
		Node* node=NULL;
		for ( int cont=0; cont < totalAttributes; cont++ ) //
			if ( cont!=classPosition )
				if ( sample->listOfAttributes->getElement ( cont )->isSelected() )
				{
					weights=new floatList();
     nodeList=new NodeList();
					x=new intList();
					x->insertElement ( cont );
					for ( int cont2=0; cont2 < cont; cont2++ ) //
						if ( cont2!=classPosition )
							if ( sample->listOfAttributes->getElement ( cont2 )->isSelected() )
							{
								y=new intList();
								y->insertElement ( cont2 );
//cout << "\nx: " << *x <<",  y: " << *y <<" and z:" << *z; //, alpha, NULL, NULL);
        nodeList->insertElement(new Node(cont2));
								weights->insertElement ( discreteSample->getMutualInformation ( x,y,z ) );
								zap ( y );
							} // end for
					zap ( x );
					node=new Node ( cont );
//cout << "node to be inserted: " << *node << "and weights: " << *weights << "\n";
					mutualConditionalInformation->insertNode ( node, weights, nodeList );
			//		zap ( node );
					zap ( weights );
				} // end if-for
		zap ( z );
		return mutualConditionalInformation;
	}
	/*____________________________________________________________________________________ */
	/*
	  TAN::TAN()
	  {
	    //TAN<T>::setClassifier();

	    //parents=Initialize(ClassAttribute::GetModalidades(), NULL);
	  }

	  /*____________________________________________________________________________________ */

	void TAN::set()
	{
parentalTree=NULL;
		setParents();
		GBN::set();
		if ( GBN::verbosity!=NULL && GBN::verbosity->verbosityR.parameters ) printProbabilityTables();
//printProbabilityTables();




		if ( !directMethod )
			undirectedBN->setJunctionTreeTAN ( classPosition );
//undirectedBN->setJunctionTreeTAN();
//NB<T>::setClassifier();
//parents=Initialize(ClassAttribute::GetModalidades(), NULL);
	}
	/*____________________________________________________________________________________ */

	void TAN::setParents2()
	{

		if ( parents==NULL )
		{
			parents=new intList*[totalAttributes];
			for ( int cont=0; cont < totalAttributes; cont++ ) //
			{
				parents[cont]=new intList();
				if ( cont!=classPosition )
					if ( sample->listOfAttributes->getElement ( cont )->isSelected() )
						parents[cont]->insertElement ( classPosition );
//cout <<"\npar2:" << parents[cont]->getElement((int)0);
			}
		}
	};

	/*____________________________________________________________________________________ */

	TAN::TAN ( floatMLSample* sample, int classPosition, floatList* algorithm, VerbosityClass* verbosity, LossFunction* lossFunction ) : BNC ( sample, classPosition, algorithm, verbosity, lossFunction )
	{
		set();
//parentalTree=NULL;
		//  orderedAttributes=NULL;
//setParents();

//    if (sample->listOfAttributes->getTotalSelectedAttributes()>2)
		//    setParentalTree();
//cout << *parentalTree;
//setParents2();
//    BNC::set();


//      BN:set();

		// printParents();
	}
	/*____________________________________________________________________________________ */

	TAN::TAN() : BNC()
	{

	}
	/*___________________________________________________________ */

	string TAN::print()
	{
		char line[50];
		sprintf ( line, "TAN with alpha=%0.2f", alpha );
		return string ( line );
	}

}
;  // Fin del Namespace

#endif

/* Fin Fichero: TAN.h */
