/* File: BNC.h */


#ifndef __BNC_h__
#define __BNC_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

//#include "../../commonc++/rational.cpp"
//#include "../ProbabilityTable.h"
//#include "../Attribute.cpp"







//using namespace std;

namespace BIOS {


/************************/
/* BNC DEFINITION */
/************************/


/**
        @memo BNC 

	@doc

    @author Maria Mar Abad Grau
	@version 1.0
*/


	 class BNC: public Classifier, public GBN {

	protected:

	  intList* getDiscretePattern(floatList* inputPattern, int totalClasses);

   	
	//	virtual void set();

 //float getSNPDistance(int att);

    void printCommonColumns(int att, int r, int totalRows);
    void printHasParents(int att, int r);
    void printHeading(int att);
    void printBody(int att);
    void printProbabilityTables();


 	//void extractDistancesVector();
 
 //void extractDistancesVector(floatList* parameterList, int firstPosition);

      public:


  		 BNC();

		BNC(floatMLSample* sample, int classPosition, floatList* algorithm, VerbosityClass *verbosity, LossFunction* lossFunction);

		 virtual ~BNC();

	 double* getClassFrequencies(floatList* inputPattern); 


	
};  // End of class BNC



};  // Fin del Namespace

#endif

//#include "BNC.cpp"
/* Fin Fichero: BNC.h */
