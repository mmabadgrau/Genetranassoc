/* File: NB.h */


#ifndef __NB_h__
#define __NB_h__







//using namespace UTILS;


namespace BIOS {



/************************/
/* NB DEFINITION */
/************************/


/**
        @memo NB 

	@doc

    @author Maria M. Abad
	@version 1.0
*/


	class NB: public BNC {

	


	      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:

		  NB();
		  
  		  NB(char filename[256], intList* parameterList);

		  NB(floatMLSample* sample, int classPosition, floatList* parameterList, VerbosityClass* verbosity, LossFunction* lossFunction);

		  virtual ~NB();
		  
		  void set (floatMLSample* sample, int classPosition, floatList* parameterList);

		  void set();

		  
		  char* print();
     private:		  

		  void setParents();
		  
		  void setParents(floatList* algorithm);

	//	 int GetClass(list<T>* inputPattern){return NB<T>::GetClass(inputPattern);};


};  // End of class NB


};  // Fin del Namespace

#endif

//#include "NB.cpp"

/* Fin Fichero: NB.h */
