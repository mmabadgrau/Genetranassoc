/* File: AdditiveClassifier.cpp */

#ifndef __AdditiveClassifier_cpp__
#define __AdditiveClassifier_cpp__




//using namespace UTILS;


namespace BIOS {


void AdditiveClassifier::set(floatList* parameterList, DistanceMethodClass* distanceMethodClass)
{
//int totalAttributos=sample->listOfAttributes->size();
	k=1;
  if (distanceMethodClass==NULL)
  	this->distanceMethodClass=new DistanceMethodClass(SqRoot, squareDifference);
else this->distanceMethodClass=new DistanceMethodClass(*distanceMethodClass);
        weight=false;
	if (parameterList!=NULL && parameterList->size()>0) k=(int)parameterList->getFirstElement();
if (parameterList!=NULL && parameterList->size()>1) weight=parameterList->getElement(1);
//extractDistancesVector();
//setWeightsVector();
//end();
};
/*____________________________________________________________________________________ */
/*
void AdditiveClassifier::setWeightsVector()
{
float distance;
switch (distanceMethod)
{
case PhysicalDistance:
if (distancesVector->getElement(classPosition)==-1) break;
else
{
weightsVector=new floatList();
for (int i=0;i<totalAttributes;i++)
{
if (distancesVector->getElement(i)!=-1)
{
distance=-1*fabs(distancesVector->list<float>::getElement((int)i)-distancesVector->list<float>::getElement((int)classPosition))/(float)100000;
weightsVector->insertElement(exp(distance));
}
else weightsVector->insertElement(1);
}
}
break;
default: break;
}

}


/*____________________________________________________________________________________ */

/*
 void AdditiveClassifier::extractDistancesVector()
{
if (distanceMethod==PhysicalDistance)
 if (parameterList->size()!=(2+totalAttributes))
{
cout <<"Error in AdditiveClassifier::set(parameterList), physical positions not found in " << *parameterList << "\ntotal is : " << parameterList->size() << " and the total number of attributes is: " << totalAttributes;
end();
}
else Classifier::extractDistancesVector(2);
}

/*____________________________________________________________________________________ */
/*
AdditiveClassifier::AdditiveClassifier(char* filename, floatList* parameterList):Classifier(filename)
{	
set(parameterList);
};

/*____________________________________________________________________________________ */

AdditiveClassifier::AdditiveClassifier(floatMLSample* sample, int att, floatList* parameterList, DistanceMethodClass* distanceMethodClass, VerbosityClass* verbosity, LossFunction* lossFunction):Classifier(sample, att, parameterList, verbosity, lossFunction)
{	
set(parameterList, distanceMethodClass);
};

/*____________________________________________________________________________________ */

AdditiveClassifier::AdditiveClassifier(floatList* parameterList, DistanceMethodClass* distanceMethodClass)
{
set(parameterList, distanceMethodClass);	
};

/*____________________________________________________________________________________ */

AdditiveClassifier::~AdditiveClassifier()
{
zap(distanceMethodClass);
//zap(weightsVector);
};
/*____________________________________________________________________________________ */

double* AdditiveClassifier::getFrequencies(KElementVector * kList)
{
int pos;
double *classFrequencies=new double[totalClasses];
int *classAbsoluteFrequencies=new int[totalClasses];
InitializeList(classAbsoluteFrequencies, totalClasses, 0);
KElementVector::iterator p=kList->getFirst();
while (p!=kList->end())
{
pos=kList->getElement(p)->GetClas();
if (pos<0 || pos>=totalClasses)
throw OutOfBounds(pos, totalClasses, "AdditiveClassifier::getFrequencies(KElementVector * kList)");
classAbsoluteFrequencies[pos]++;
p=kList->getNext(p);
};
for (int i=0;i<totalClasses;i++)
classFrequencies[i]=classAbsoluteFrequencies[i]/(double)kList->size();
zaparr (classAbsoluteFrequencies);
return classFrequencies; //GetMaxPos(classFrequencies, size);
}

 /*___________________________________________________________ */

double* AdditiveClassifier::getClassFrequencies(floatList* targetInputPattern)  
{
try
{
 KElementVector * kList=sample->getKClosestPatterns(targetInputPattern, k, distanceMethodClass, true, true, true, classPosition, targetInputPattern->size());
if (verbosity->verbosityR.structure)
cout <<*kList;// <<"\n";
double* frequencies=getFrequencies(kList);
//cout <<"totale:" << kList->size();
// end();
zap(kList);
return frequencies;//
}
catch (OutOfRange<int>& ore){ore.addMessage("\ncalled from AdditiveClassifier::getClassFrequencies"); throw;}
catch (BadFormat& bf){bf.addMessage("\ncalled from AdditiveClassifier::getClassFrequencies"); throw;}
};

 
/*___________________________________________________________ */
/*
double* AdditiveClassifier::GetClassFrequencies(floatList* targetInputPattern)
{

 floatList *inputPattern=NULL;
 long int cont=0;
 
 floatSample::iterator p=NULL;
 if (sample!=NULL && sample->sample!=NULL)
 p=sample->sample->getFirst();
 else throw NullValue("AdditiveClassifier::GetClassFrequencies");
 KElement *kElement=NULL;
 ListOfPointers<KElement> * kList= new ListOfPointers<KElement>();
 ListOfPointers<KElement>::iterator pk=NULL;
 int maxClass;
 while (p!=NULL)
 {
  kElement=new KElement();
  inputPattern=new floatList(*sample->sample->getElement(p));
  kElement->SetClas((int)inputPattern->removeNode(classPosition));
  kElement->SetDistance(sample->listOfAttributes->getDistance(inputPattern, targetInputPattern, true, distanceMethod, classPosition));
  kElement->SetElementPos(cont);
  pk=kList->GetClosestGreaterPointerToElement(kElement, false);
  kList->insertElementAtPointer(kElement, pk);
  zap(kElement);
  zap(inputPattern);

  if (kList->size()>k)
  {
   kElement=kList->Pop();
   zap(kElement);
  }

   p=sample->sample->getNext(p);
   cont++;
 }; // end while
double* frequencies=getFrequencies(kList);

zap(kList);

return frequencies;//
};
*/
/*___________________________________________________________ */

char* AdditiveClassifier::print()
{
sprintf(line, "AdditiveClassifier with k=%d", k);
return line;
}



};  // Fin del Namespace

#endif

/* Fin Fichero: AdditiveClassifier.cpp */
