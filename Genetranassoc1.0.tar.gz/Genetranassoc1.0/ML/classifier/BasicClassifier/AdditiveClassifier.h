/* File: AdditiveClassifier.h */

#ifndef __AdditiveClassifier_h__
#define __AdditiveClassifier_h__



//using namespace UTILS;


namespace BIOS {



class AdditiveClassifier: public Classifier
{
public:

doubleList* weights;

//floatList* weightsVector;
//void set(floatList* parameters);

  void set(floatList* parameterList=NULL, doubleList* weights=NULL);


public:

AdditiveClassifier(floatList* parameterList=NULL, DistanceMethodClass* distanceMethodClass=NULL);


AdditiveClassifier(char* filename, floatList* parameterList, DistanceMethodClass* distanceMethodClass=NULL);

AdditiveClassifier(floatMLSample* sample, int att, floatList* parameterList=NULL, DistanceMethodClass* distanceMethodClass=NULL, VerbosityClass *verbosity=NULL, LossFunction* lossFunction=NULL);

	
~AdditiveClassifier();

double* getClassFrequencies(floatList* targetInputPattern);

double* getFrequencies(KElementVector* kList);


char* print();
};



ostream& operator<<(ostream& out, AdditiveClassifier& AdditiveClassifier)
       {

out << (Classifier&)AdditiveClassifier;
out <<"k is " << AdditiveClassifier.k << "\n";
out <<"weight is " << AdditiveClassifier.weight <<"\n";
out <<*AdditiveClassifier.distanceMethodClass;
};









};  // Fin del Namespace

#endif

//#include "AdditiveClassifier.cpp"
/* Fin Fichero: AdditiveClassifier.h */
