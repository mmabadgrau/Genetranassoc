#ifndef __FachadeClassifierAC_h__ 
#define __FachadeClassifierAC_h__ 



#include "AdditiveClassifier.h"
#endif
