#ifndef __FachadeClassifierACC_h__ 
#define __FachadeClassifierACC_h__ 



#include "AdditiveClassifier.cpp"
#endif
