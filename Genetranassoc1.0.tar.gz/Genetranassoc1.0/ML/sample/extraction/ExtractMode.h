#ifndef __SelMode_h__
#define __SelMode_h__


namespace BIOS {

typedef enum SelMode {
	Todos=0,
	InclusionSRM=1, //filter
	InclusionERM=2, //filter
	manual = 3,
	treeWrapper = 4,
	InclusionWrapper=5
};

}

#endif
