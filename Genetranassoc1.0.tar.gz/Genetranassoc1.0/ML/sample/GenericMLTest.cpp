#ifndef GenericMLTest_cpp//
#define GenericMLTest_cpp//






//using namespace UTILS;

namespace BIOS
{

	GenericMLTest::GenericMLTest ( char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, int jointRows )
	{
		try
		{
			char timestr[256];
			struct timeval  tv;
			gettimeofday ( &tv, NULL );
			sprintf ( timestr, "%u.%06u", tv.tv_sec,  tv.tv_usec );
			timeMark=string ( timestr );

			this->internalTestMod=internalTestMod->clone();
			this->externalTestMod=externalTestMod->clone();


			// if (testMod->tm==tHalfTraining && testModeForInsideMeasure) throw BadFormat("GenericMLTest::GenericMLTest (char* fileSample, TestModeClass *testMod, int jointRows, bool testModeForInsideMeasure)");
//cout <<testMod->numberOfFolds <<"\n";
			fileName=new char[256];
			strcpy ( fileName,fileSample );
//this->pos=pos;
			this->size=0;
			totalAtts=GenericSample::divideSample ( timeMark, fileSample, internalTestMod, externalTestMod, jointRows );


			internalSamplesForTraining=NULL;
			internalSamplesForTest=NULL;
			wholeInternalSamples=NULL;
			externalSamples=NULL;
			genericInternalCountsForTraining=NULL;
			genericInternalCountsForTest=NULL;
			genericExternalCounts=NULL;
			wholeInternalCounts=NULL;
		}
		catch ( BasicException & be ) {be.addMessage ( "\ncalled from  GenericMLTest::GenericMLTest (char* fileSample, TestModeClass *testMod, int jointRows)" ); throw; };
	}

	/*___________________________________________________________ */

	int GenericMLTest::getSize()
	{
		if ( size==0 ) setSize();
		if ( size==0 ) throw NullValue ( "void  GenericMLTest::getSize()" );
		return size;
	}

	/*___________________________________________________________ */

	GenericMLTest::~GenericMLTest()
	{
		emptyCounts();
//cout <<"numberof folds:" << testMod->numberOfFolds <<"\n";
//for (int i=0; i<testMod->numberOfFolds; i++)
//{
//cout <<"zap i:" << i <<"\n";
//zap(samplesForTraining);
//}
//cout <<*testMod <<"\n";
		for ( int i=0; i<externalTestMod->numberOfFolds; i++ )
		{
			zaparr ( internalSamplesForTraining[i], internalTestMod->numberOfFolds );
			zaparr ( internalSamplesForTest[i], internalTestMod->numberOfFolds );
		}
		zaparr ( internalSamplesForTraining, externalTestMod->numberOfFolds );
		zaparr ( internalSamplesForTest, externalTestMod->numberOfFolds );
		zaparr ( wholeInternalSamples, externalTestMod->numberOfFolds );
		zaparr ( externalSamples, externalTestMod->numberOfFolds );

		zaparr ( fileName );
		zap ( internalTestMod );
		zap ( externalTestMod );
	}
	/*___________________________________________________________ */

	void GenericMLTest::emptyCounts()
	{
		for ( int i=0; i<externalTestMod->numberOfFolds; i++ )
		{
			if ( genericInternalCountsForTraining != NULL )
				zaparr ( genericInternalCountsForTraining[i], internalTestMod->numberOfFolds );
			if ( genericInternalCountsForTest != NULL )
				zaparr ( genericInternalCountsForTest[i], internalTestMod->numberOfFolds );
		}
		zaparr ( genericInternalCountsForTraining, externalTestMod->numberOfFolds );
		zaparr ( genericInternalCountsForTest, externalTestMod->numberOfFolds );
		zaparr ( wholeInternalCounts,  externalTestMod->numberOfFolds );
		zaparr ( genericExternalCounts,  externalTestMod->numberOfFolds );
	}
	/*___________________________________________________________ */

	GenericCounts*** GenericMLTest::getGenericInternalCountsForTraining()
	{
		return genericInternalCountsForTraining;
	}
	/*___________________________________________________________ */

	GenericCounts*** GenericMLTest::getGenericInternalCountsForTest()
	{
		return genericInternalCountsForTest;
	}
	/*___________________________________________________________ */

	GenericCounts** GenericMLTest::getGenericExternalCounts()
	{
		return genericExternalCounts;
	}
	/*___________________________________________________________ */

	int GenericMLTest::getRealNumberOfAtts()
	{
		return totalAtts;
	}
	/*___________________________________________________________ */

	void GenericMLTest::setSize()
	{
//defaultPositions=true;
		this->size=getRealNumberOfAtts();
//this->pos=initializeFrom(0, size);
	}
	/*___________________________________________________________ */

	char* GenericMLTest::getFileName()
	{
//defaultPositions=true;
		return fileName;
//this->pos=initializeFrom(0, size);
	}
	/*___________________________________________________________ */

	void  GenericMLTest::setSubsamples ( int iniPos, int length )
	{
		try
		{
//cout << "insidesubsamples:\n";
//     cout << "externalTestMode: " << *externalTestMod <<"\n";
//     cout << "internalTestMode: " << *internalTestMod <<"\n";
			internalSamplesForTraining=new GenericSample**[externalTestMod->numberOfFolds];
			internalSamplesForTest=new GenericSample**[externalTestMod->numberOfFolds];
			char file[1024];
			string t, t2;
			GenericSample*** genericSamples=NULL, ***genericSubsamples=NULL;
			if ( length==-1 ) length=getSize();
			int* pos=initializeFrom ( iniPos, length );
			wholeInternalSamples=new GenericSample*[externalTestMod->numberOfFolds];
			externalSamples=new GenericSample*[externalTestMod->numberOfFolds];
			char * fileNoPath=NULL;
			//wholeSample=this->getSample ( fileName, pos, length );
			for ( int i=0; i<externalTestMod->numberOfFolds;i++ )
			{
				t=timeMark+string ( "testE" ) +tos ( i );
				t2=timeMark+string ( "datE" ) +tos ( i );
				if ( externalTestMod->tm==tTraining && externalTestMod->fractionOfDefaultTrainingSize==1 && internalTestMod->tm==tTraining && internalTestMod->fractionOfDefaultTrainingSize==1 )
				{
					strcpy ( file, fileName );
					externalSamples[i]=this->getSample ( file, pos, length );
					wholeInternalSamples[i]=this->getSample ( file, pos, length );
				}
				else
				{
//cout << "herrrrr\n";					
changeExtension ( fileName, file,t.c_str() );
					fileNoPath = removeDir ( file );
					externalSamples[i]=this->getSample ( fileNoPath, pos, length );
//cout << "external sample size: "<< externalSamples[i]->size() <<"\n";
					unlink ( fileNoPath );
					zaparr(fileNoPath);
					changeExtension ( fileName, file,t2.c_str() );
					fileNoPath = removeDir ( file );
					wholeInternalSamples[i]=this->getSample ( fileNoPath, pos, length );
//cout << "whole sample size: "<< wholeInternalSamples[i]->size() <<"\n";
					unlink ( fileNoPath );
					delete fileNoPath;
				}
				internalSamplesForTraining[i]=new GenericSample*[internalTestMod->numberOfFolds];
				internalSamplesForTest[i]=new GenericSample*[internalTestMod->numberOfFolds];
				for ( int j=0; j<internalTestMod->numberOfFolds;j++ )
				{
					for ( int k=0; k<2;k++ ) // Training and test
					{
						if ( k==0 ) {t=timeMark+string ( "datE" ) +tos ( i ) +string ( "datI" ) +tos ( j ) ;  genericSamples=internalSamplesForTraining;}
						else {t=timeMark+string ( "datE" ) +tos ( i ) +string ( "testI" ) +tos ( j ) ; genericSamples=internalSamplesForTest;}
							if ( externalTestMod->tm==tTraining && externalTestMod->fractionOfDefaultTrainingSize==1 && internalTestMod->tm==tTraining && internalTestMod->fractionOfDefaultTrainingSize==1 )
						{
							strcpy ( file, fileName );
							genericSamples[i][j]=this->getSample ( file, pos, length );
//cout << "genericSamples size: "<< genericSamples[i][j]->size() <<"\n";

						}
						else
						{
							changeExtension ( fileName, file,t.c_str() );
							fileNoPath = removeDir ( file );
							genericSamples[i][j]=this->getSample ( fileNoPath, pos, length );
//cout << "genericSamples size: "<< genericSamples[i][j]->size() <<"\n";
							unlink ( fileNoPath );
							zaparr(fileNoPath);
						}
					}
				}

			}
			zap ( pos );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void  GenericMLTest::setSubsamples(int* pos, int length) " ); throw;};

	}


	/*___________________________________________________________ */

	void  GenericMLTest::setGenericCounts ( int* pos, int length )
	{

		try
		{
			if ( pos==NULL ) throw NullValue ( "void  GenericMLTest::setGenericCounts(int* pos, int length)" );
			if ( genericInternalCountsForTraining!=NULL || genericInternalCountsForTest!=NULL || wholeInternalCounts!=NULL ) emptyCounts();
			genericInternalCountsForTraining=new GenericCounts**[externalTestMod->numberOfFolds];
			genericInternalCountsForTest=new GenericCounts**[externalTestMod->numberOfFolds];
			wholeInternalCounts=new GenericCounts*[externalTestMod->numberOfFolds];
			genericExternalCounts=new GenericCounts*[externalTestMod->numberOfFolds];
			//cout <<"sample size is " << ((VectorOfParentalGenotypes*)wholeSample)->size() <<"\n";
			//cout <<"whole sample is: " << *wholeSample <<"\n";
			GenericCounts*** genericCounts=NULL;
			GenericSample*** samples=NULL;
			for ( int i=0; i<externalTestMod->numberOfFolds;i++ )
			{
//if (wholeInternalSamples==NULL || wholeInternalSamples[i]==NULL) cout <<"error, null\n";
//BIOS::print(pos, length);
				wholeInternalCounts[i]=this->getCounts ( wholeInternalSamples[i], pos, length );
				genericExternalCounts[i]=this->getCounts ( externalSamples[i], pos, length );
				genericInternalCountsForTraining[i]=new GenericCounts*[internalTestMod->numberOfFolds];
				genericInternalCountsForTest[i]=new GenericCounts*[internalTestMod->numberOfFolds];
//if (1==0)
				for ( int j=0; j<internalTestMod->numberOfFolds;j++ )
					for ( int k=0; k<2;k++ ) // training and test
					{
						if ( k==0 ) {genericCounts=genericInternalCountsForTraining; samples=internalSamplesForTraining;}
						else {genericCounts=genericInternalCountsForTest; samples=internalSamplesForTest;}
						genericCounts[i][j]=this->getCounts ( samples[i][j], pos, length );
					}
			}
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void  GenericMLTest::setGenericCounts(int* pos, int length) " ); throw;};
	}
	/*___________________________________________________________ */

	MeasureResults**  GenericMLTest::getResults ( ListOfGenericMeasures* measures, Container<vector<ofstream*>,ofstream*>* listOfStreams ) //, int*subRegion, int length)
	{
		try
		{
			MeasureResults*** results=new MeasureResults**[measures->size() ], **finalResults=new MeasureResults*[measures->size() ];
			GenericMeasure* training=NULL, *test=NULL;
			stringSample*sample, *result;
//cout << "size of training:" << genericInternalCountsForTraining[0][0]->size() <<" plus " << genericInternalCountsForTest[0][0]->size() <<"\n";
//cout << "size of test:" << genericExternalCounts[0]->size() <<"\n";


			for ( int m=0; m<measures->size();m++ )
			{
				results[m]=new MeasureResults*[externalTestMod->numberOfFolds];
				for ( int i=0; i<externalTestMod->numberOfFolds;i++ )
				{
results[m][i]=NULL;
			training=measures->getElement ( m )->getNewGenericMeasure ( wholeInternalCounts[i], genericInternalCountsForTraining[i], genericInternalCountsForTest[i] );
if (training==NULL) throw NullValue("MeasureResults**  GenericMLTest::getResults ( ListOfGenericMeasures* measures, Container<vector<ofstream*>,ofstream*>* listOfStreams ): training is null");
//cout << "testMode:" << training->testMode <<"\n";
//	results[m][i]=training->getResults();
//cout << "measure is: " << training->getName() << "\n";
//cout << "measure is:" << measures->getElement ( m )->getName() <<"\n";
//cout <<"training:\n" << *training <<"\n";
//cout <<"pval:\n" << *training->getResults() <<"\n";

					if ( externalTestMod->tm==tTraining  )
{
						test=training; //->clone();

//cout <<"test:\n" << *test <<"\n";
//exit(0);
}
					else
{
//if ( genericExternalCounts[i]==NULL) cout <<"null\n";
//cout << * genericExternalCounts[i] <<"\n";
//cout << "before infer\n";
						test=training->inferGenericMeasure ( genericExternalCounts[i] );// outsideTestMode crossVal or holdout
//cout << "after infer\n";
}
					if ( test==NULL ) throw NullValue ( "MeasureResults**  GenericMLTest::getResults (ListOfGenericMeasures* measures, Container<vector<ofstream*>,ofstream*>* listOfStreams)" );
					if ( listOfStreams!=NULL) *listOfStreams->getElement ( m )  << *test <<"\n";
					// OBTAIN P-VALUES
					results[m][i]=test->getResults();
					// DELETE TEMPORAL MEASURES
			zap ( training );
//cout << "before second zaping\n";		
if ( externalTestMod->tm!=tTraining  )
					zap ( test );
//cout << "after second zaping\n";		
//exit(0);
				}
			}
	for ( int m=0; m<measures->size();m++ )
			{
				finalResults[m]=results[m][0]->getAverage ( results[m], externalTestMod->numberOfFolds );
			 zaparr ( results[m], externalTestMod->numberOfFolds );
			}
			zaparr ( results, measures->size() );
			return finalResults;
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from MeasureResults**  GenericMLTest::getResults(ListOfGenericMeasures* measures) " ); throw;};
	}
} // end namespace
#endif
