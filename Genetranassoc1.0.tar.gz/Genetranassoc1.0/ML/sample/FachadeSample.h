#ifndef __FachadeSample_h__ 
#define __FachadeSample_h__ 


#include "../classifier/AlgTypeClass.h"

#include "GenericSample.h"
#include "GenericMLTest.h"

#include "selection/SelModeClass.h"
#include "selection/Selection.h"
#include "selection/FachadeSelection.h"
#include "discretization/DiscModeClass.h"
#include "selection/FachadeSelection.h"
//#include "../measure/FachadeMeasure.h"
#include "MLSample.h"


#include "discretization/FachadeDiscretization.h"

#endif
