#ifndef SameFrequencyAttributeDiscretization_h //
#define SameFrequencyAttributeDiscretization_h //

//////

//using namespace UTILS;


namespace BIOS  {





  class SameFrequencyAttributeDiscretization: public AttributeDiscretization
  {
  protected:

   int totalIntervals;
 
  public:

    //       SameFrequencyAttributeDiscretization(Classifier<float>* classifier, bool half, bool puntos, bool parada);

    //	SameFrequencyAttributeDiscretization (){}; //

 void discretization(floatSample::iterator first, floatSample::iterator last)
{
int foldSize;
int pos=0, pos2;
int resto=sample->getSize()%totalIntervals;
float firstElement, lastElement;
for (int i=0;i<totalIntervals-1;i++)
 {
 foldSize=sample->getSize()/totalIntervals;
 if ((resto>0) && (i<resto)) foldSize=foldSize+1;
 pos=pos+foldSize-1;
 firstElement=sample->sample->getElement(pos)->getElement(0);
 pos2=pos+1;
do
{
 lastElement=sample->sample->getElement(pos2)->getElement(0);
 pos2++;
}
while (lastElement==firstElement && pos2<sample->getSize());
 intervals->insertElement((lastElement+firstElement)/(float)2);
}
}
    

SameFrequencyAttributeDiscretization (floatMLSample* sample, int minNumberOfInstancesPerInterval=-1):AttributeDiscretization(sample, minNumberOfInstancesPerInterval)
{
this->totalIntervals=sample->getSize()/this->minNumberOfInstancesPerInterval;
}; //



    floatList* GetIntervals();
    
    ~SameFrequencyAttributeDiscretization(); //


  };


}
#endif

//#include "SameFrequencyAttributeDiscretization.cpp"
