#ifndef __FachadeBN_h__ 
#define __FachadeBN_h__ 


#include "AlgTypeClassBN.h"
#include "UndirectedBN.h"
#include "GBN.h"

// end namespace

//#include "Front.cpp"
#endif
