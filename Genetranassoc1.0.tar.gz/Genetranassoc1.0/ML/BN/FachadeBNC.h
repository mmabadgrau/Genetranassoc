#ifndef __FachadeBNC_h__ 
#define __FachadeBNC_h__ 



#include "GBN.cpp"
#include "UndirectedBN.cpp"
// end namespace

//#include "Front.cpp"
#endif
