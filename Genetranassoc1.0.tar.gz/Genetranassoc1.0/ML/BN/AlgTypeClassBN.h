/* File: AlgTypeClassBN.h */

#ifndef __AlgTypeClassBN_h__
#define __AlgTypeClassBN_h__



//using namespace UTILS;


namespace BIOS
{

  enum AlgTypeBN {
K2=0
  };

  class AlgTypeClassBN
  {


  public:
  
    AlgTypeBN algorithm;
 


    AlgTypeClassBN(AlgTypeBN algorithm)
    {
      this->algorithm=algorithm;
    }

 static  bool requiresDiscretization(AlgTypeBN algorithm)
{
switch (algorithm)
{
case K2:
 return true;
break;
default:
return false;
break;
}
}

};

ostream& operator<<(ostream& out, AlgTypeClassBN& p)
  {
     
      out <<"\nLearning BN algorithm:\t\t";
      switch (p.algorithm) //
      { //
      case K2: 	out <<"K2"; break;
}
  
		}
     


};  // Fin del Namespace

#endif

/* Fin Fichero: TestModeClass.h */
