#ifndef __HaplotypeCaseControlCounts_cpp__
#define __HaplotypeCaseControlCounts_cpp__

void print(BIOS::HaplotypeCaseControlCounts *h){
	cout << *h << endl;
}

void print2(BIOS::HaplotypeCaseControlCounts *h){
	cout << "hola" << endl;
}

namespace BIOS {

	HaplotypeCaseControlCounts::HaplotypeCaseControlCounts(int size): HaplotypeCounts(size)
	{
		frequencyControls=0;
		frequencyCases=0;
	};
	

	/*_________________________________________________________________*/
	

			HaplotypeCaseControlCounts::HaplotypeCaseControlCounts(Haplotype* haplotype, float frequencyCases, float frequencyControls): HaplotypeCounts(haplotype)
			{
			this->frequencyCases=frequencyCases;
			this->frequencyControls=frequencyControls;
			}
			
				/*_________________________________________________________________*/
	
			HaplotypeCaseControlCounts::HaplotypeCaseControlCounts(HaplotypeCaseControlCounts& other): HaplotypeCounts((HaplotypeCounts&) other)
			{
			frequencyCases=other.frequencyCases;
			frequencyControls=other.frequencyControls;
			}
	
	/*_________________________________________________________________*/

	HaplotypeCaseControlCounts::~HaplotypeCaseControlCounts()
	{
	}




			/*_________________________________________________________________*/
	
	bool HaplotypeCaseControlCounts::operator==(HaplotypeCaseControlCounts & h){
		//cout << " comparing HaplotypeCaseControlCounts ..." << endl;
return HaplotypeCaseControlCounts::operator==((HaplotypeCaseControlCounts&)h) && frequencyCases==h.frequencyCases & frequencyControls==h.frequencyControls;
		
	}

	
			/*_________________________________________________________________*/
	
	void HaplotypeCaseControlCounts::sumProps(HaplotypeCaseControlCounts * h){
		this->frequencyCases += h->frequencyCases;
		this->frequencyControls += h->frequencyControls;
	}

	
			/*_________________________________________________________________*/
	
	void HaplotypeCaseControlCounts::add(int cases, int controls){
		this->frequencyCases += cases;
		this->frequencyControls += controls;
	}

/*_________________________________________________________________*/

double HaplotypeCaseControlCounts::getFirstFrequency()
{
return frequencyCases;
}


/*_________________________________________________________________*/

double HaplotypeCaseControlCounts::getSecondFrequency()
{
return frequencyControls;
}


/*_________________________________________________________________*/

double HaplotypeCaseControlCounts::getThirdFrequency()
{
return 0;
}
/*_________________________________________________________________*/

void HaplotypeCaseControlCounts::print(ostream& output)
{
				output << "[";
				//cout <<"size is " << h.size() << "\n";
			
					output << *this->haplotype;

				output << "][" << this->frequencyCases << "]";
				output << "[" << this->frequencyControls << "]";


				//return output;
}

};

#endif
