#ifndef __SNPAfter_cpp__
#define __SNPAfter_cpp__

//#include <string.h>
//#include <cstdio>




//using namespace UTILS;


namespace BIOS {




/* _____________________________________________________*/

SNPPos GetTotalSNPs(char* filesample)
{
SNPPos totalSNPs;
char filePos[256], fileRSPos[256];
changeExtension(filesample, filePos, "pou");
changeExtension(filesample, fileRSPos, "rs");
stringList*sourcePositions;
if (!fileExists(filePos) && !fileExists(fileRSPos))
throw BadFormat("SNPAfter::GetTotalSNPs");

if (fileExists(filePos))
{
sourcePositions=new stringList(filePos);
totalSNPs=sourcePositions->size();
zap(sourcePositions);
return totalSNPs;
}
sourcePositions=new stringList(fileRSPos);
totalSNPs=sourcePositions->size();
zap(sourcePositions);
return totalSNPs;
}

} // end namespace

#endif

/* End of file: SNPAfter.h */
