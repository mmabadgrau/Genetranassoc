#ifndef __TDTtable_cpp__
#define __TDTtable_cpp__




/*_____________________________________________________________*/
/*
void print ( BIOS::TDTtable *t )
{
	cout << *t << endl;
}


/*_____________________________________________________________*/


namespace BIOS
{

	template<>	TDTtable<HaplotypeTUCountsVector>::TDTtable ( int cols, double minFreq, bool HWE ) :BidimensionalTable<double> ( 3,cols )
	{
// the third row is to store homozygous haplotype counts
		partition = NULL;
		this->minFreq=minFreq;
		this->HWE=HWE;
	};

	/*_____________________________________________________________*/


	template<>	TDTtable<HaplotypeCaseControlCountsVector>::TDTtable ( int cols, double minFreq, bool HWE ) :BidimensionalTable<double> ( 2,cols )
	{
// the third row is to store homozygous haplotype counts
		partition = NULL;
		this->minFreq=minFreq;
		this->HWE=HWE;
	};

	/*_____________________________________________________________________________________________________________*/


	template<class T>	TDTtable<T>::TDTtable ( const TDTtable<T>& other ) :BidimensionalTable<double> ( ( BidimensionalTable<double>& ) other )
	{
// the third row is to store homozygous haplotype counts
		partition=NULL;
		if ( other.partition!=NULL ) partition = other.partition->clone();
		this->minFreq=other.minFreq;
		this->HWE=other.HWE;
	};

	/*_____________________________________________________________________________________________________________*/


	template<class T>		TDTtable<T>* TDTtable<T>::clone()
	{
		return new TDTtable<T> ( *this );
	}

	/*_____________________________________________________________________________________________________________*/


	template<class T>		TDTtable<T>::~TDTtable()
	{
//exit(0);
		empty();
	}

	/*_____________________________________________________________________________________________________________*/


	template<>		void TDTtable<HaplotypeCaseControlCountsVector>::addDimension()
	{
	}

	/*_____________________________________________________________________________________________________________*/


	template<>	void	TDTtable<HaplotypeTUCountsVector>::addDimension()
	{
		if ( partition!=NULL ) throw BadFormat ( "void	TDTtable<HaplotypeTUCountsVector>::addDimension()" );
		reset ( 3, getYDim() );
	}

	/*___________________________________________________*/

	template <> void TDTtable<HaplotypeCaseControlCountsVector>::addValue ( int i, int j, double value )
	{
		if ( i<getXDim() ) BidimensionalTable<double>::addValue ( i,j,value );
	}

	/*___________________________________________________*/

	template <> void TDTtable<HaplotypeTUCountsVector>::addValue ( int i, int j, double value )
	{
		BidimensionalTable<double>::addValue ( i,j,value );
	}

	/*___________________________________________________*/

	template <> void TDTtable<HaplotypeCaseControlCountsVector>::setValue ( int i, int j, double value )
	{
		if ( i<getXDim() ) BidimensionalTable<double>::setValue ( i,j,value );
	}

	/*___________________________________________________*/

	template <> void TDTtable<HaplotypeTUCountsVector>::setValue ( int i, int j, double value )
	{
		BidimensionalTable<double>::setValue ( i,j,value );
	}

	/*___________________________________________________*/

	template <> double TDTtable<HaplotypeCaseControlCountsVector>::getValue ( int i, int j )
	{
		if ( i<getXDim() ) return BidimensionalTable<double>::getValue ( i,j ); else return -1;
	}

	/*___________________________________________________*/

	template <> double TDTtable<HaplotypeTUCountsVector>::getValue ( int i, int j )
	{
		return BidimensionalTable<double>::getValue ( i,j );
	}

	/*_____________________________________________________________________________________________________________*/


	template<class T>		TDTtable<T>::TDTtable ( PartitionHaplotypeTUCountsVector* p, double minFreq, bool HWE )
			:BidimensionalTable<double> ( 2, p->size() )
	{
		try
		{
			this->partition=NULL;
			addDimension();
// may be is not needed, can be replaced by the next method
			if ( p==NULL ) throw NullValue ( " TDTtable::TDTtable (PartitionHaplotypeTUCountsVector * p, double minFreq, bool HWE)" );
			this->minFreq=minFreq;
			this->HWE=HWE;
			HaplotypeList* hs;
			this->partition=new PartitionAsVectorSampleOfHaplotypes ( '\t', '[',']' );
			HaplotypeTUCountsVector* hv;
			HaplotypeTUCounts* hc;
			for ( PartitionHaplotypeTUCountsVector::iterator it=p->begin(); it<p->end(); it++ )
			{
				hs=new HaplotypeList ( '\t', '[',']' );
				hv=p->getElement ( it );
				for ( HaplotypeTUCountsVector::iterator it2=hv->begin(); it2<hv->end(); it2++ )
				{
					hc=hv->getElement ( it2 );
					hs->insertHardElement ( hc->getHaplotype() );
					addValue ( 0, p->getPosition ( it ), hc->getFirstFrequency() );
					addValue ( 1, p->getPosition ( it ), hc->getSecondFrequency() );
					addValue ( 2, p->getPosition ( it ), hc->getThirdFrequency() );
				}
				if ( hs->size() >0 ) this->partition->insertElement ( hs );
			}
//cout << "here\n";
			filter();
			if ( !HWE && getTotalTransmissionCount ( ut ) ==0 ) {emptyAll();return;};
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from TDTtable::TDTtable( PartitionHaplotypeTUCountsVector* p, double minFreq, bool HWE )) " ); throw;};

	};

	/*_____________________________________________________________________________________________________________*/


	template<class T>		TDTtable<T>::TDTtable ( Container<vector<T*>, T*>* partition, double minFreq, bool HWE )
			:BidimensionalTable<double> ( 2, partition->size() )
	{
		try
		{
			this->partition=NULL;
			addDimension();
			if ( partition==NULL ) throw NullValue ( " TDTtable::TDTtable (Container<vector<HaplotypeCountsList*>, HaplotypeCountsList*>* partition, double minFreq, bool HWE)" );
			this->minFreq=minFreq;
			this->HWE=HWE;
			HaplotypeList* hs;
			this->partition=new PartitionAsVectorSampleOfHaplotypes ( '\t', '[',']' );
			T* hv;
			HaplotypeCounts* hc;
			for ( typename Container<vector<T*>, T*>::iterator it=partition->begin(); it<partition->end(); it++ )
			{
				hs=new HaplotypeList ( '\t', '[',']' );
				hv=partition->getElement ( it );
				for ( typename T::iterator it2=hv->begin(); it2<hv->end(); it2++ )
				{
					hc=hv->getElement ( it2 );
					hs->insertHardElement ( hc->getHaplotype() );
					addValue ( 0, partition->getPosition ( it ), hc->getFirstFrequency() );
					addValue ( 1, partition->getPosition ( it ), hc->getSecondFrequency() );
					addValue ( 2, partition->getPosition ( it ), hc->getThirdFrequency() );
				}
				if ( hs->size() >0 ) this->partition->insertElement ( hs );
			}
//cout << "here2\n";
			filter();
			if ( !HWE && getTotalTransmissionCount ( ut ) ==0 ) {emptyAll();return;};
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from TDTtable::TDTtable ( Container<vector<HaplotypeCountsList*>, HaplotypeCountsList*>* partition, double minFreq, bool HWE )" ); throw;};

	};


	/*_____________________________________________________________________________________________________________*/

//	  template <class T>
	template<class T>	TDTtable<T>::TDTtable ( T * p, int* positions, int length, double minFreq, bool HWE )
			:BidimensionalTable<double> ( 2,p->size() )
	{
// p will be HaplotypeTUCountsVector or HaplotypeCaseControlTUCountsVector
		// *positions and length are not used and they should be removed.
		try
		{
			this->partition=NULL;

			addDimension();

//			if ( !HWE && getTotalTransmissionCount ( ut ) ==0 ) {zap ( partition ); zap ( table ); zap ( dimensionList );return;};
//return;
//cout << "haplistis:" << *p <<"\n";
			if ( p==NULL ) throw NullValue ( "TDTtable::TDTtable ( HaplotypeCountsList * p, int* positions, int length, double minFreq, bool HWE )" );

			this->minFreq=minFreq;
			this->HWE=HWE;
			HaplotypeList* hs;



			partition=new PartitionAsVectorSampleOfHaplotypes ( '\t', '[',']' );

			HaplotypeCounts* hc;
			Haplotype* h;
			PartitionAsVectorSampleOfHaplotypes::iterator it2;

			for ( typename T::iterator it=p->begin(); it<p->end(); it++ )
			{
				hs=new HaplotypeList ( '\t', '[',']' );
				hc=p->getElement ( it );
				hs->insertHardElement ( hc->getHaplotype() );
//cout << "hs is:" << *hs <<"\n";
				addValue ( 0, p->getPosition ( it ), hc->getFirstFrequency() );
				addValue ( 1, p->getPosition ( it ), hc->getSecondFrequency() );
				addValue ( 2, p->getPosition ( it ), hc->getThirdFrequency() );
				partition->insertElement ( hs );
//cout << "after inserting in partition\n";
			}
//cout << "beforefiltering: " << *this <<"\n";
			filter();
//cout << "after filt " << *this <<"\n";
			if ( !HWE && getTotalTransmissionCount ( ut ) ==0 ) {emptyAll(); return;};
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from TDTtable::TDTtable(HaplotypeCountsList * p, int* positions, int length, double minFreq, bool HWE)) " ); throw;};
	};


	/*_____________________________________________________________________________________________________________*/
	/*
			TDTtable::TDTtable(HaplotypeTUCountsVector * p, int* positions, int length, double minFreq, bool HWE)
				:BidimensionalTable<double>(3,p->size())
			{
	try
	{
						this->minFreq=minFreq;
									this->HWE=HWE;
	 HaplotypeSet* hs;
	partition=new PartitionAsSetSampleOfHaplotypes('\t', '[',']');
	 HaplotypeTUCounts* hc;
	 Haplotype* h;
	 int pos;
	 PartitionAsSetSampleOfHaplotypes::iterator it2;
	 for (HaplotypeTUCountsVector::iterator it=p->begin(); it<p->end(); it++)
	  {
	  hs=new HaplotypeSet('\t', '[',']');
	  hc=p->getElement(it);
	  if (positions!=NULL) h=hc->getHaplotype()->filter(positions, length);
	  else h=hc->getHaplotype()->clone();
	  hs->insertElement(h);
		partition->insertElement(hs);
	  it2=partition->findElementContainingEqualInternalElement(h);
	  addValue(0, partition->getPosition(it2), hc->frequencyT);
	  addValue(1, partition->getPosition(it2), hc->frequencyU);
	  addValue(2, partition->getPosition(it2), hc->frequencyHomo);
	  }
	  filter();
	}
	catch (BasicException& be){be.addMessage("\ncalled from TDTtable::TDTtable(HaplotypeTUCountsVector * p, int* positions, int length, double minFreq, bool HWE)) "); throw;};
	};



	/*______________________________________________________________________________________________*/


	template<class T>		TDTtable<T>* TDTtable<T>::getFilteredTable()
	{
// for !HWE it removes those columns that does not have any T or U transmission at all or is under minFreq
		try
		{
			int totalHaps=this->getYDim();

			for ( int i=0; i<this->getYDim(); i++ )
				if ( ( !HWE && ( getHeteroHapCount ( i ) ==0 || getHeteroHapCount ( i ) <minFreq ) ) || ( HWE && ( getValue ( 2,i ) ==0 || getValue ( 2,i ) <minFreq ) ) )
					totalHaps--;
			if ( totalHaps==0 ) return NULL;
			if ( totalHaps<0 ) throw OutOfRange<int> ( totalHaps, "TDTtable<T>* TDTtable<T>::getFilteredTable()" );
//return NULL;
			TDTtable<T>* result=new TDTtable<T> ( totalHaps );

			result->partition=new PartitionAsVectorSampleOfHaplotypes ( '\t', '[',']' );
			int pos=0;
			for ( int j=0; j<getYDim(); j++ )
				if ( ( !HWE && getHeteroHapCount ( j ) >0 && getHeteroHapCount ( j ) >=minFreq ) || ( HWE && ( getValue ( 2,j ) >0 && getValue ( 2,j ) >=minFreq ) ) )
				{
					result->partition->insertHardElement ( this->partition->getElement ( j ) );
					for ( int i=0; i<getXDim(); i++ )
						result->setValue ( i, pos, getValue ( i, j ) );
					pos++;
				}
			if ( pos!=totalHaps ) throw OutOfBounds ( totalHaps, pos, "TDTtable::getFilteredTable(int minFreq, bool HWE)" );
			return result;
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from TDTtable* TDTtable::getFilteredTable()) " ); throw;};
	};

	/*__________________________________________________________________________________________*/


	template<class T>		void TDTtable<T>::empty()
	{
//cout << "partition removed\n";
		zap ( partition );
	}

	/*__________________________________________________________________________________________*/


	template<class T>		void TDTtable<T>::emptyAll()
	{
		empty();// zap partition
		BidimensionalTable<double>::empty();
		MultidimensionalTable<double>::empty(); // zap table
		MultidimensionalEmptyTable<double>::empty(); // zap dimensionList
	}
	/*__________________________________________________________________________________________*/


	template<class T>		void TDTtable<T>::filter()
	{
		try
		{
			if ( partition->size() ==0 )  {emptyAll(); return;};
			TDTtable<T>* f=this->getFilteredTable();
//if (partition!=NULL) cout <<"partition is: " << *partition <<"\n";
//			cout << "before zap\n";
//if (f!=NULL) cout << "nonull\n";
//zap ( f );
//cout << "after zap\n";
//return;


			if ( f==NULL ) {emptyAll(); return;}
			//  if (partition==NULL) return;
			zap ( this->partition );
			this->partition=f->partition->clone();

			reset ( f->getXDim(), f->getYDim() );

			for ( int i=0; i<f->getXDim();i++ )
				for ( int j=0; j<f->getYDim();j++ )
					setValue ( i,j,f->getValue ( i,j ) );
//cout <<"this dedddis:\n";
//cout <<* this <<"\n";
			zap ( f );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void TDTtable::filter()) " ); throw;};
	}



	/*________________________________________________________________________________________________*/
	/*
	  void TDTtable::update (HaplotypeTUCountsVector* hapCounts, VectorOfParentalHaplotypes* parentalHaplotypesList, bool useDistances=true)
	  {
	    TDTtable* oldData=this->clone();
	    BidimensionalTable<double>::empty(); // zaparr(table);
	    MultidimensionalTable<double>::set(); // create an empty table
	//    cout <<*oldData <<"\n";
	    double minDistance=-1, tempMin;
	    intSet* minPos=NULL;//=new intSet();// it will store all positions with same minimum distance
	    int selectedPos;
	    zap (this->partition);
	    this->partition=oldData->partition->clone();
	    for (HaplotypeTUCountsVector::iterator it=hapCounts->begin(); it<hapCounts->end(); it++)
	    {
	      minPos=oldData->partition->getPositionsWithMinDistance (*hapCounts->getElement (it)->getHaplotype() );
	      if (minPos->size() ==0) throw BadFormat ("TDTtable::update(HaplotypeTUCountsVector* hapCounts)");
	      selectedPos=rand()%minPos->size();
	    //  for (intSet::iterator it3=minPos->begin(); it3!=minPos->end(); it3++)
	      {
	        addValue (0, minPos->getElement (selectedPos), hapCounts->getElement (it)->frequencyT);
	        addValue (1, minPos->getElement (selectedPos), hapCounts->getElement (it)->frequencyU);
	        addValue (2, minPos->getElement (selectedPos), hapCounts->getElement (it)->frequencyHomo);
	      }
	      zap (minPos);
	    }
	    zap (oldData);
	    filter();
	    if (parentalHaplotypesList!=NULL) removeSemiHomo(parentalHaplotypesList);
	  }

	  
		  
	  
	  /*_____________________________________________________________*/

	template<class T>		TDTtable<T> * TDTtable<T>::newFromTree ( HaplotypeTUCountsTree *tree )
	{

		PartitionHaplotypeTUCountsVector * p = tree->getBestLeaves(); // p contains groups of leaves
		this->copyFrequenciesTo ( p ); // update p frequencies with values in table
		TDTtable<T> *t = new TDTtable<T> ( p, 0, false ); // create a new table with the groups in p
		zap ( p );

		return t;

	}

	/*_____________________________________________________________*/

	/*
	template <class T> void TDTtable<T>::update ( GeneticCounts<T>* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft )
		{
			try
			{
	throw NonImplemented("void TDTtable::update ( GeneticCounts<T>* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft )");
		}
			catch ( BasicException& be ) {be.addMessage ( "\ncalled from  template <> void TDTtable::update ( TUCounts* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft )" ); throw;};
		}
		/*_____________________________________________________________*/


	template <> void TDTtable<HaplotypeTUCountsVector>::update ( GeneticCounts<HaplotypeTUCountsVector>* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft )
	{
		try
		{
			update2 ( ( ( TUCounts* ) hapCounts )->parentalHaplotypesList, useDistances, treeDT, position, toLeft );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from  template <> void TDTtable::update ( TUCounts* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft )" ); throw;};
	}

	/*_____________________________________________________________*/


		template <> void TDTtable<HaplotypeCaseControlCountsVector>::update ( GeneticCounts<HaplotypeCaseControlCountsVector>* counts, bool useDistances, bool treeDT, int position, bool toLeft )
		{
	// used for T CaseControlCounts
			try
			{
				HaplotypeCaseControlCountsVector* hapCounts= ( HaplotypeCaseControlCountsVector* ) ( counts->haplotypeCountsVector );

				TDTtable<HaplotypeCaseControlCountsVector>* oldData=this->clone();
				initialize(); // set table counts to 0
				double minDistance=-1, tempMin;
				int selectedPos;
				intSet* minPos, *minPos2;
				Haplotype* h, *closestH;
				double cases, controls;
				HaplotypeCaseControlCounts* element;
				for ( HaplotypeCaseControlCountsVector::iterator it=hapCounts->begin(); it!=hapCounts->end(); it++ )
				{
					element=hapCounts->getElement ( it );
					h=element->getHaplotype ();
					cases=element->getFirstFrequency();
					controls=element->getSecondFrequency();
					if ( h!=NULL )
					{
						minPos=oldData->partition->getPositionsWithInternalMinDistance ( h, position, toLeft );

						selectedPos=minPos->getElement ( rand() %minPos->size() );
						if ( !useDistances || treeDT )
						{
							minPos2=oldData->partition->getElement ( selectedPos )->getPositionsWithMinDistance ( h , position, toLeft );
							closestH=oldData->partition->getElement ( selectedPos )->getElement ( minPos2->getElement ( 0 ) );
							if ( !useDistances )
								if ( h->getDistance ( closestH, -1 ) !=0 )
									selectedPos=rand() %oldData->partition->size(); // not exactly the same haplotype
							zap ( minPos2 );
						}
						addValue ( 0, selectedPos, cases );
						addValue ( 1, selectedPos, controls );
						zap ( minPos );
					}
				}
				delete oldData;
				//filter();// those partitions with no hetero genotypes will be removed

			}
			catch ( BasicException& be ) {be.addMessage ( "\ncalled from  template <> void TDTtable<HaplotypeCaseControlCountsVector>::update ( GeneticCounts<T>* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft )" ); throw;};
		}

		/*_____________________________________________________________*/


	template<class T>		void TDTtable<T>::update2 ( VectorOfParentalHaplotypes* parentalHaplotypesList, bool useDistances, bool treeDT, int position, bool toLeft )
	{
		try
		{
			//BIOS::print (parentalHaplotypesList->getPositions(), parentalHaplotypesList->getLength());
			//exit(0);

			TDTtable<T>* oldData=this->clone();
			initialize(); // set table counts to 0
			double minDistance=-1, tempMin;
			int selectedPosT, selectedPosU;
			intSet* minPosT, *minPosU, *minPosT2, *minPosU2;
			Haplotype* ht, *hu, *closestHt, *closestHu;
			ParentalHaplotypesUsingPointers* element;
			//oldData->partition->print();
			//PartitionAsSetSampleOfHaplotypes::iterator posT, posU;
//cout <<"list:" << *parentalHaplotypesList <<"\n";
			for ( VectorOfParentalHaplotypes::iterator it=parentalHaplotypesList->begin(); it!=parentalHaplotypesList->end(); it++ )
			{
				element=parentalHaplotypesList->getElement ( it );
				for ( int parent=0; parent<2;parent++ )
				{
					ht=element->getHap ( parent, t );
					hu=element->getHap ( parent, u );
					if ( ht!=NULL && hu!=NULL )
					{
						minPosT=oldData->partition->getPositionsWithInternalMinDistance ( ht, position, toLeft );
						minPosU=oldData->partition->getPositionsWithInternalMinDistance ( hu, position, toLeft );
						//selectedPosT=minPosT->getElement ( rand() %minPosT->size() );
						//selectedPosU=minPosU->getElement ( rand() %minPosU->size() );
						selectedPosT=minPosT->getElement ( 0 );
						selectedPosU=minPosU->getElement ( 0 );
						if ( !useDistances || treeDT )
						{
							minPosT2=oldData->partition->getElement ( selectedPosT )->getPositionsWithMinDistance ( ht , position, toLeft );
							minPosU2=oldData->partition->getElement ( selectedPosU )->getPositionsWithMinDistance ( hu , position, toLeft );
							closestHt=oldData->partition->getElement ( selectedPosT )->getElement ( minPosT2->getElement ( 0 ) );
							closestHu=oldData->partition->getElement ( selectedPosU )->getElement ( minPosU2->getElement ( 0 ) );
							if ( !useDistances )
							{
								if ( ht->getDistance ( closestHt, -1 ) !=0 )
									selectedPosT=rand() %oldData->partition->size(); // not exactly the same haplotype
								if ( hu->getDistance ( closestHu, -1 ) !=0 )
									selectedPosU=rand() %oldData->partition->size(); // not exactly the same haplotype
							}
							zap ( minPosT2 );
							zap ( minPosU2 );
						}
						if ( ( minPosT->size() ==1 && minPosU->size() ==1 && selectedPosT !=selectedPosU ) || ( treeDT && closestHt!=closestHu ) ) // only hetero
						{
							addValue ( 0, selectedPosT, 1 );
							addValue ( 1, selectedPosU, 1 );
						}
						else addValue ( 2, selectedPosT, 2 );
						zap ( minPosT ); zap ( minPosU );
					}
				}
			}
			delete oldData;
			//filter();// those partitions with no hetero genotypes will be removed
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from  void TDTtable::update (VectorOfParentalHaplotypes* parentalHaplotypesList)" ); throw;};
	}
	/*_____________________________________________________________*/

	/*
	template<>		void TDTtable<HaplotypeCaseControlCountsVector>::update2 (HaplotypeCaseControlCountsVector* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft )
		{
			try
			{
				TDTtable* oldData=this->clone();
				BidimensionalTable<double>::empty(); // zaparr(table);
				MultidimensionalTable<double>::set(); // create an empty table
				double minDistance=-1, tempMin;
				int selectedPosT, selectedPosU;
				intSet* minPos, *minPos2;
				Haplotype* h, *closestH;
	   double cases, controls;
				HaplotypeCaseControlCounts* element;
				for ( HaplotypeCaseControlCountsVector::iterator it=hapCounts->begin(); it!=hapCounts->end(); it++ )
				{
					element=hapCounts->getElement ( it );
						h=element->getHaplotype ();
	     cases=element->getFirstFrequency();
						controls=element->getSecondFrequency();
						if ( h!=NULL )
						{
							minPos=oldData->partition->getPositionsWithInternalMinDistance ( h, position, toLeft );
							selectedPos=minPos->getElement ( rand() %minPos->size() );
							if ( !useDistances || treeDT )
							{
								minPos2=oldData->partition->getElement ( selectedPos )->getPositionsWithMinDistance ( h , position, toLeft );
								closestH=oldData->partition->getElement ( selectedPos )->getElement ( minPos2->getElement ( 0 ) );
								if ( !useDistances )
									if ( h->getDistance ( closestH, -1 ) !=0 )
										selectedPos=rand() %oldData->partition->size(); // not exactly the same haplotype
								zap ( minPos2 );
							}
								addValue ( 0, selectedPos, cases );
								addValue ( 1, selectedPos, controls );
							zap ( minPos );
						}
					}
				delete oldData;
				//filter();// those partitions with no hetero genotypes will be removed
			}
			catch ( BasicException& be ) {be.addMessage ( "\ncalled from  void TDTtable::update (VectorOfParentalHaplotypes* parentalHaplotypesList)" ); throw;};
		}

		/*________________________________________________________________________________________________*/

	/*
			void TDTtable::Fill(PartitionHaplotypeTUCountsVector * p)
			{
				if ( getYDim() != p->size() ){
					cerr << "TDTtable: The table could not be filled. The number of columns and the number of subsets does not match " << endl;
					return;
				}
				//
				// Fill table
				//
				double t_freq, u_freq;

				// Fill each column
				for (int i=0; i < p->size(); i++){

					t_freq = (*p)[i]->getTransmittedFreqSum();
					u_freq =  (*p)[i]->getFreqSum() - t_freq;
					this->setValue(0,i, t_freq);
					this->setValue(1,i, u_freq);

				}
				partition = NULL;

			};

	/*___________________________________________________________________________________________*/



	template <class T> double TDTtable<T>::getStatistic ( bool HWE )
	{
		double sum=0;
		for ( int i=0; i<getYDim();i++ )
		{
			double b, c;
			if ( !HWE )
			{
				b = getValue ( 0,i );
				c = getValue ( 1,i );
			}
			else
			{
				b = getValue ( 2,i ) /2;
				c = getValue ( 0,i ) +getValue ( 1,i );
			}
			if ( ( b+c ) >0 ) sum += std::pow ( b-c , ( double ) 2 ) / ( double ) ( b+c );
		}
		if ( HWE ) return sum;
		else return sum* ( getYDim()-1 ) / ( double ) getYDim();
	};

	/*___________________________________________________________________________________________*/



	template<>		double TDTtable<HaplotypeCaseControlCountsVector>::getStatistic ( bool HWE )
	{
		if ( HWE ) throw BadFormat ( "double TDTtable<HaplotypeCaseControlCountsVector>::getStatistic ( bool HWE )" );
		double sum=0;
		double observed, expected, prob, cases=getTotalFirstRow(), controls=getTotalSecondRow();
		double totalHaps=cases+controls;
		for ( int i=0; i<getYDim();i++ )
		{
			prob= ( getValue ( 0,i ) +getValue ( 1,i ) ) /totalHaps;
			observed = getValue ( 0,i ); // cases
			expected = prob*cases;
			if ( expected>0 ) sum+=std::pow ( observed-expected, 2 ) /expected;

			observed = getValue ( 1,i ); // controls
			expected = prob*controls;
			if ( expected>0 ) sum+=std::pow ( observed-expected, 2 ) /expected;
		}
		return sum;
	};

	/*__________________________________________________________________________________*/


	template<class T>		double TDTtable<T>::getStatisticZforColumn ( int i , double wholeSampleT, double wholeSampleU )
	{
		/*
		double p = 0.5; // proportion

		double a; // number of disease-associated haplotypes (sum of T frequencies)
		double n; // the total number of haplotypes (sum of frequencies)
		double z;

		// Calculate a
		a = getValue ( 0,i );

		// Calculate n
		n= a + getValue ( 1,i );

		// Calculate z statistic
		if ( n == 1 )
			z = 0;
		else
			z = ( a - n*p ) / ( sqrt ( n*p* ( 1.0-p ) ) ) ;

		return z;
		*/

		double a = getValue ( 0,i );

		// Calculate n
		double c = getValue ( 1,i );

		double nchromoF = wholeSampleT + wholeSampleU;
		float na = wholeSampleT;
		float nc = wholeSampleU;

		double p = ( a + c ) / ( double ) nchromoF, pa = na / ( double ) nchromoF;
		double ea = na * p, ec = nc * p;
		double x = ( a - ea ) / sqrt ( ( a + c ) * pa * ( 1 - pa ) );
		return x;



	}

	/*_____________________________________________________________*/

	template<class T>		double TDTtable<T>::getStatisticZ ( double wholeSampleT, double wholeSampleU )
	{
		double z=0;
		double z_i=0;


		// For each column, calculate z statistic
		for ( int i=0; i<getYDim();i++ )   //i is the column index
		{
			z_i = getStatisticZforColumn ( i , wholeSampleT, wholeSampleU );
			//if ( z_i > 0 )
			z += z_i;
		}
		return z;
	}

	/*_____________________________________________________________*/


	template<class T>			double TDTtable<T>::getStatisticZ2 ( double wholeSampleT, double wholeSampleU )
	{
		double z=0;
		double z_i=0;


		// For each column, calculate z statistic
		for ( int i=0; i<getYDim();i++ )   //i is the column index
		{
			z_i = getStatisticZforColumn ( i , wholeSampleT, wholeSampleU );
			z += z_i*z_i;
		}
		return z;
	}

	/*_____________________________________________________________*/

	template<class T>		double TDTtable<T>::getWeightedStatistic ( doubleList* weights )
	{
		if ( weights->size() != getYDim() ) throw NullValue ( "TDTtable::getWeightedStatistic(doubleList* weights)" );
		double sum=0;

		for ( int i=0; i<getYDim();i++ )
		{
			double b, c;
			b = getValue ( 0,i );
			c = getValue ( 1,i );
			if ( ( b+c ) >0 ) sum += weights->getElement ( i ) *std::pow ( b-c , ( double ) 2 ) / ( double ) ( b+c );
		}
		return sum;
		//return sum*(getYDim()-1)/(double)getYDim();
	};

	/*_____________________________________________________________*/

	template<class T>		doubleList* TDTtable<T>::getHapFreqs()
	{
		doubleList* results=new doubleList();
		//if ( getTotalTransmissionCount ( ut ) ==0 )
		//	throw ZeroValue ( "TDTtable::getHapFreqs()" );
		for ( int i=0; i<getYDim(); i++ )
			if ( getTotalTransmissionCount ( ut ) ==0 ) results->insertElement ( 0 );
			else results->insertElement ( ( getValue ( 0,i ) +getValue ( 1,i ) ) / ( double ) getTotalTransmissionCount ( ut ) );
		return results;
	}

	/*_____________________________________________________________*/


	template<class T>		double TDTtable<T>::getHeteroHapCount ( int hapPos, Transmission trans )
	{
		double result;
		switch ( trans )
		{
			case t: result=getValue ( 0, hapPos ); break;
			case u: result=getValue ( 1, hapPos ); break;
			case ut: result=getValue ( 0,hapPos ) +getValue ( 1,hapPos ); break;
		}
		return result;
	}


	/*_____________________________________________________________*/


	template<class T>		double TDTtable<T>::getHomoHapCount ( int hapPos )
	{
		return getValue ( 2, hapPos );
	}
	/*_____________________________________________________________*/

	template <> void TDTtable<HaplotypeCaseControlCountsVector>::keepOnlyBothInFirstColumn ( GeneticCounts<HaplotypeCaseControlCountsVector>* hapCounts )
	{
		GenotypeList* caseGenotypes= ( ( CaseControlCounts* ) hapCounts )->getCaseGenotypes();
		GenotypeList* controlGenotypes= ( ( CaseControlCounts* ) hapCounts )->getControlGenotypes();
		GenotypeList* list=caseGenotypes;
		Haplotype* left, *right;
		PartitionAsVectorSampleOfHaplotypes::iterator posT, posU;
		int row=0;
		for ( int i=0; i<2; i++ )
		{
			if ( i==1 ) {list=controlGenotypes; row=1;}
			for ( GenotypeList::iterator it=list->begin(); it<list->end(); it++ )
			{
				left=list->getElement(it)->getLeftHaplotype();
				right=list->getElement(it)->getRightHaplotype();
				posT=partition->findElementContainingInternalElement ( left );
				posU=partition->findElementContainingInternalElement ( right );
				if ( posT!=posU || ( posT==posU && posT!=partition->begin() ) )
				{
					setValue ( row, partition->getPosition ( posT ), getValue ( row, partition->getPosition ( posT ) )-1 );
					setValue ( row, partition->getPosition ( posU ), getValue ( row, partition->getPosition ( posU ) )-1 );
				}
				else if ( posT!=partition->end() ) // those with both haps in first col are added too to second column to have 1df
					addValue ( 1-row, partition->getPosition ( posT ),2 );
			}
		}
	}


	/*_____________________________________________________________*/

	template <> void TDTtable<HaplotypeTUCountsVector>::removeSemiHomo ( GeneticCounts<HaplotypeTUCountsVector>* hapCounts )
	{
		try
		{
//cout << "before removing:" << *this <<"\n";
//removeSemiHomo2(((TUCounts*)hapCounts)->parentalHaplotypesList);
			VectorOfParentalHaplotypes* parentalHaplotypesList= ( ( TUCounts* ) hapCounts )->parentalHaplotypesList;
			//   cout <<"before is:" << *this <<"\n";
			Haplotype* ht, *hu;
			ParentalHaplotypesUsingPointers* element;
			PartitionAsVectorSampleOfHaplotypes::iterator posT, posU;
			for ( VectorOfParentalHaplotypes::iterator it=parentalHaplotypesList->begin(); it!=parentalHaplotypesList->end(); it++ )
			{
				element=parentalHaplotypesList->getElement ( it );
				for ( int parent=0; parent<2;parent++ )
				{
					ht=element->getHap ( parent, t );
					hu=element->getHap ( parent, u );
					if ( *ht!=*hu )
					{
						posT=partition->findElementContainingInternalElement ( ht );
						posU=partition->findElementContainingInternalElement ( hu );
						if ( posT==posU && posT!=partition->end() )
						{
							// cout << "haps: " << *ht << " and " << *hu << " belongs both to group " << partition->getPosition (posT) << "\n";

							setValue ( 0, partition->getPosition ( posT ), getValue ( 0, partition->getPosition ( posT ) )-1 );
							setValue ( 1, partition->getPosition ( posT ), getValue ( 1, partition->getPosition ( posT ) )-1 );
							addValue ( 2, partition->getPosition ( posT ), 2 );
							if ( getValue ( 0, partition->getPosition ( posT ) ) <0 || getValue ( 1, partition->getPosition ( posT ) ) <0 )
							{
								cout <<"current is:" << *this <<"\n";
								throw ZeroValue ( "void TDTtable::removeSemiHomo (VectorOfParentalHaplotypes* parentalHaplotypesList)" );
							}
						}
					}
				}
			}
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from  void TDTtable::removeSemiHomo (VectorOfParentalHaplotypes* parentalHaplotypesList)" ); throw;};

	}
	/*_____________________________________________________________*/

	/*
		template <class T> void TDTtable<T>::removeSemiHomo2 ( VectorOfParentalHaplotypes* parentalHaplotypesList )
		{
	throw NonImplemented("	template <class T> void TDTtable<T>::removeSemiHomo2 ( VectorOfParentalHaplotypes* parentalHaplotypesList )");
	}
		/*_____________________________________________________________*/

	/*
		template <> void TDTtable<HaplotypeTUCountsVector>::removeSemiHomo2 ( VectorOfParentalHaplotypes* parentalHaplotypesList )
		{
			try
			{
				//   cout <<"before is:" << *this <<"\n";
				Haplotype* ht, *hu;
				ParentalHaplotypesUsingPointers* element;
				PartitionAsSetSampleOfHaplotypes::iterator posT, posU;
				for ( VectorOfParentalHaplotypes::iterator it=parentalHaplotypesList->begin(); it!=parentalHaplotypesList->end(); it++ )
				{
					element=parentalHaplotypesList->getElement ( it );
					for ( int parent=0; parent<2;parent++ )
					{
						ht=element->getHap ( parent, t );
						hu=element->getHap ( parent, u );
						if ( *ht!=*hu )
						{
							posT=partition->findElementContainingInternalElement ( ht );
							posU=partition->findElementContainingInternalElement ( hu );
							if ( posT==posU && posT!=partition->end() )
							{
								// cout << "haps: " << *ht << " and " << *hu << " belongs both to group " << partition->getPosition (posT) << "\n";

								setValue ( 0, partition->getPosition ( posT ), getValue ( 0, partition->getPosition ( posT ) )-1 );
								setValue ( 1, partition->getPosition ( posT ), getValue ( 1, partition->getPosition ( posT ) )-1 );
								addValue ( 2, partition->getPosition ( posT ), 2 );
								if ( getValue ( 0, partition->getPosition ( posT ) ) <0 || getValue ( 1, partition->getPosition ( posT ) ) <0 )
								{
									cout <<"current is:" << *this <<"\n";
									throw ZeroValue ( "void TDTtable::removeSemiHomo (VectorOfParentalHaplotypes* parentalHaplotypesList)" );
								}
							}
						}
					}
				}
	// cout <<"final is:" << *this <<"\n";
	// exit(0);
			}
			catch ( BasicException& be ) {be.addMessage ( "\ncalled from  void TDTtable::removeSemiHomo (VectorOfParentalHaplotypes* parentalHaplotypesList)" ); throw;};
		}

		/*_____________________________________________________________*/

	/*
	template<>	void TDTtable::removeSemiHomo ( VectorOfParentalHaplotypes* parentalHaplotypesList )
		{
			try
			{
				//   cout <<"before is:" << *this <<"\n";
				Haplotype* ht, *hu;
				ParentalHaplotypesUsingPointers* element;
				PartitionAsSetSampleOfHaplotypes::iterator posT, posU;
				for ( VectorOfParentalHaplotypes::iterator it=parentalHaplotypesList->begin(); it!=parentalHaplotypesList->end(); it++ )
				{
					element=parentalHaplotypesList->getElement ( it );
					for ( int parent=0; parent<2;parent++ )
					{
						ht=element->getHap ( parent, t );
						hu=element->getHap ( parent, u );
						if ( *ht!=*hu )
						{
							posT=partition->findElementContainingInternalElement ( ht );
							posU=partition->findElementContainingInternalElement ( hu );
							if ( posT==posU && posT!=partition->end() )
							{
								// cout << "haps: " << *ht << " and " << *hu << " belongs both to group " << partition->getPosition (posT) << "\n";

								setValue ( 0, partition->getPosition ( posT ), getValue ( 0, partition->getPosition ( posT ) )-1 );
								setValue ( 1, partition->getPosition ( posT ), getValue ( 1, partition->getPosition ( posT ) )-1 );
								addValue ( 2, partition->getPosition ( posT ), 2 );
								if ( getValue ( 0, partition->getPosition ( posT ) ) <0 || getValue ( 1, partition->getPosition ( posT ) ) <0 )
								{
									cout <<"current is:" << *this <<"\n";
									throw ZeroValue ( "void TDTtable::removeSemiHomo (VectorOfParentalHaplotypes* parentalHaplotypesList)" );
								}
							}
						}
					}
				}
	// cout <<"final is:" << *this <<"\n";
	// exit(0);
			}
			catch ( BasicException& be ) {be.addMessage ( "\ncalled from  void TDTtable::removeSemiHomo (VectorOfParentalHaplotypes* parentalHaplotypesList)" ); throw;};
		}

		/*_____________________________________________________________*/


	template<class T>	double TDTtable<T>::getTotalTransmissionCount ( Transmission trans )
	{
		double result=0;
		for ( int i=0; i<getYDim(); i++ )
			switch ( trans )
			{
			case t: case u: result+=getValue ( trans-1,i ); break;
				case ut: result+=getValue ( 0,i ) +getValue ( 1,i ); break;
			}
		return result;
	}

	/*_____________________________________________________________*/


	template<class T>		double TDTtable<T>::getTotalHeteroGenotypes()
	{
		return getTotalTransmissionCount ( ut ) / ( double ) 2;
	}

	/*_____________________________________________________________*/


	template<class T>		double TDTtable<T>::getTotalHomoGenotypes()
	{
		return ( getTotalCounts()-getTotalTransmissionCount ( ut ) ) /2;
	}



	/*_____________________________________________________________*/


	template<class T>		doubleList* TDTtable<T>::getCounts ( Transmission trans )
	{
		doubleList* results=new doubleList();
		for ( int i=0; i<getYDim(); i++ )
			switch ( trans )
			{
			case t: case u: results->insertElement ( getValue ( trans-1,i ) );break;
				case ut: results->insertElement ( getValue ( 0,i ) +getValue ( 1,i ) ); break;
			}
		return results;
	}

	/*_____________________________________________________________*/


	template<class T>		doubleList* TDTtable<T>::getHomoCounts ()
	{
		doubleList* results=new doubleList();
		for ( int i=0; i<getYDim(); i++ )
			results->insertElement ( getValue ( 2,i ) );
		return results;
	}

	/*_____________________________________________________________*/


	template<class T>		double TDTtable<T>::getTotalRow ( int row )
	{
		double result=0;
		for ( int i=0; i<getYDim(); i++ )
			result=result+getValue ( row, i );
		return result;
	}

	/*_____________________________________________________________*/


	template<class T>		double TDTtable<T>::getTotalFirstRow ()
	{
		return getTotalRow ( 0 );
	}
	/*_____________________________________________________________*/


	template<class T>		double TDTtable<T>::getTotalSecondRow ()
	{
		return getTotalRow ( 1 );
	}


	/*_____________________________________________________________*/

	/*
		double TDTtable::getPVal()
	  {
	cout <<"dinn\n";
	cout <<"st:" << getStatistic() <<"\n";
	  return pdfTestChiSquare(getStatistic(),getYDim()-1);
	  }

	/*_____________________________________________________________*/

	/*
		double TDTtable::getWeightedPVal(doubleList* weights)
	  {
	  double result=pdfTestWeightedChiSquareTDT(getWeightedStatistic(weights), weights);
	  return result;
	  }
	*/

	/*_____________________________________________________________*/

	template<>		void  TDTtable<HaplotypeCaseControlCountsVector>::print ( ostream& out )
	{
//cout <<"totaldims:" << l.getYDim();
		if ( partition!=NULL )
		{
			out << "\t" << *partition <<"\n";
			for ( int i=0; i<=getYDim();i++ )
				out <<"___\t";
			out <<"\n";
			for ( int tr=0; tr<2; tr++ )
			{
				if ( tr==0 ) out << "Cs:\t"; else out << "Co: \t";
				for ( int i=0; i<getYDim();i++ )
				{
					out << getValue ( tr,i );
					if ( i< ( getYDim()-1 ) ) out <<"\t"; else out <<"\n";
				}
			}
		}
	}

	/*_____________________________________________________________*/

	template<>		void  TDTtable<HaplotypeTUCountsVector>::print ( ostream& out )
	{
//cout <<"totaldims:" << l.getYDim();
		if ( partition!=NULL )
		{
			out << "\t" << *partition <<"\n";
			for ( int i=0; i<=getYDim();i++ )
				out <<"___\t";
			out <<"\n";
			for ( int tr=0; tr<3; tr++ )
			{
				if ( tr==0 ) out << "T:\t"; else if ( tr==1 ) out << "U: \t"; else out <<"H:\t";
				for ( int i=0; i<getYDim();i++ )
				{
					out << getValue ( tr,i );
					if ( i< ( getYDim()-1 ) ) out <<"\t"; else out <<"\n";
				}
			}
		}
	}
	/*_____________________________________________________________*/


	template<class T>		ostream& operator<< ( ostream& out, TDTtable<T>& l )
	{
//cout <<"totaldims:" << l.getYDim();
		l.print ( out );
		return out;
	}

	/*_____________________________________________________________*/

	template<class T>		int TDTtable<T>::findColumn ( Haplotype *h )
	{
// it returns the column position of the set of haplotypes where the haplotype h belongs to. -1 if not present

		return partition->getPosition ( partition->findElementContainingInternalElement ( h ) );
	}

	/*_____________________________________________________________*/

	template<class T>		void TDTtable<T>::copyFrequenciesTo ( PartitionHaplotypeTUCountsVector * p )
	{
		HaplotypeTUCountsVector* hv;
		HaplotypeTUCounts* hc;


		// for each haplotype in p
		for ( PartitionHaplotypeTUCountsVector::iterator it=p->begin(); it<p->end(); it++ )
		{
			hv=p->getElement ( it );
			for ( HaplotypeTUCountsVector::iterator it2=hv->begin(); it2<hv->end(); it2++ )
			{
				hc=hv->getElement ( it2 ); // <<- haplotype

				// Find haplotype in this
				int column = findColumn ( hc->getHaplotype() );

				// copy frequencies
				if ( column != -1 )
				{
					hc->frequencyT = getValue ( 0, column );
					hc->frequencyU = getValue ( 1, column );
					hc->frequencyHomo = getValue ( 2, column );
				}

			}

		}


	}

	/*_____________________________________________________________*/
	/*
	template<class T>		void TDTtable<T>::print()
		{
			cout << *this ;
		}


		/*_____________________________________________________________*/

	template<class T>		void TDTtable<T>::twice()
	{
		for ( int i=0; i<getYDim();i++ )
		{

			for ( int k=0; k<3;k++ )
				setValue ( k, i, 2*getValue ( k, i ) );


		}
	}

};

#endif
