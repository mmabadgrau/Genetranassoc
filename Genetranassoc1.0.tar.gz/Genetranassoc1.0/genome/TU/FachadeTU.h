#ifndef __FachadeTU_h__ 
#define __FachadeTU_h__ 

#include "HaplotypeTUCounts.h"
#include "HaplotypeTUCountsVector.h"
#include "PartitionHaplotypeTUCountsVector.h"
#include "SetOfPartitions.h"
#include "TreeOfHaplotypeTUCounts.h"
#include "HaplotypeTUCountsTree.h"
#include "TDTtable.h"
#include "TUMeasures/FachadeTUMeasures.h"

#include "ParentalHaplotypesForEachIndividual.h"
#include "ParentalHaplotypes.h"
#include "ParentalHaplotypesUsingPointers.h"
#include "ParentalGenotypesUsingPointers.h"
#include "VectorOfParentalGenotypes.h"
#include "VectorOfParentalHaplotypes.h"
#include "TrioGenotype.h"
#include "TrioPhenotype.h"
#include "Trio.h"
#include "TrioSample.h"
#include "TrioCounters.h"



#include "HapExtractionConfiguration.h"
#include "TrioCountersHapUAndT.h"
//#include "TrioSNPGenotype.h"
//#include "MultimarkerMeasuresByBlocks.h"
//#include "GetMultimarkerMeasures.h"

#include "TreeDT.h"

#include "PD.h"
#include "TUCounts.h"
#include "TUMLTest.h"

#endif
