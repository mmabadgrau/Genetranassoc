#ifndef __TDTtable_h__
#define __TDTtable_h__

namespace BIOS {
	
  /**
     @memo TDTtable
     @doc
     Definition:
	Table to store T/U frequencies for the TDT algorithm or Case/Control frequencies

     @author Jose Moreno
     @version 1.0
	
	*/	


class VectorOfParentalHaplotypes;
// typedef SingleAncestorGraph<DirectedArc, HaplotypeTUCounts*, void> TreeOfHaplotypeTUCounts;

template<class T>	class TDTtable: public BidimensionalTable<double>{
    
  
  private:
  
  double minFreq;
  
  bool HWE;

		public:
		//! Vector of vector of haplotypes from which the table was created
		PartitionAsVectorSampleOfHaplotypes * partition;


		/**
		*	Constructor
		*/		
		TDTtable(int cols, double minFreq=0, bool HWE=false);

		/**
		*	Destructor
		*/		
	virtual	~TDTtable();

    static TDTtable* fromString(string s){throw NonImplemented("static TDTtable* fromString(string s)");};

void addValue (int i, int j, double value);

void setValue (int i, int j, double value);

double getValue (int i, int j);

virtual void empty();

void emptyAll();

		/**
		*	Constructor from a partition
		* 	Creates a table from the T/U data in a partition
		*	The number of columns in the table will be the number of subsets in p.
		*	The number of rows will be tow. The first for the Transmitted haplotypes. The second for the Non transmitted.
		*	@param p Partition from which to fill the table
		*/		
	TDTtable(Container<vector<T*>, T*>* partition, double minFreq=0, bool HWE=false);

TDTtable(PartitionHaplotypeTUCountsVector* hapCounts, double minFreq=0, bool HWE=false);
		//PartitionHaplotypeTUCountsVector
		TDTtable(const TDTtable& other);

 		/**
		*	Constructor from a partition
		* 	Creates a table from the T/U data in a vector of haplotypes.
    * It creates a partition with one haplotype at each haplotypeVector in the partition
		*	The number of columns in the table will be the number of haplotypes in the vextor.
		*	The number of rows will be two. The first for the Transmitted haplotypes. The second for the Non transmitted.
		*	@param p HaplotypVector from which to fill the table
		*/		
//template<class T>		
TDTtable(T* hapCounts, int* positions=NULL, int length=-1, double minFreq=0, bool HWE=false);

	//TDTtable(HaplotypeCaseControlCountsVector* hapCounts, int* positions=NULL, int length=-1, double minFreq=0, bool HWE=false);

  virtual TDTtable* clone();

  TDTtable* getFilteredTable();

  void filter();
		/**
		*	Fills the table based on the given partition.
		*	The table must have the same columns as the number of subsets in the partition 
		*	@param p Partition from which to fill the table
		*
		*/
		void Fill(PartitionHaplotypeTUCountsVector * p=NULL);
		
		/**
		* Modifies the partition given.
		* The frequencies for each haplotype in the partition will come from this table.
		*/
		void copyFrequenciesTo(PartitionHaplotypeTUCountsVector * p=NULL);
		
		/**
		* Find the column containing haplotype h
		* @param h haplotype to be found in this table.
		* @return column in the table. -1 if not found
		*/
		int findColumn(Haplotype *h);
		
	 /**
	 * Creates a tdttable from this and the given tree.
	 * Uses the best nodes of the tree to restrict the columns of this table.
	 * The nodes of the tree must be present in the table
	 * @param tree Tree of haplotypes used to restrict the columns in this table.
	 * @return A new table.
	 */
	 TDTtable * newFromTree(HaplotypeTUCountsTree *tree);		
// 	 TDTtable * newFromTree(TreeOfHaplotypeTUCounts *tree);		


  doubleList* getHapFreqs();
  
  void update2(VectorOfParentalHaplotypes* parentalHaplotypesList, bool useDistances=true, bool treeDT=false, int position=0, bool toLeft=false);

void update(GeneticCounts<T>* hapCounts, bool useDistances=true, bool treeDT=false, int position=0, bool toLeft=false);
  
//	void update(HaplotypeTUCountsVector* hapCounts, int iniPos, int length, bool left);

  double getStatistic(bool HWE=false);

	void addDimension();
  /**
   * Statistic for TreeDT
   * @return 
   */
  double getStatisticZ(double wholeSampleT=0, double wholeSampleU=0);
  double getStatisticZ2(double wholeSampleT=0, double wholeSampleU=0);
  double getStatisticZforColumn(int i, double wholeSampleT, double wholeSampleU);

  double getWeightedStatistic(doubleList* weights);

//  double getPVal();

//  double getWeightedPVal(doubleList* weights);

  doubleList* getCounts(Transmission transmission);

	doubleList* getHomoCounts ();

double getTotalHomoGenotypes();

double getTotalHeteroGenotypes();

 double getHomoHapCount (int hapPos);


	double getTotalTransmissionCount(Transmission trans);

double getTotalFirstRow();

double getTotalSecondRow();

double getTotalRow(int row);

	double getHeteroHapCount(int hapPos, Transmission trans=ut);
	
void removeSemiHomo(GeneticCounts<T>* hapCounts);

void keepOnlyBothInFirstColumn(GeneticCounts<T>* hapCounts);

//void removeSemiHomo2(VectorOfParentalHaplotypes* parentalHaplotypesList);
	
//void print();

bool operator==(TDTtable& other) {throw NonImplemented("TDTtable::operator==(TDTtable& other)");};

void print( ostream& out);

	void twice();

//void update2 (T* hapCounts, bool useDistances, bool treeDT, int position, bool toLeft );
	};
	
	


template <class T> ostream& operator<<(ostream& out, TDTtable<T>& l);



};

#endif
