#ifndef __G2Measure_h__
#define __G2Measure_h__

namespace BIOS {
	
  /**
     @memo G2Measure
     @doc
     Definition:
	Table to store T/U frecuencies for the TDT algorithm

     @author María del Mar Abad Grau
     @version 1.0
	
	*/	
template<class T> class G2Measure: public GroupBasedTDTMeasure<T> {


    
		public:
	

		/**
		*	Constructor
		*/		
		G2Measure(GeneticCounts<T>* tuCounts, double minFreq=10, int testMode=2, GeneticCounts<T>** partialTuCountsTraining=NULL, GeneticCounts<T>** partialTuCountsTest=NULL, bool useDistance=true, bool lengthDistance=false);
		
		G2Measure(double minFreq, int testMode, bool useDistances=true, bool lengthDistance=false);

				G2Measure(G2Measure& other);

		/**
		*	Destructor
		*/		
virtual		~G2Measure();

//void setAll();

	 virtual	TDTtable<T>*  set(GeneticCounts<T>* aTUCounts=NULL);

//void set(TDTtable* aTDTtable);

virtual G2Measure* clone();

virtual  bool getOneSide();

//virtual double getStatistic();

  virtual G2Measure* getNewMeasure(GenericCounts* tuCounts, GenericCounts** training=NULL, GenericCounts** test=NULL);
  
  	//	virtual G2Measure* inferMeasure(TUCounts* tuCounts);

 // virtual G2Measure* getNewMeasure(HapExtractionConfiguration* hapExtractionConfiguration, double minFreq=0, bool useModel=true);

		/**
		*	Calculate statistic from the tables 
		*/

//virtual double getPVal();	
	
virtual stringList* getHeadFile();

void fillPartition (Container<vector<T*>, T*> * p, T* hapCountsVector, double totalFirst, double totalSecond );

virtual double getOR();

string getName();//{return string("mTDT2G");};

// stringList* getFreqsResults();

//friend ostream& operator<<(ostream& out, G2Measure& l);


virtual void onePrint( ostream&, GeneticCounts<T>* aTuCounts, TDTtable<T>* aTDTtable, int subsample, int position=-1);

void parentalPrinting ( ostream& out, GeneticCounts<T>* aTuCounts);

	};




};

#endif
