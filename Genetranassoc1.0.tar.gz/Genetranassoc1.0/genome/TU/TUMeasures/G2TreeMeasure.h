#ifndef __G2TreeMeasure_h__
#define __G2TreeMeasure_h__

namespace BIOS {
	
  /**
     @memo G2TreeMeasure
     @doc
     Definition:
	Modification of 2G algorithm to use prior information. It adds 1 to the transmission or non-transmission frequencies depending on whether the closest haplotype to the crrent one is in G1 or G2 respectively. It start with the haplotype with the largest difference and continues from top to down in differences

     @author María del Mar Abad Grau
     @version 1.0
	
	*/	
template<class T> class G2TreeMeasure: public G2Measure<T> {

private:

double s;

    
		public:
	

		/**
		*	Constructor
		*/		
		G2TreeMeasure(GeneticCounts<T>* tuCounts, double s=2, double minFreq=10, int testMode=2, GeneticCounts<T>** partialTuCountsTraining=NULL, GeneticCounts<T>** partialTuCountsTest=NULL, bool useDistance=true, bool lengthDistance=false);
		
		G2TreeMeasure(double s, double minFreq, int testMode, bool useDistances=true, bool lengthDistance=false);

				G2TreeMeasure(G2TreeMeasure& other);

double getTotalCounts(HaplotypeVector * g, GeneticCounts<T>* aTUCounts, intSet* hapPos );

		/**
		*	Destructor
		*/		
virtual		~G2TreeMeasure();

//void setAll();

	 virtual	TDTtable<T>*  set(GeneticCounts<T>* aTUCounts=NULL);

//void set(TDTtable* aTDTtable);

virtual G2TreeMeasure* clone();

//virtual  bool getOneSide();

//virtual double getStatistic();

  virtual G2TreeMeasure* getNewMeasure(GenericCounts* tuCounts, GenericCounts** training=NULL, GenericCounts** test=NULL);
  
  	//	virtual G2TreeMeasure* inferMeasure(TUCounts* tuCounts);

 // virtual G2TreeMeasure* getNewMeasure(HapExtractionConfiguration* hapExtractionConfiguration, double minFreq=0, bool useModel=true);

		/**
		*	Calculate statistic from the tables 
		*/

//virtual double getPVal();	
	
//virtual stringList* getHeadFile();

//virtual double getOR();

string getName();//{return string("mTDT2G");};

// stringList* getFreqsResults();

//friend ostream& operator<<(ostream& out, G2TreeMeasure& l);


//void onePrint( ostream&, TUCounts* aTuCounts, TDTtable* aTDTtable);

	};




};

#endif
