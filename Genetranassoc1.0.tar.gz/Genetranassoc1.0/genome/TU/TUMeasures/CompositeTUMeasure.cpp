#ifndef __CompositeTUMeasure_cpp__
#define __CompositeTUMeasure_cpp__


namespace BIOS {

template <class T> 	CompositeTUMeasure<T>::CompositeTUMeasure(CompositeTUMeasure<T> & other)
	{
		this->measureLeft = other.measureLeft->clone();		
		this->measureRight = other.measureRight->clone();	

		this->measureLeft->setCounts(other.measureLeft->getCounts()->clone());
		this->measureRight->setCounts(other.measureRight->getCounts()->clone());
	}

/*______________________________________________________________________________________________________________*/

template <class T>	CompositeTUMeasure<T>::CompositeTUMeasure(TUMeasure<T> *  measureLeft, TUMeasure<T> *measureRight,  double minFreq)
	{
		this->measureLeft = measureLeft;
		this->measureRight = measureRight;
	};

/*______________________________________________________________________________________________________________*/

template <class T>	CompositeTUMeasure<T>::CompositeTUMeasure(GeneticCounts<T>* geneticCounts, TUMeasure<T> *  measureLeft, TUMeasure<T> *measureRight,  double minFreq):TUMeasure<T>(geneticCounts)
	{

		if ( geneticCounts == NULL) 
			throw null_tuCounts;

		this->setCounts(geneticCounts);

		this->measureLeft = measureLeft;
		this->measureRight = measureRight;

		this->measureLeft->setCounts( geneticCounts->filterLeftHalf() );
		this->measureRight->setCounts( geneticCounts->filterRightHalf() );

	};

/*______________________________________________________________________________________________________________*/

template <class T> 	CompositeTUMeasure<T>::~CompositeTUMeasure()
	{
		if (measureLeft->getCounts() != NULL)
			delete measureLeft->getCounts();
		if (measureRight->getCounts() != NULL)
			delete measureRight->getCounts();
		delete measureLeft;
		delete measureRight;
		
	}
/*______________________________________________________________________________________________________________*/

template <class T> 	double CompositeTUMeasure<T>::getPVal()
	{
		double p_right, p_left;
		
		p_right = measureRight->getPVal();
		p_left = measureLeft->getPVal();

		return p_right * p_left;


	}

/*______________________________________________________________________________________________________________*/

template <class T> 	string CompositeTUMeasure<T>::getName(){
		return string("TDTComposite("  + measureLeft->getName() + ", " + measureRight->getName() + ")" );
	};

/*______________________________________________________________________________________________________________*/
	
template <class T> 	CompositeTUMeasure<T>* CompositeTUMeasure<T>::clone(){
 		return new CompositeTUMeasure<T>(*this);
	};

/*______________________________________________________________________________________________________________*/

template <class T> 	CompositeTUMeasure<T>* CompositeTUMeasure<T>::getNewMeasure(GenericCounts* geneticCounts, GenericCounts** training, GenericCounts** test)
	{
		return new CompositeTUMeasure((GeneticCounts<T>*)geneticCounts, measureLeft, measureRight, this->minFreq);
	};

/*______________________________________________________________________________________________________________*/

template <class T> 	CompositeTUMeasure<T>* CompositeTUMeasure<T>::inferMeasure(GeneticCounts<T>* genericCounts)
	{
		GenericCounts * tuLeft = genericCounts->filterLeftHalf();
		GenericCounts * tuRight = genericCounts->filterRightHalf();

		CompositeTUMeasure<T> * compositeMeasure = new CompositeTUMeasure<T>(measureLeft->inferMeasure((TUCounts*)tuLeft), measureRight->inferMeasure((GeneticCounts<T>*)tuRight), this->minFreq);
		compositeMeasure->counts = genericCounts;

		return compositeMeasure;
		
	};
	
};

#endif
