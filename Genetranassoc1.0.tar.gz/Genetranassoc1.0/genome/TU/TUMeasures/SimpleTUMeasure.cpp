#ifndef __SimpleTUMeasure_cpp__
#define __SimpleTUMeasure_cpp__





namespace BIOS {

template <class T>		SimpleTUMeasure<T>::SimpleTUMeasure(GeneticCounts<T>* counts, double minFreq, bool permutations, bool left):TUMeasure<T>(counts, minFreq, permutations)
{
		};

/*_________________________________________________________________*/

template <class T>			SimpleTUMeasure<T>::SimpleTUMeasure():TUMeasure<T>()
{
		};
/*_________________________________________________________________*/

template <class T>			SimpleTUMeasure<T>::SimpleTUMeasure(double minFreq, bool permutations):TUMeasure<T>(minFreq, permutations)
{
		};
/*_________________________________________________________________*/

template <class T>			SimpleTUMeasure<T>::SimpleTUMeasure(SimpleTUMeasure& other):TUMeasure<T>(other)
{
		};
/*___________________________________________________________________________________*/


template <class T>	double	SimpleTUMeasure<T>::getGenotypeCount(Haplotype*a, Haplotype*b)
{
double total=0;
ParentalHaplotypesUsingPointers* p;
for (ParentalHaplotypesUsingPointersList::iterator it=this->counts->getParentalHaplotypesList()->begin();it<this->counts->getParentalHaplotypesList()->end();it++)
{
p=*it;
if (p->getHap(0,t)!=NULL && *(Haplotype*)(p->getHap(0,t))==*a && p->getHap(0,u)!=NULL && *(Haplotype*)(p->getHap(0,u))==*b) total+=p->freq;
if (p->getHap(1,t)!=NULL && *(Haplotype*)(p->getHap(1,t))==*a && p->getHap(1,u)!=NULL && *(Haplotype*)(p->getHap(1,u))==*b) total+=p->freq;
}
return total;
};	
/*_________________________________________________________________*/
/*

		SimpleTUMeasure::SimpleTUMeasure(bool permutations):GenericMeasure()
{
this->permutations=permutations;
hapExtractionConfiguration=NULL;
		};
/*_________________________________________________________________*/

template <class T>			SimpleTUMeasure<T>::~SimpleTUMeasure(){
  //counts=NULL;
		};
/*_________________________________________________________________*/
/*
		double SimpleTUMeasure::getStatistic(){
  return new SimpleTUMeasure(*this);
		};

/*_________________________________________________________________*/
/*
	 SimpleTUMeasure* SimpleTUMeasure::getNewGenericMeasure(GenericCounts* tuCounts2, bool useModel)
	{
 return getNewMeasure((TUCounts*)tuCounts2, useModel);
	}
		 
	

/*_________________________________________________________________*/

template <class T>			GenericCounts* SimpleTUMeasure<T>::getTUCounts(){
  return (GenericCounts*)this->counts;
		};



/*_____________________________________________________________*/
/*
	double SimpleTUMeasure::getPVal()
  {
  //cout <<"measure with perms is:" << this->getName() <<"\n";
  double result=1;
  doubleList* null=new doubleList();
  double* nullArray;
  SimpleTUMeasure* tu;
  if (counts->getPermutations()==NULL) 
  counts->setPermutations();

  
  for (int i=0; i<counts->getTotalPermutations(); i++)
  {
  //if (i%10==0)  cout <<"permutation " << i <<"\n";
   tu=(SimpleTUMeasure*)this->getNewMeasure(counts->getPermutations()[i]);
   null->insertElement(tu->getStatistic());
   zap(tu);
  }
  null->sort();
//  cout <<*null <<"\nwhile real value is:" << getStatistic() <<"\n";
  nullArray=null->getTable();
  result=getPValue(nullArray, counts->getTotalPermutations(), getStatistic());
  zap(null);
  zaparr(nullArray);
  return result;
  }
/*_____________________________________________________________*/

template <class T>	  SimpleTUMeasure<T>* SimpleTUMeasure<T>::fromString(string s){throw NonImplemented("SimpleTUMeasure::fromString(string s)");};


};

#endif
