#ifndef __YateTDTMeasure_cpp__
#define __YateTDTMeasure_cpp__




/*_____________________________________________________________*/
/*
void print(BIOS::YateTDTMeasure *t){
	cout << *t << endl;
}
*/

/*_____________________________________________________________*/


namespace BIOS {		


template <class T> YateTDTMeasure<T>::YateTDTMeasure(GeneticCounts<T>* tuCounts, double alpha, bool basicYate, bool left):Chi2TDTMeasure<T> (tuCounts, 0, false, left)
{
this->basicYate=basicYate;
this->alpha=alpha;
		};

/*_________________________________________________________________*/


template <class T> YateTDTMeasure<T>::YateTDTMeasure(double alpha, bool basicYate, bool left):Chi2TDTMeasure<T> (0, false, left)
{
this->basicYate=basicYate;
this->alpha=alpha;
		};

/*_________________________________________________________________*/

template <class T>    YateTDTMeasure<T>* YateTDTMeasure<T>::getNewMeasure(GenericCounts* tuCounts, GenericCounts** training, GenericCounts** test)
{
return new YateTDTMeasure((GeneticCounts<T>*)tuCounts, alpha, basicYate);
}
/*_________________________________________________________________*/
/*
   YateTDTMeasure* YateTDTMeasure::inferMeasure(TUCounts* tuCounts, int iniPos, int length)
{
else Chi2TDT::getNewMeasure(tuCounts, );
}

/*_________________________________________________________________________________*/


template <class T> 		YateTDTMeasure<T>::~YateTDTMeasure(){
//		 zap(this->tdtTable);
			}
/*_________________________________________________________________________________*/


template <class T> 	YateTDTMeasure<T>*	YateTDTMeasure<T>::clone(){
		 return new YateTDTMeasure(*this);
			}



/*________________________________________________________________________________*/



template <class T> 		double YateTDTMeasure<T>::getStatistic()
		{
      int k=this->tdtTable->getYDim();
						double result=0, a, b, p=0.5;
      for (int i=0; i<this->tdtTable->getYDim(); i++)
						{
								a=this->tdtTable->getValue(0,i);
								b=this->tdtTable->getValue(1,i);
      		if ((a+b)==0) throw ZeroValue("YateTDTMeasure::getStatistic()");
        if (!basicYate) p=1/((double)(a+b));
        result+=std::pow(fabs(a-b)-alpha*p,2)/(double)(a+b);
      }
     return result*(k-1)/(double)k;
		};



/*_____________________________________________________________________________________________________________*/



template <class T> 		string YateTDTMeasure<T>::getName()
{
string s= string("mTDTYateAlpha_")+tos(alpha); if (!basicYate) s=s+string("P"); 
return s;
};
	/*_________________________________________________________________*/

template <class T> stringList* YateTDTMeasure<T>::getFreqsResults()
 {
throw NonImplemented("aplaceTDTMeasure::getFreqsResults()");
/*
doubleList*r;
stringList* result=new stringList();
result->insertElement(tos(tuCounts->getTrioCounters()->pos[0]));
 result->insertElement(string("Haplotypes: "));
 result->insertElement((tos(tdtTable->partition)));
 result->insertElement(string("\nT: ")); 
 r=tdtTable->getCounts(1);
 result->insertElement(tos(r));
 zap(r);
 result->insertElement(string("\nU: ")); 
 r=tdtTable->getCounts(0);
 result->insertElement(tos(r));
 zap(r);
return result;
*/
}
};

#endif
