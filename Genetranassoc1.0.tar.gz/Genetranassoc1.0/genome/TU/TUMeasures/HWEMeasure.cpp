#ifndef __HWEMeasure_cpp__
#define __HWEMeasure_cpp__





namespace BIOS {

template<class T> HWEMeasure<T>::HWEMeasure(GeneticCounts<T>* tuCounts, double minFreq, bool permutations, bool left):Chi2TDTMeasure<T>(minFreq, permutations, left)
{
try
{
this->counts=tuCounts;
this->tdtTable=new TDTtable<T>(tuCounts->haplotypeTUCountsVector, NULL, 0, minFreq, true);//true for HWE
if (this->tdtTable->partition==NULL) zap(this->tdtTable);
}
catch (BasicException& be){be.addMessage("\ncalled from HWEMeasure::HWEMeasure(TUCounts* tuCounts, double minFreq, bool permutations, bool left):Chi2TDTMeasure(minFreq, permutations, left)) "); throw;};

};
/*_________________________________________________________________*/

	template<class T>	HWEMeasure<T>::HWEMeasure(double minFreq, bool permutations, bool left):Chi2TDTMeasure<T>(minFreq, permutations, left)
{
};
/*_________________________________________________________________*/

template<class T>		HWEMeasure<T>::HWEMeasure(HWEMeasure<T>& other):Chi2TDTMeasure<T>(other)
{
		};
/*_________________________________________________________________*/
/*

		HWEMeasure::HWEMeasure(bool permutations):Chi2TDTMeasure(permutations)
{
		};

/*_____________________________________________________________________________________________________________*/


template<class T>		void HWEMeasure<T>::print(ostream& out){
 if (this->tdtTable!=NULL)  out << *this->tdtTable; else out <<"Null homo table\n";
		};

/*_____________________________________________________________*/

template<class T> stringList*  HWEMeasure<T>::getHeadFile()
 {

stringList *result=new stringList();
result->insertElement(string("Pos: pVal"));
return result;
};
/*___________________________________________________________________________________*/


template<class T> HWEMeasure<T>*		HWEMeasure<T>::clone(){
return new HWEMeasure<T>(*this);
			}
		/*_________________________________________________________________*/

template<class T> HWEMeasure<T>*		HWEMeasure<T>::getNewMeasure(GenericCounts* tuCounts, GenericCounts** training, GenericCounts** test)
{
try
{
return new HWEMeasure<T>((GeneticCounts<T>*)tuCounts, this->minFreq, this->permutations);
}
catch (BasicException& be){be.addMessage("\ncalled from HWEMeasure*		HWEMeasure::getNewMeasure(TUCounts* tuCounts)) "); throw;};

		};
/*_________________________________________________________________*/

template<class T>		HWEMeasure<T>::~HWEMeasure(){
//zap(tdtTable);
		};
/*_________________________________________________________________*/

template<class T>		double HWEMeasure<T>::getStatistic()
		{
     return this->tdtTable->getStatistic(true);
		};

	/*___________________________________________________________________________________*/
 
 
template<class T> string HWEMeasure<T>::getName()
 {
 string result=string("HWE");
  if (this->minFreq!=0) result=result+string("_minFreq")+tos(this->minFreq);
 if (this->permutations) result=result+this->addPermutationsInName();
 return result;
 };
/*_____________________________________________________________*/
/*
	double HWEMeasure::getPVal()
  {
throw NonImplemented("HWEMeasure::getPVal()");
  }
/*_____________________________________________________________*/

 template<class T> HWEMeasure<T>* HWEMeasure<T>::fromString(string s){throw NonImplemented("HWEMeasure::fromString(string s)");};


};

#endif
