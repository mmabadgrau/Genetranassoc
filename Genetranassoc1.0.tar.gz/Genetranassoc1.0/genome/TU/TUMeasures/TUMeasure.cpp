#ifndef __TUMeasure_cpp__
#define __TUMeasure_cpp__





namespace BIOS
{

template <class T>  TUMeasure<T>::TUMeasure (GeneticCounts<T>* tuCounts, double minFreq, bool permutations) :GenericMeasure(tuCounts, permutations)
  {
   // this->tuCounts=tuCounts;
   // this->permutations=permutations;
    this->minFreq=minFreq;
//if (permutations) this->minFreq=0;
  };

  /*_________________________________________________________________*/

template <class T>   TUMeasure<T>::TUMeasure() :GenericMeasure()
  {
   // this->tuCounts=NULL;
    this->minFreq=0;
  };
  /*_________________________________________________________________*/

 template <class T>  TUMeasure<T>::TUMeasure (double minFreq, bool permutations) :GenericMeasure(permutations)
  {
  //  this->tuCounts=NULL;
 //   this->permutations=permutations;
    this->minFreq=minFreq;
  };
  /*_________________________________________________________________*/

 template <class T>  TUMeasure<T>::TUMeasure (TUMeasure<T>& other) :GenericMeasure(other)
  {
  //  this->tuCounts=other.tuCounts;
  //  this->permutations=other.permutations;
    this->minFreq=other.minFreq;
  };
  /*_________________________________________________________________*/
  /*

  		TUMeasure::TUMeasure(bool permutations):GenericMeasure()
  {
  this->permutations=permutations;
  hapExtractionConfiguration=NULL;
  		};
  /*_________________________________________________________________*/

 template <class T>  TUMeasure<T>::~TUMeasure()
  {
    //tuCounts=NULL;
  };
  /*_________________________________________________________________*/
  /*
  		double TUMeasure::getStatistic(){
    return new TUMeasure(*this);
  		};

  /*_________________________________________________________________*/

 template <class T>  GenericMeasure* TUMeasure<T>::getNewGenericMeasure (GenericCounts* tuCounts2, GenericCounts** training, GenericCounts** test)
  {
    try
    {
      return getNewMeasure (  tuCounts2,training, test);
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from GenericMeasure* TUMeasure::getNewGenericMeasure(GenericCounts* tuCounts2, GenericCounts** training, GenericCounts** test) "); throw;};

  }

  /*_________________________________________________________________*/
/*
  TUMeasure* TUMeasure::getNewMeasure (TUCounts* tuCounts2, TUCounts** training, TUCounts** test)
  {
    throw NonImplemented ("TUMeasure::getNewMeasure(GenericCounts* tuCounts2, int iniPos, int length)");
  }

  /*_________________________________________________________________*/

 template <class T>  TUMeasure<T>* TUMeasure<T>::inferMeasure (GeneticCounts<T>* tuCounts2)
  {
    throw NonImplemented ("TUMeasure::inferMeasure(GenericCounts* tuCounts2");

  }

  /*_________________________________________________________________*/

 template <class T>  TUMeasure<T>* TUMeasure<T>::inferGenericMeasure (GenericCounts* tuCounts2)
  {
    return inferMeasure ( (GeneticCounts<T>*) tuCounts2);
  }

  /*_________________________________________________________________*/
  /*
  	GenericCounts* TUMeasure::getCounts(char* filename, int totalPermutations, int* pos, int size)
  	{
  	cout <<"DDDD\n";
  cout <<"namefile is:" << filename;
  	TrioSample* ts=new TrioSample(filename);
  	cout <<"HERRR\n";
  	TUCounts* tuCounts2=ts->getTUCounts(pos, size, hapExtractionConfiguration, useOnlyHetero, totalPermutations);
  	cout <<"SSS\n";
  	zap(ts);
    return tuCounts2;
  	}


  /*_________________________________________________________________*/

template <class T>   MeasureResults* TUMeasure<T>::getResults()
  {
    //getPVal();
    try
    {
  //  if (Bonferroni) 
//cout <<"getpval is being computed for StatisticalTestResults\n";
    return new StatisticalTestResults (getPVal(), getTotalMultipleTest());
//else return new StatisticalTestResults (getPVal(), 0);
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from MeasureResults* TUMeasure::getResults()"); throw;};
  }

  /*_________________________________________________________________*/

template <class T>   GenericCounts* TUMeasure<T>::getTUCounts()
  {
    return (GenericCounts*)counts;
  };

/*_________________________________________________________________*/

 template <class T>  double TUMeasure<T>::getTotalMultipleTest()
  {
    return 0;
  };
  


  /*_________________________________________________________________*/

 template <class T>  string TUMeasure<T>::addPermutationsInName()
  {
    if (counts!=NULL) return string ("_") +tos (counts->getTotalPermutations() ) +string ("permutations");
    else return string ("_usingPermutations");
  };

  /*_________________________________________________________________*/

 template <class T>  void TUMeasure<T>::setTUCounts (TUCounts *t)
  {
    this->counts = t;
  }


  /*_____________________________________________________________*/
  /*
  	double TUMeasure::getPVal()
    {
  cout <<"measure with perms is:" << this->getName() <<"\n";
    double result=1;
    doubleList* null=new doubleList();
    double* nullArray;
    TUMeasure* tu;

    if (tuCounts->getPermutations()==NULL) tuCounts->setPermutations();
    for (int i=0; i<tuCounts->getTotalPermutations(); i++)
    {
  //  if (i%10==0) cout <<"permutation " << i <<"\n";
   //cout <<"perm " << i <<" is: " << *tuCounts->getPermutations()[i] <<"\n";
     tu=this->getNewMeasure(tuCounts->getPermutations()[i]);
     null->insertElement(tu->getStatistic());
     zap(tu);
    }
    null->sort();
   // cout <<*null <<"\nwhile real value is:" << getStatistic() <<"\n";
    nullArray=null->getTable();
    result=getPValue(nullArray, tuCounts->getTotalPermutations(), getStatistic());
    zap(null);
    zaparr(nullArray);
    return result;
    }
  /*_____________________________________________________________*/

template <class T>  TUMeasure<T>* TUMeasure<T>::fromString (string s) {throw NonImplemented ("TUMeasure::fromString(string s)");};


};

#endif
