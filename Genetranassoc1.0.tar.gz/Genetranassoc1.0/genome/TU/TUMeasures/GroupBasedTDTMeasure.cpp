#ifndef __GroupBasedTDTMeasure_cpp__
#define __GroupBasedTDTMeasure_cpp__




namespace BIOS
{



	template<class T>	GroupBasedTDTMeasure<T>::GroupBasedTDTMeasure ( GeneticCounts<T>* tuCounts, double minFreq, int testMode, GeneticCounts<T>** partialTuCountsTraining, GeneticCounts<T>** partialTuCountsTest, bool permutations, bool useDistances, bool lengthDistance ) :Chi2TDTMeasure<T> ( tuCounts, minFreq, permutations )
	{
		try
		{
			totalMultipleTest=1;
			this->testMode=testMode;
			totalFolds=testMode;
			// if (testMode==1) totalFolds=2; // holdout
			this->lengthDistance=lengthDistance;
			this->partialTuCountsTraining=partialTuCountsTraining;
			this->partialTuCountsTest=partialTuCountsTest;
			this->useDistances=useDistances;
			partialTdtTables=NULL;
			partialTrainingTdtTables=NULL;
			totalUsedHaplotypes=0;
			totalUsedDifferentHaplotypes=0;
			if ( this->tdtTable!=NULL )
			{
//cout << "initableis:" << *tdtTable <<"\n";
				totalUsedHaplotypes= ( int ) this->tdtTable->getTotalTransmissionCount ( ut );
				totalUsedDifferentHaplotypes=this->tdtTable->getYDim();
			}
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from GroupBasedTDTMeasure::GroupBasedTDTMeasure(TUCounts* tuCounts, double minFreq..." ); throw;};
	};

	/*_________________________________________________________________*/

	template<class T>	GroupBasedTDTMeasure<T>::GroupBasedTDTMeasure ( double minFreq, int testMode, bool permutations, bool useDistances, bool lengthDistance ) :Chi2TDTMeasure<T> ( minFreq, permutations )
	{
		totalMultipleTest=1;
		totalUsedHaplotypes=0;
		totalUsedDifferentHaplotypes=0;
		this->testMode=testMode;
		totalFolds=testMode;
//  if (testMode==1) totalFolds=2; // holdout
		this->useDistances=useDistances;
		this->lengthDistance=lengthDistance;
		partialTdtTables=NULL;
		partialTrainingTdtTables=NULL;
		partialTuCountsTraining=NULL;
		partialTuCountsTest=NULL;
	};




	/*_________________________________________________________________*/

	template<class T>		GroupBasedTDTMeasure<T>::GroupBasedTDTMeasure ( GroupBasedTDTMeasure<T>& other ) :Chi2TDTMeasure<T> ( other )
	{
		totalMultipleTest=other.totalMultipleTest;
		testMode=other.testMode;
		totalFolds=other.totalFolds;
		partialTuCountsTraining=other.partialTuCountsTraining;
		partialTuCountsTest=other.partialTuCountsTest;
		partialTdtTables=NULL;
		partialTrainingTdtTables=NULL;
		totalUsedHaplotypes=other.totalUsedHaplotypes;
		totalUsedDifferentHaplotypes=other.totalUsedDifferentHaplotypes;
		this->useDistances=other.useDistances;
		this->lengthDistance=other.lengthDistance;
		if ( testMode>=1 && other.partialTrainingTdtTables!=NULL )
		{
			totalUsedDifferentHaplotypes=other.totalUsedDifferentHaplotypes;
			partialTrainingTdtTables=other.partialTrainingTdtTables->clone();
		}
		if ( testMode>=1 && other.partialTdtTables!=NULL )
		{
			totalUsedDifferentHaplotypes=other.totalUsedDifferentHaplotypes;
			partialTdtTables=other.partialTdtTables->clone();
		}
	};


	/*_________________________________________________________________*/

	template<class T>		GroupBasedTDTMeasure<T>::~GroupBasedTDTMeasure()
	{
		if ( testMode>=1 )
		{
//cout << "there are: \n";
//if (partialTdtTables!=NULL) cout << partialTdtTables->size() << "\n";
//else cout <<"0\n";

//cout << "test is:" << *partialTdtTables <<"\n";
			zap ( partialTdtTables );

//cout << "training is:" << *partialTrainingTdtTables <<"\n";

//cout << "fff\n";
			zap ( partialTrainingTdtTables );

//cout << "ddd\n";
		}
//else cout <<"hett\n";
	};

	/*___________________________________________________________________________________*/


	template<class T>		GroupBasedTDTMeasure<T>*	GroupBasedTDTMeasure<T>::inferMeasure ( GeneticCounts<T>* tuCounts )
	{
		GroupBasedTDTMeasure* result=NULL;

		if ( testMode<1 )
		{
//cout << "infering\n";
			result= ( GroupBasedTDTMeasure<T>* )  Chi2TDTMeasure<T>::inferMeasure ( tuCounts );
//cout << "now showing: \nn";
// cout << *result <<"\n";
			return result;

		}
		if ( tuCounts==NULL )
			throw NullValue ( "GroupBasedTDTMeasure*	GroupBasedTDTMeasure::inferMeasure(TUCounts* tuCounts)" );

//if (tdtTable==NULL) throw NullValue("Chi2TDTMeasure::inferMeasure(TUCounts* tuCounts)");
		result= ( GroupBasedTDTMeasure* ) this->clone();
//result->setTestMode(0);


//cout <<"result: " << *result <<"\n";
//zap(result->tuCounts);

//cout << *this <<"\n";
//cout << *this->tuCounts->haplotypeTUCountsVector <<"\n";
		if ( testMode==1 )
		{
			zap ( result->tdtTable );
			if ( partialTrainingTdtTables!=NULL && partialTrainingTdtTables->getFirstElement() !=NULL )
			{
//cout << *partialTrainingTdtTables->getFirstElement() <<"\n";
				result->tdtTable=partialTrainingTdtTables->getFirstElement()->clone();
			}
		}
//cout << "there\n";
		if ( result->tdtTable!=NULL )
		{

			result->tdtTable->update ( tuCounts );

//cout << *result <<"\n";

			if ( result->tdtTable!=NULL && result->tdtTable->partition==NULL ) zap ( result->tdtTable );
		}
		result->counts = tuCounts;
//cout << *tuCounts->haplotypeTUCountsVector <<"\n";

// TUCounts* other=tuCounts->clone();
// zap(other);

//cout << "las\n";

		if ( result->partialTrainingTdtTables!=NULL )
			zap ( result->partialTrainingTdtTables );
		if ( result->partialTdtTables!=NULL )
			zap ( result->partialTdtTables );
		result->testMode=0;
		return result;
	}

	/*_________________________________________________________________*/
/*
	template<class T>		void GroupBasedTDTMeasure<T>::removeSemiHomo ( TDTtable<T>* tdtTable, GeneticCounts<T>* tuCounts )
	{
		//.........
		try
		{
			if ( tdtTable!=NULL && tuCounts!=NULL )
				tdtTable->removeSemiHomo ( tuCounts );//->parentalHaplotypesList );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void GroupBasedTDTMeasure::removeSemiHomo()2" ); throw;};
	};



	/*_________________________________________________________________*/

	template<class T>		void GroupBasedTDTMeasure<T>::removeNotUsed ( TDTtable<T>* tdtTable, GeneticCounts<T>* tuCounts )
	{
		//.........
	try
		{
			if ( tdtTable!=NULL && tuCounts!=NULL )
				tdtTable->removeSemiHomo ( tuCounts );//->parentalHaplotypesList );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void GroupBasedTDTMeasure::removeSemiHomo()2" ); throw;};
	};

	/*_________________________________________________________________*/

	template<>		void  GroupBasedTDTMeasure<HaplotypeCaseControlCountsVector>::removeNotUsed ( TDTtable<HaplotypeCaseControlCountsVector>* tdtTable, GeneticCounts<HaplotypeCaseControlCountsVector>* tuCounts )
	{
		//.........
		try
		{
			if ( tdtTable!=NULL && tuCounts!=NULL )
				tdtTable->keepOnlyBothInFirstColumn ( tuCounts );//->parentalHaplotypesList );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void GroupBasedTDTMeasure::removeSemiHomo()2" ); throw;};
	};

	/*_________________________________________________________________*/

	template<class T>		int GroupBasedTDTMeasure<T>::getTestMode()
	{
		return testMode;
	}

	/*_________________________________________________________________*/

	template<class T>		void GroupBasedTDTMeasure<T>::setTestMode ( int testMode )
	{
		this->testMode=testMode;
	}


	/*_________________________________________________________________*/

	template<class T>		void GroupBasedTDTMeasure<T>::setAll()
	{
		//.........
		try
		{
			int position=0;
			if ( lengthDistance ) position=-1;
			TDTtable<T>* aTdtTable, *aTrainingTdtTable=NULL, *aTrainingTdtTableTemp=NULL;


//for (int i=0; i<1000;i++)
{
//if (i%50==0) cout <<"cont " << i <<"\n";
zap ( this->tdtTable );
			this->tdtTable=set ( ( GeneticCounts<T>* ) this->counts );
//for (int j=0; j<100000;j++)
//for (int k=0; k<5;k++);
}
//exit (0);
		if (this->tdtTable!=NULL) removeNotUsed ( this->tdtTable, ( GeneticCounts<T>* ) this->counts );
			if ( testMode<1 ) return;
this->partialTdtTables=NULL;
	this->partialTrainingTdtTables=NULL;
//return;
			this->partialTdtTables=new Container<vector<TDTtable<T>* >, TDTtable<T>* >;
			this->partialTrainingTdtTables=new Container<vector<TDTtable<T>* >, TDTtable<T>* >;

			for ( int i=0; i<totalFolds; i++ )
			{
				if ( this->partialTuCountsTraining[i]==NULL ) throw NullValue ( "void GroupBasedTDTMeasure::setAll()" );
				aTdtTable=set ( this->partialTuCountsTraining[i] );
				if ( aTdtTable!=NULL && ( aTdtTable->getTotalTransmissionCount ( ut ) ==0 ) ) zap ( aTdtTable );
				if ( this->partialTuCountsTest[i]==NULL ) throw NullValue ( "void GroupBasedTDTMeasure::setAll()-2" );
				if ( aTdtTable!=NULL )
				{
				removeNotUsed ( aTdtTable, this->partialTuCountsTraining[i] );
					aTrainingTdtTable=aTdtTable->clone();
					aTdtTable->update ((this->partialTuCountsTest[i]), useDistances, false, position, false );
					if ( aTdtTable!=NULL && ( aTdtTable->getTotalTransmissionCount ( ut ) ==0 ) ) zap ( aTdtTable );
					if ( aTdtTable!=NULL && aTdtTable->partition==NULL )
					{
						zap ( aTdtTable );
						zap ( aTrainingTdtTable );
					}
				}
				else aTrainingTdtTable=NULL;
				this->partialTrainingTdtTables->insertElement ( aTrainingTdtTable );
				this->partialTdtTables->insertElement ( aTdtTable );
			}
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void GroupBasedTDTMeasure::setAll()" ); throw;};
	};

	/*____________________________________________________________ */

	template<class T>		TDTtable<T>* GroupBasedTDTMeasure<T>::set ( GeneticCounts<T>* aTUCounts )
	{
		if ( aTUCounts==NULL ) return NULL;
		TDTtable<T>* result=new TDTtable<T> ( ( aTUCounts->haplotypeCountsVector ), NULL, 0, this->minFreq );
		if ( result==NULL || result->partition==NULL || result->getTotalHeteroGenotypes() ==0 ) {zap ( result );return NULL;}

		return result;
		//   cout <<"table after semi:\n" << *tdtTable <<"\n";
	}
	/*_____________________________________________________________*/


	template<class T>	double GroupBasedTDTMeasure<T>::getPVal ( int position, int subsample )
	{
		try
		{
				if ( subsample==0 ) if ( this->tdtTable==NULL ) return 1; else return  pdfTestChiSquare ( this->tdtTable->getStatistic(), this->tdtTable->getYDim()-1 );
			typename Vector<TDTtable<T>*>::Class*tables=partialTdtTables;

			if ( subsample==2 ) tables=partialTrainingTdtTables;
			if ( tables==NULL ) throw BadFormat ( "double GroupBasedTDTMeasure::getPVal(int position, bool testing)" );
			if ( tables->getElement ( position ) ==NULL )
				return 1; //throw BadFormat ( "double GroupBasedTDTMeasure::getPVal(int position, bool testing)" );
			else return pdfTestChiSquare ( tables->getElement ( position )->getStatistic(), tables->getElement ( position )->getYDim()-1 );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from GroupBasedTDTMeasure::getPVal(int position, bool testing)" ); throw;};
	}
	/*_____________________________________________________________*/


	template<class T>		double GroupBasedTDTMeasure<T>::getPVal()
	{
		try
		{
			int minDF;
			double result=0, totalOutcomes=0;


			if ( partialTdtTables==NULL || partialTdtTables->size() ==0 ) // testMode<1
				return Chi2TDTMeasure<T>::getPVal();

//  if (testMode>=2) return pdfTestChiSquare ( getStatistic(),testMode );

// for holdout (testMode=1) and cross validation
			result=1;
			for ( typename Vector<TDTtable<T>*>::Class::iterator it=partialTdtTables->begin(); it<partialTdtTables->end(); it++ )
				if ( partialTdtTables->getElement ( it ) !=NULL )
				{
					//cout <<*partialTdtTables->getElement ( it ) <<"\n";
//cout <<"statistic is: " << partialTdtTables->getElement ( it )->getStatistic() << " and p val is: " << pdfTestChiSquare ( partialTdtTables->getElement ( it )->getStatistic(), partialTdtTables->getElement ( it )->getYDim()-1 ) <<"\n";
					result=result*getPVal ( partialTdtTables->getPosition ( it ), true );;// using sum of chi squares 1 df
					totalOutcomes++;
				}
//cout <<"final meausre inside:" << result <<"\n";
//cout <<"pval result is: " <<pdfTestqfast(result,totalOutcomes) <<"\n";
			if ( totalOutcomes>0 ) return pdfTestqfast ( result,totalFolds ); else return 1;


//if  (partialTdtTables->size()==2 && sumOfHalves) return getPValSumOfHalfNormal(getStatistic());
			//		return pdfTestChiSquare ( getStatistic(),testMode );

		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from GroupBasedTDTMeasure::getPVal()" ); throw;};
	}
	/*_________________________________________________________________*/

	template<class T>		double GroupBasedTDTMeasure<T>::getTotalMultipleTest()
	{
		return totalMultipleTest;
	};


	/*_________________________________________________________________*/

	template<class T>		void GroupBasedTDTMeasure<T>::print ( ostream& out )
	{
//out << "\nFirstprintcommonall\n";

		try
		{
			onePrint ( out, ( GeneticCounts<T>* ) this->counts, this->tdtTable, 0 );
//out << "\nand now the others\n";
//out << "there are " << partialTdtTables->size() << "tables\n";
			if ( this->testMode>=1 )
				for ( int i=0; i<this->totalFolds; i++ )
				{
					out <<"\n";
					if ( this->partialTdtTables!=NULL && this->partialTdtTables->size() >0 && this->partialTdtTables->getElement ( i ) !=NULL )
					{
//out << "fold "<< i << "tucounts training:\n" << *partialTuCountsTraining[i] << "\ntest:\n" << *partialTuCountsTest[i] <<"\ntdtTraining:\n" << *partialTrainingTdtTables->getElement(i) <<"\nand now:\n";
						onePrint ( out, this->partialTuCountsTest[i], this->partialTdtTables->getElement ( i ), 1, i );
					}
					else
					{
						onePrint ( out, NULL, NULL, 1, -1 );
					}
				}
			if ( this->testMode==1 )
			{
				out <<"\n";
				if ( this->partialTrainingTdtTables!=NULL &&  this->partialTrainingTdtTables->size() >0 && this->partialTrainingTdtTables->size() >=1 )
					onePrint ( out, this->partialTuCountsTraining[0], this->partialTrainingTdtTables->getElement ( 0 ), 2, 0 );
				else 					onePrint ( out, NULL, NULL, 2, -1 );
			};
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from GroupBasedTDTMeasure::print(ostream& out)" ); throw;};
	}

	/*_________________________________________________________________________________________________*/

	template<class T>		void GroupBasedTDTMeasure<T>::onePrint ( ostream& out, GeneticCounts<T>* aTuCounts, TDTtable<T>* aTdtTable, int subsample, int position )
	{
		try
		{
			doubleList* tl, *ul, *homol;
			if ( aTdtTable!=NULL && aTdtTable->partition!=NULL )
			{
//cout <<*tdtTable;
//cout <<"--------------";
				aTdtTable->partition->setDelimiters ( '\0', '\n' );
				aTdtTable->partition->setOutputSeparator ( '\0' );
				aTdtTable->partition->setOutputSeparatorForInternalContainers ( ' ' );
				aTdtTable->partition->setDelimitersForInternalContainers ( '\0', ' ' );
				if ( aTuCounts==NULL ) throw NullValue ( "GroupBasedTDTMeasure::onePrint(ostream& out,...)" );
				if ( aTuCounts->getParentalGenotypes() ==NULL ) throw NullValue ( "GroupBasedTDTMeasure::onePrint(ostream& out,...)A" );
				if ( aTuCounts->getParentalGenotypes()->getPositions() ==NULL ) throw NullValue ( "GroupBasedTDTMeasure::onePrint(ostream& out,...)C" );
				if ( aTuCounts->getPositions() ==NULL ) throw NullValue ( "GroupBasedTDTMeasure::onePrint(ostream& ou,...t)-2" );


				if ( aTuCounts!=NULL ) out << aTuCounts->getParentalGenotypes()->getPositions() [aTuCounts->getPositions() [0]] <<": ";
				else out <<  "-1\t";
				out << getPVal ( position, subsample ) <<"\t";//Chi2TDTMeasure::getPVal();

				out << " Haplotypes: " << *aTdtTable->partition;
				tl=aTdtTable->getCounts ( t );
				ul=aTdtTable->getCounts ( u );
				homol=aTdtTable->getHomoCounts();
				homol->setDelimiters ( '\0', '\0' );
				out <<"T: " << *tl <<"U: " << *ul <<"H: " << *homol;
				zap ( ul );zap ( tl ); zap ( homol );
			}
			else out <<"null tdt table\n\n\n";
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from GroupBasedTDTMeasure::onePrint(ostream& out,...)" ); throw;};
	};

	/*_____________________________________________________________*/

	/*
		double GroupBasedTDTMeasure::getPVal()
	  {
	  try
	{
	return Chi2TDTMeasure::getPVal();
	}
	catch (BasicException& be) {be.addMessage ("\ncalled from GroupBasedTDTMeasure::getPVal()"); throw;};

	  }


	/*_________________________________________________________________________________________________*/
	/*
	double GroupBasedTDTMeasure::getStatistic()
	{
	return Chi2TDTMeasure::getStatistic();
	}
	/*_________________________________________________________________________________________________*/

	template<class T>		double GroupBasedTDTMeasure<T>::getStatistic()
	{
		double result=0;
		if ( this->partialTdtTables==NULL || this->partialTdtTables->size() ==0 ) return Chi2TDTMeasure<T>::getStatistic();
		for ( typename Vector<TDTtable<T>*>::Class::iterator it=partialTdtTables->begin(); it<partialTdtTables->end(); it++ )
		{
			if ( partialTdtTables->getElement ( it ) !=NULL )
				result=result+partialTdtTables->getElement ( it )->getStatistic();// using sum of chi squares 1 df
		}
		if ( testMode>1 ) return result/totalFolds;
		return result; //partialTdtTables->size();
	}

	/*_________________________________________________________________________________________________*/

template <> 	double GroupBasedTDTMeasure<HaplotypeTUCountsVector>::getStatistic()
{
// it divides by 2 tdtTable->getStatistic() because only individuals with both haplotypes being high risk are counted so that df is 1 (second column is the opposite to first column)
double result=0;
		if ( this->partialTdtTables==NULL || this->partialTdtTables->size() ==0 ) return Chi2TDTMeasure<HaplotypeTUCountsVector>::getStatistic()/2;
		for (  Vector<TDTtable<HaplotypeTUCountsVector>*>::Class::iterator it=partialTdtTables->begin(); it<partialTdtTables->end(); it++ )
		{
			if ( partialTdtTables->getElement ( it ) !=NULL )
				result=result+partialTdtTables->getElement ( it )->getStatistic()/2;// using sum of chi squares 1 df
		}
		if ( testMode>1 ) return result/totalFolds;
		return result; //partialTdtTables->size();
}

	/*___________________________________________________________________________________*/


	template<class T>		double	GroupBasedTDTMeasure<T>::getGenotypeCount ( Haplotype*a, Haplotype*b, int position, int subsample )
	{
		GeneticCounts<T>* c= ( TUCounts* ) this->counts;
		if ( subsample==1 ) c=partialTuCountsTest[position];
		if ( subsample==2 ) c=partialTuCountsTraining[position];
		if ( c==NULL ) throw NullValue ( "void GroupBasedTDTMeasure::getGenotypeCount(Haplotype*a, Haplotype*b, int position, int subsample)" );

		double total=0;
		ParentalHaplotypesUsingPointers* p;
		for ( ParentalHaplotypesUsingPointersList::iterator it=c->getParentalHaplotypesList()->begin();it<c->getParentalHaplotypesList()->end();it++ )
		{
			p=*it;
			if ( p->getHap ( 0,t ) !=NULL && * ( Haplotype* ) ( p->getHap ( 0,t ) ) ==*a && p->getHap ( 0,u ) !=NULL && * ( Haplotype* ) ( p->getHap ( 0,u ) ) ==*b ) total+=p->freq;
			if ( p->getHap ( 1,t ) !=NULL && * ( Haplotype* ) ( p->getHap ( 1,t ) ) ==*a && p->getHap ( 1,u ) !=NULL && * ( Haplotype* ) ( p->getHap ( 1,u ) ) ==*b ) total+=p->freq;
		}
		return total;
	};
	/*_________________________________________________________________________________________________*/


	/*_____________________________________________________________________________________________________________*/

	/*
			ostream& GroupBasedTDTMeasure::print(ostream& out){
	   out << *this;
	   return out;
			};
	/*_____________________________________________________________*/


};

#endif
