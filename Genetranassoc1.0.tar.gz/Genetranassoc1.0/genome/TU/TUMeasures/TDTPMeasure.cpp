#ifndef __TDTPMeasure_cpp__
#define __TDTPMeasure_cpp__





namespace BIOS
{

template<class T>	TDTPMeasure<T>::TDTPMeasure ( GeneticCounts<T>* tuCounts, double minFreq, bool independentCols, bool permutations, int testMode, GeneticCounts<T>** partialTuCountsTraining, GeneticCounts<T>** partialTuCountsTest, bool useDistance, bool lengthDistance ) :GroupBasedTDTMeasure<T> ( tuCounts, minFreq, testMode, partialTuCountsTraining, partialTuCountsTest, permutations, useDistance, lengthDistance )
	{

		weights=NULL;
		partialWeights=NULL;

		//if ( tuCounts==NULL || tdtTable==NULL || tdtTable->partition==NULL ) {zap ( tdtTable );return;}
		if ( this->testMode==-1 && this->tdtTable!=NULL )this-> totalMultipleTest=this->tdtTable->partition->size(); // Bonferroni correction
		this->setAll();




		if ( this->tdtTable!=NULL ) weights=this->tdtTable->getHapFreqs();

		if ( this->partialTrainingTdtTables!=NULL )
		{
			partialWeights=new doubleList*[this->partialTrainingTdtTables->size() ];
			for ( typename Vector<TDTtable<T>*>::Class::iterator it=this->partialTrainingTdtTables->begin(); it<this->partialTrainingTdtTables->end(); it++ )
			{
				if ( this->partialTrainingTdtTables->getElement ( it ) !=NULL )
					partialWeights[this->partialTrainingTdtTables->getPosition ( it ) ]=this->partialTrainingTdtTables->getElement ( it )->getHapFreqs();
				else partialWeights[this->partialTrainingTdtTables->getPosition ( it ) ]=NULL;
			}
		}

		this->independentCols=independentCols;
	};

	/*_________________________________________________________________*/

template<class T>		TDTPMeasure<T>::TDTPMeasure ( double minFreq, bool independentCols, bool permutations, int testMode, bool useDistances, bool lengthDistance ) :GroupBasedTDTMeasure<T> ( minFreq, testMode, permutations, useDistances, lengthDistance )
	{
		weights=NULL;
		partialWeights=NULL;
		this->independentCols=independentCols;
	};

	/*_________________________________________________________________*/

template<class T>		TDTPMeasure<T>::TDTPMeasure ( TDTPMeasure& other ) :GroupBasedTDTMeasure<T> ( other )
	{
		weights=NULL;
		partialWeights=NULL;
		this->independentCols=other.independentCols;

		if ( other.weights!=NULL ) 
{
weights=other.weights->clone();
//cout << "copying weights:\n";
//cout << *weights <<"\n";
}

		if ( other.partialTdtTables!=NULL )
		{
			partialWeights=new doubleList*[this->partialTdtTables->size() ];
			for ( int i=0; i<this->partialTdtTables->size();i++ )
				if ( other.partialWeights[i]!=NULL ) partialWeights[i]=other.partialWeights[i]->clone();
				else partialWeights[i]=NULL;
		}


	};

	/*_________________________________________________________________*/

template<class T>		TDTPMeasure<T>::~TDTPMeasure()
	{
		zap ( weights );
		if ( this->partialTrainingTdtTables!=NULL )
			zaparr ( partialWeights,this->partialTrainingTdtTables->size() );
// zap(tdtTable);
	};

	/*___________________________________________________________________________________*/


template<class T>		TDTPMeasure<T>*	TDTPMeasure<T>::inferMeasure ( TUCounts* tuCounts )
	{
		int totalPartials=0;
		if ( partialWeights!=NULL ) totalPartials=this->partialTdtTables->size();
		TDTPMeasure<T>* result= ( TDTPMeasure<T>* ) GroupBasedTDTMeasure<T>::inferMeasure ( tuCounts );
		if ( result->partialWeights!=NULL )
			zaparr ( result->partialWeights, totalPartials );
if (this->testMode==1) 		zap ( result->weights );
		if ( this->testMode==1 && partialWeights!=NULL && partialWeights[0]!=NULL) result->weights=partialWeights[0]->clone();
		return result;
	}
	/*___________________________________________________________________________________*/

	/*
	TDTPMeasure*	TDTPMeasure::inferMeasure(TUCounts* tuCounts)
	{
	if (tuCounts==NULL)
	throw NullValue("Chi2TDTMeasure*	Chi2TDTMeasure::inferMeasure(TUCounts* tuCounts)");


	//if (tdtTable==NULL) throw NullValue("Chi2TDTMeasure::inferMeasure(TUCounts* tuCounts)");
	TDTPMeasure* result=this->clone();
	//zap(result->tuCounts);
	//cout <<"current:\n";
	//cout << *this <<"\n";
	//cout << *this->tuCounts->haplotypeTUCountsVector <<"\n";
	if (result->tdtTable!=NULL)
	{
	result->tdtTable->update(tuCounts->parentalHaplotypesList);
	//cout <<"afterudating:\n";
	//cout << *result <<"\n";
	if (result->tdtTable!=NULL && result->tdtTable->partition==NULL) zap(result->tdtTable);
	}
	result->tuCounts = tuCounts;

	//cout << *tuCounts->haplotypeTUCountsVector <<"\n";
	//cout <<"new:\n" << *result;

	// TUCounts* other=tuCounts->clone();
	// zap(other);

	return result;
	}

		/*_________________________________________________________________*/

template<class T>		TDTPMeasure<T>* TDTPMeasure<T>::clone()
	{
		return new TDTPMeasure ( *this );
	};

	/*____________________________________________________________ */
	/*
	TDTtable<T>* TDTPMeasure::set(TUCounts* aTUCounts)
	{
	TDTtable<T>* result=new TDTtable<T>(aTUCounts->haplotypeTUCountsVector, NULL, 0, minFreq);
	if (result==NULL || result->partition==NULL || result->getTotalHeteroGenotypes()==0) {zap(result);return NULL;}

	return result;
	  //   cout <<"table after semi:\n" << *tdtTable <<"\n";
	}

	/*_________________________________________________________________*/

template<class T>		string TDTPMeasure<T>::getName()
	{
		string result=string ( "mTDTP" );



		if ( this->testMode==-1 ) result=result+string ( "_Bonferroni" );
		if ( this->testMode==0 ) result=result+string ( "_noCorrection" );
		if ( this->testMode==1 ) result=result+string ( "_holdout" );
		if ( this->testMode>=2 ) result=result+string ( "_cv" ) +tos ( this->testMode );
		if ( this->useDistances )
			if ( this->lengthDistance ) result=result+string ( "_useLengthDistances" );
			else result=result+string ( "_useBiosDistances" );



		if ( this->independentCols ) result=result+string ( "_indep" );
		if ( this->minFreq!=0 ) result=result+string ( "_minFreq" ) +tos ( this->minFreq );
		if ( this->permutations ) result=result+this->addPermutationsInName();
		return result;

	};
	/*_______________________________________________________________________________*/


template<class T>		double TDTPMeasure<T>::getStatistic()
	{






		double result=0;
		if ( this->partialTdtTables==NULL || this->partialTdtTables->size() ==0 )

			if ( weights!=NULL ) return this->tdtTable->getWeightedStatistic ( weights );
			else return 0;



		for ( int i=0; i<this->partialTdtTables->size(); i++ )
		{
			if ( this->partialTdtTables->getElement ( i ) !=NULL )


				if ( partialWeights[i]!=NULL )


					result=result+this->partialTdtTables->getElement ( i )->getWeightedStatistic ( partialWeights[i] );

		}
		return result/this->totalFolds;


	};



	/*_________________________________________________________________*/

template<class T>		TDTPMeasure<T>* TDTPMeasure<T>::getNewMeasure ( GenericCounts* tuCounts, GenericCounts** training, GenericCounts** test )
	{
		return new TDTPMeasure<T> ( ( GeneticCounts<T>* ) tuCounts, this->minFreq, independentCols, this->permutations, this->testMode, ( GeneticCounts<T>** ) training, ( GeneticCounts<T>** ) test, this->useDistances, this->lengthDistance );
	}
	/*_____________________________________________________________________________________________________________*/



	template<class T>	doubleList* TDTPMeasure<T>::getWeights()
	{
		return weights;
	};


	/*____________________________________________________________ */
	/*
	TDTtable<T>* TDTPMeasure::set(TUCounts* aTUCounts)
	{
	TDTtable<T>* result=new TDTtable<T>(aTUCounts->haplotypeTUCountsVector, NULL, 0, minFreq);
	if (result==NULL || result->partition==NULL || result->getTotalHeteroGenotypes()==0) {zap(result);return NULL;}

	return result;
	  //   cout <<"table after semi:\n" << *tdtTable <<"\n";
	}


	/*_____________________________________________________________*/
	/*
		double TDTPMeasure::getPVal()
	  {
	  if (weights!=NULL)
	  {
	   if (tdtTable==NULL) throw NullValue("double TDTPMeasure::getPVal()");
	  if (!independentCols) return pdfTestWeightedChiSquareTDT(getStatistic(), weights);
	  else return pdfTestWeightedChiSquareTDT2(getStatistic()*(tdtTable->getYDim()-1)/(double)tdtTable->getYDim(), weights);
	  }
	  else return 1;
	  }

		/*_____________________________________________________________*/



template<class T>		double TDTPMeasure<T>::getPVal ( int position, int subsample )
	{
//cout <<"subsample is:" << subsample << "\n";
//if (weights==NULL) cout <<"null weights\n"; else cout << *weights <<"\n";
if (subsample==0) 
{
if (this->tdtTable==NULL) return 1; 
	if ( !independentCols ) 	return pdfTestWeightedChiSquareTDT ( this->tdtTable->getWeightedStatistic ( weights ), weights );
		else  return pdfTestWeightedChiSquareTDT2 ( this->tdtTable->getWeightedStatistic ( weights ) * ( this->tdtTable->getYDim()-1 ) / ( double ) this->tdtTable->getYDim(), weights );
}
		Container<vector<TDTtable<T>* >, TDTtable<T>* >*tables=this->partialTdtTables;


		if (subsample==2 ) tables=this->partialTrainingTdtTables;
		if ( tables==NULL || tables->getElement ( position ) ==NULL )
			throw BadFormat ( "double TDTPMeasure::getPVal(int position, bool testing)" );

		if ( partialWeights[position ]==NULL && this->partialTrainingTdtTables->getElement ( position ) !=NULL )
			partialWeights[position]=this->partialTrainingTdtTables->getElement ( position )->getHapFreqs();

		if ( !independentCols ) 	return pdfTestWeightedChiSquareTDT ( tables->getElement ( position )->getWeightedStatistic ( partialWeights[position] ), partialWeights[position ] );
		else  return pdfTestWeightedChiSquareTDT2 ( tables->getElement ( position )->getWeightedStatistic ( partialWeights[position] ) * ( tables->getElement ( position )->getYDim()-1 ) / ( double ) tables->getElement ( position )->getYDim(), partialWeights[position ] );

	}
	/*_____________________________________________________________*/


template<class T>		double TDTPMeasure<T>::getPVal()
	{
		try
		{
			double result=1;
//cout << "here\n";
//cout << "total folds:" << totalFolds <<"\n";
//cout << "independent tablesr:" << independentCols <<"\n";
			if ( this->partialTdtTables==NULL || this->partialTdtTables->size() ==0 )
			{
				if ( this->tdtTable==NULL ) return 1;
				if ( weights==NULL ) weights=this->tdtTable->getHapFreqs();
//cout <<"weights basic: " << *weights <<"\n";
//cout <<*tdtTable <<"\n";
				if ( !independentCols ) return pdfTestWeightedChiSquareTDT ( getStatistic(), weights );
				else return pdfTestWeightedChiSquareTDT2 ( getStatistic() * ( this->tdtTable->getYDim()-1 ) / ( double ) this->tdtTable->getYDim(), weights );
			}
			int totalOutcomes=0;
//cout << "now total folds:" << totalFolds <<"\n";
//cout << "independent tablesr:" << independentCols <<"\n";
//cout << "total tables:" << partialTdtTables->size() <<"\n";
			for ( typename Container<vector<TDTtable<T> >, TDTtable<T> >::iterator it=this->partialTdtTables->begin(); it<this->partialTdtTables->end(); it++ )
			{
				if ( this->partialTdtTables->getElement ( it ) !=NULL )
				{
//cout << "result before substracting is:" << result << "\n";

					result=result*this->getPVal ( this->partialTdtTables->getPosition ( it ), true );

//cout << "statistic in tdtP is:" << partialTdtTables->getElement ( it )->getWeightedStatistic(partialWeights[partialTdtTables->getPosition ( it ) ]) << "\n";
					totalOutcomes++;
				}
			}
//cout << "result before is:" << result << " and no wis:" << result/totalFolds <<"\n";


			if ( totalOutcomes>0 ) return pdfTestqfast ( result,this->totalFolds ); else return 1;




//if  (partialTdtTables->size()==2 && sumOfHalves) return getPValSumOfHalfNormal(getStatistic());
			//		return pdfTestChiSquare ( getStatistic(),testMode );

		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from TDTPMeasure::getPVal()" ); throw;};

	}



	/*_____________________________________________________________*/


template<class T>		void TDTPMeasure<T>::onePrint ( ostream& out, GeneticCounts<T>* aTuCounts, TDTtable<T>* aTDTtable, int subsample, int position)
	{
		if ( weights!=NULL )
			out <<"Hap freqs:" << *getWeights() <<"\n";
		GroupBasedTDTMeasure<T>::onePrint ( out, aTuCounts, aTDTtable, subsample, position);
	}

};

#endif
