#ifndef __TDTMeasure_cpp__
#define __TDTMeasure_cpp__




/*_____________________________________________________________*/
/*
void print(BIOS::TDTMeasure *t){
	cout << *t << endl;
}
*/

/*_____________________________________________________________*/


namespace BIOS {		



/*_____________________________________________________________*/


template<class T> TDTMeasure<T>::TDTMeasure(GeneticCounts<T>* tuCounts, double minFreq, bool permutations, int testMode, GeneticCounts<T>** partialTuCountsTraining, GeneticCounts<T>** partialTuCountsTest, bool useDistance, bool lengthDistance):GroupBasedTDTMeasure<T> (tuCounts, minFreq, testMode, partialTuCountsTraining, partialTuCountsTest, permutations, useDistance, lengthDistance)
{
//if (tuCounts==NULL || tdtTable==NULL || tdtTable->partition==NULL) {zap(tdtTable);return;}
if (testMode==-1) this->totalMultipleTest=this->tdtTable->partition->size(); // Bonferroni correction
this->setAll();

		};




	
/*___________________________________________________________________________________*/

template<class T> TDTMeasure<T>::TDTMeasure(double minFreq, bool permutations, int testMode, bool useDistances, bool lengthDistances):GroupBasedTDTMeasure<T> (minFreq, testMode, permutations, useDistances, lengthDistances)
{
		};

/*___________________________________________________________________________________*/


template<class T> 		TDTMeasure<T>::~TDTMeasure(){
//cout <<"qqqqqqqqqq\n";
			}
			
/*____________________________________________________________ */
/*
TDTtable* TDTMeasure::set(TUCounts* aTUCounts)
{
TDTtable* result=new TDTtable(aTUCounts->haplotypeTUCountsVector, NULL, 0, minFreq);
if (result==NULL || result->partition==NULL || result->getTotalHeteroGenotypes()==0) {zap(result);return NULL;}

return result;
  //   cout <<"table after semi:\n" << *tdtTable <<"\n";
}	
/*___________________________________________________________________________________*/
 
 
template<class T>  string TDTMeasure<T>::getName()
 {
 string result=string("mTDT");




if (this->testMode==-1) result=result+string("_Bonferroni");
 if ( this->testMode==0 ) result=result+string ( "_noCorrection" );
 if (this->testMode==1) result=result+string("_holdout");
 if (this->testMode>=2) result=result+string("_cv")+tos(this->testMode);
if ( this->useDistances ) 
  if (this->lengthDistance) result=result+string ( "_useLengthDistances" );
  else result=result+string ( "_useBiosDistances" );




 if (this->minFreq!=0) result=result+string("_minFreq")+tos(this->minFreq);
 if (this->permutations) result=result+this->addPermutationsInName();
 return result;
 };
/*___________________________________________________________________________________*/


template<class T> TDTMeasure<T>*		TDTMeasure<T>::clone(){
return new TDTMeasure<T>(*this);
			}

/*___________________________________________________________________________________*/



template<class T> TDTMeasure<T>*		TDTMeasure<T>::getNewMeasure(GenericCounts* tuCounts, GenericCounts** training, GenericCounts** test){
return new TDTMeasure<T>((GeneticCounts<T>*)tuCounts, this->minFreq, this->permutations, this->testMode, (GeneticCounts<T>**)training, (GeneticCounts<T>**)test, this->useDistances, this->lengthDistance);
			}
	/*_________________________________________________________________________________________________*/

template<class T> 	double TDTMeasure<T>::getStatistic()
	{
		double result=0;
		if ( this->partialTdtTables==NULL || this->partialTdtTables->size() ==0 ) return Chi2TDTMeasure<T>::getStatistic();
		for ( typename Vector<TDTtable<T>*>::Class::iterator it=this->partialTdtTables->begin(); it<this->partialTdtTables->end(); it++ )
		{
			if ( this->partialTdtTables->getElement ( it ) !=NULL )
				result=result+this->partialTdtTables->getElement ( it )->getStatistic();// using sum of chi squares 1 df
		}
  return result/this->totalFolds; 
	}
	/*_____________________________________________________________*/
/*

	double TDTMeasure::getPVal()
	{
		try
		{
		int minDF;
			double result=0, totalOutcomes=0;


			if ( partialTdtTables==NULL || partialTdtTables->size() ==0 ) // testMode<1
			return Chi2TDTMeasure::getPVal();

 // if (testMode>=2) return pdfTestChiSquare ( getStatistic(),testMode );

// for holdout (testMode=1)
result=totalFolds;
for ( TDTtableVector::iterator it=partialTdtTables->begin(); it<partialTdtTables->end(); it++ )
			if ( partialTdtTables->getElement ( it ) !=NULL )
{
//cout << "statistic in tdt is:" << partialTdtTables->getElement ( it )->getStatistic() << "\n";
				result=result+pdfTestChiSquare(partialTdtTables->getElement ( it )->getStatistic(), partialTdtTables->getElement ( it )->getYDim()-1)-1;// using sum of chi squares 1 df
}
		return result/totalFolds;

	}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from TDTMeasure::getPVal()" ); throw;};

}





/*____________________________________________________________ */
/*
TDTtable* TDTMeasure::set(TUCounts* aTUCounts)
{
TDTtable* result=new TDTtable(aTUCounts->haplotypeTUCountsVector, NULL, 0, minFreq);
if (result==NULL || result->partition==NULL || result->getTotalHeteroGenotypes()==0) {zap(result);return NULL;}

return result;
  //   cout <<"table after semi:\n" << *tdtTable <<"\n";
}



/*_________________________________________________________________________________________________*/
/*
		void TDTMeasure::onePrint(ostream& out, TUCounts* aTuCounts, TDTtable* aTDTtable)
{
try
{
doubleList* tl, *ul, *homol;
if (aTdtTable!=NULL && aTdtTable->partition!=NULL)
{
//cout <<*tdtTable;
//cout <<"--------------";
aTdtTable->partition->setDelimiters('\0', '\n');
aTdtTable->partition->setOutputSeparator('\0');
aTdtTable->partition->setOutputSeparatorForInternalContainers(' ');
aTdtTable->partition->setDelimitersForInternalContainers('\0', ' ');
if (aTuCounts==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)A");
if (aTuCounts->getParentalGenotypes()==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)");
if (aTuCounts->getParentalGenotypes()->getPositions()==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)C");
if (aTuCounts->getPositions()==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)-2");
out << aTuCounts->getParentalGenotypes()->getPositions()[aTuCounts->getPositions()[0]] <<": ";
out << getPVal();
out << " Haplotypes: " << *aTdtTable->partition;
tl=aTdtTable->getCounts(t);
ul=aTdtTable->getCounts(u);
homol=aTdtTable->getHomoCounts();
out <<"T: " << *tl <<"U: " << *ul <<"H: " << *homol;
 zap(ul);zap(tl); zap(homol);
}
else out <<"null tdt table\n\n\n";
}
catch (BasicException& be){be.addMessage("\ncalled from Chi2TDTMeasure::print(ostream& out)"); throw;};
		};

	*/
};

#endif
