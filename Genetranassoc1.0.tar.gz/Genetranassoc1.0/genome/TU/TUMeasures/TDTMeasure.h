#ifndef __TDTMeasure_h__
#define __TDTMeasure_h__

namespace BIOS {
	
  /**
     @memo TDTMeasure
     @doc
     Definition:
	Table to store T/U frecuencies for the TDT algorithm

     @author María del Mar Abad Grau
     @version 1.0
	
	*/	
template<class T> class TDTMeasure: public GroupBasedTDTMeasure<T> {
    
		public:
	

		/**
		*	Constructor
		*/		

	//	TDTMeasure(int minFreq=10, bool permutations=false);

		/**
		*	Destructor
		*/	
	
	virtual	~TDTMeasure();

virtual TDTMeasure* clone();

		/**
		*	Constructor 
		*	@param minFreq Min number of counts in an haplotype to be used
		*/		


	
TDTMeasure(GeneticCounts<T>* tuCounts, double minFreq=10, bool permutations=false, int testMode=2, GeneticCounts<T>** partialTuCountsTraining=NULL, GeneticCounts<T>** partialTuCountsTest=NULL, bool useDistance=true, bool lengthDistance=false);


//virtual TDTtable* set(TUCounts* aTUCounts);


TDTMeasure(double minFreq=10, bool permutations=false, int testMode=2, bool useDistances=true, bool lengthDistance=false);





// stringList* getFreqsResults();

		/**
		*	Calculate statistic from the tables 
		*/

virtual TDTMeasure* getNewMeasure(GenericCounts* tuCounts, GenericCounts** training=NULL, GenericCounts** test=NULL);


//virtual stringList*  getHeadFile();

virtual string getName();//{return string("mTDT");};
//		virtual void printOne(ostream& out, TUCounts* aTuCounts, TDTtable* aTDTtable);

virtual double getStatistic();

	//virtual double getPVal();
//virtual ostream& print(ostream&);
	};


//ostream& operator<<(ostream& out, TDTMeasure& l);


};

#endif
