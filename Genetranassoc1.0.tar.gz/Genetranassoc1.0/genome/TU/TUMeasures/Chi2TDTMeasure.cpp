#ifndef __Chi2TDTMeasure_cpp__
#define __Chi2TDTMeasure_cpp__




namespace BIOS {



template<class T> 		Chi2TDTMeasure<T>::Chi2TDTMeasure(GeneticCounts<T>* tuCounts, double minFreq, bool permutations, bool left):SimpleTUMeasure<T>(tuCounts, minFreq, permutations, left)
{
try
{
this->tdtTable=NULL;
//if (tuCounts!=NULL && tuCounts->haplotypeTUCountsVector->size()==0)
//throw BadFormat("Chi2TDTMeasure::Chi2TDTMeasure(TUCounts* tuCounts, double minFreq, bool permutations, bool left)");
if (tuCounts!=NULL && tuCounts->haplotypeCountsVector->size()>0)
{
//cout << "Chi2TDTMeasure const\n";
tdtTable=new TDTtable<T>(tuCounts->getHaplotypeCountsVector(), NULL, 0, minFreq);
//zap(tdtTable);
//cout << "after const\n";
if (tdtTable==NULL || tdtTable->partition==NULL || tdtTable->getTotalHeteroGenotypes()==0)
zap(tdtTable);
}
}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from Chi2TDTMeasure::Chi2TDTMeasure(TUCounts* tuCounts, double minFreq..." ); throw;};
		};

/*_________________________________________________________________*/

template<class T> 			Chi2TDTMeasure<T>::Chi2TDTMeasure(double minFreq, bool permutations, bool left):SimpleTUMeasure<T>(minFreq, permutations)
{
tdtTable=NULL;
this->minFreq=minFreq;
if (permutations) this->minFreq=0;
tdtTable=NULL;
};

/*___________________________________________________________________________________*/


template<class T> 	Chi2TDTMeasure<T>*	Chi2TDTMeasure<T>::inferMeasure(GeneticCounts<T>* tuCounts)
{
if (tuCounts==NULL) 
throw NullValue("Chi2TDTMeasure*	Chi2TDTMeasure::inferMeasure(TUCounts* tuCounts)");


//if (tdtTable==NULL) throw NullValue("Chi2TDTMeasure::inferMeasure(TUCounts* tuCounts)");
Chi2TDTMeasure* result=this->clone();
//result->setTestMode(0);


//cout <<"result: " << *result <<"\n";
//zap(result->tuCounts);

//cout << *this <<"\n";
//cout << *this->tuCounts->haplotypeTUCountsVector <<"\n";
if (result->tdtTable!=NULL) 
{

result->tdtTable->update(tuCounts);

//cout << *result <<"\n";

if (result->tdtTable!=NULL && result->tdtTable->partition==NULL) zap(result->tdtTable);
}
result->counts = tuCounts;
//cout << *tuCounts->haplotypeTUCountsVector <<"\n";

// TUCounts* other=tuCounts->clone();
// zap(other);

return result;
}
/*_________________________________________________________________*/
/*

		Chi2TDTMeasure::Chi2TDTMeasure(bool permutations):TUMeasure(permutations){
    minFreq=0;
		};
		
		/*_________________________________________________________________*/

template<class T> 			Chi2TDTMeasure<T>::Chi2TDTMeasure(Chi2TDTMeasure& other):SimpleTUMeasure<T>(other){
    this->minFreq=other.minFreq;
    if (other.tdtTable==NULL) tdtTable=NULL;
    else this->tdtTable=new TDTtable<T>(*other.tdtTable);
		};


/*_________________________________________________________________*/

template<class T> 			Chi2TDTMeasure<T>::~Chi2TDTMeasure(){
  zap(tdtTable);
		};

/*_________________________________________________________________*/
/*
		Chi2TDTMeasure* Chi2TDTMeasure::clone(){
  return new Chi2TDTMeasure(*this);
		};
/*________________________________________________________________________________*/



template<class T> 			double Chi2TDTMeasure<T>::getStatistic()
		{
  if (tdtTable!=NULL)
    return tdtTable->getStatistic();
  else return 0;
		};

/*_____________________________________________________________________________________________________________*/



template<class T> 			TDTtable<T>* Chi2TDTMeasure<T>::getTDTtable()
		{
  return tdtTable;
		};


/*_____________________________________________________________*/

template<class T> 			double Chi2TDTMeasure<T>::getWeightedStatistic(doubleList* weights)
		{
  if (tdtTable==NULL) return 0;
		return tdtTable->getWeightedStatistic(weights);
		};


/*_____________________________________________________________*/
/*
	double Chi2TDTMeasure::getWeightedPVal(doubleList* weights,bool chi2)
  {
  if (chi2) return pdfTestWeightedChiSquareTDT(getStatistic(weights), weights);  
  else return getPValWithPermutations();
  }


/*_____________________________________________________________*/
/*
double Chi2TDTMeasure::getPValWithPermutations()
{
return TUMeasure::getPVal();
}

/*_____________________________________________________________*/

template<class T> 	double Chi2TDTMeasure<T>::getPVal()
{
try
{
double result;
if (tdtTable==NULL) return 1;
if (this->permutations) return SimpleTUMeasure<T>::getPVal();
result=pdfTestChiSquare(getStatistic(),tdtTable->getYDim()-1);
if (isNAN(result)) 
{
cout << *tdtTable <<"\n";
cout <<"totalheteros:" << tdtTable->getTotalHeteroGenotypes()<<"\n";
cout << "statistic is: " << getStatistic();
throw NanValue(" Chi2TDTMeasure::getPVal()");
}
return result;
}
catch (BasicException& be) {be.addMessage ("\ncalled from Chi2TDTMeasure::getPVal()"); throw;};
}

/*_____________________________________________________________*/

template<class T> 	doubleList* Chi2TDTMeasure<T>::getHapFreqs()
{
if (tdtTable==NULL) return NULL;
return tdtTable->getHapFreqs();
}

/*_____________________________________________________________*/

template<class T> 	stringList*  Chi2TDTMeasure<T>::getHeadFile()
 {

stringList *result=new stringList();
result->insertElement(string("Pos: pVal Haplotypes: // T: Counts for T // U: Counts for U"));
return result;
};


/*_________________________________________________________________________________________________*/

template<class T> 			void Chi2TDTMeasure<T>::print(ostream& out)
{
try
{
throw NonImplemented("Chi2TDTMeasure::print(ostream& out)");
}
catch (BasicException& be){be.addMessage("\ncalled from Chi2TDTMeasure::print(ostream& out)"); throw;};
}
/*_________________________________________________________________________________________________*/

/*_________________________________________________________________________________________________*/
/*
		void Chi2TDTMeasure::print(ostream& out)
{
try
{
doubleList* tl, *ul, *homol;
if (tdtTable!=NULL && tdtTable->partition!=NULL)
{
//cout <<*tdtTable;
//cout <<"--------------";
tdtTable->partition->setDelimiters('\0', '\n');
tdtTable->partition->setOutputSeparator('\0');
tdtTable->partition->setOutputSeparatorForInternalContainers(' ');
tdtTable->partition->setDelimitersForInternalContainers('\0', ' ');
if (tuCounts==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)A");
if (tuCounts->getParentalGenotypes()==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)");
if (tuCounts->getParentalGenotypes()->getPositions()==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)C");
if (tuCounts->getPositions()==NULL) throw NullValue("Chi2TDTMeasure::print(ostream& out)-2");
out << tuCounts->getParentalGenotypes()->getPositions()[tuCounts->getPositions()[0]] <<": ";
out << getPVal();
out << " Haplotypes: " << *tdtTable->partition;
tl=tdtTable->getCounts(t);
ul=tdtTable->getCounts(u);
homol=tdtTable->getHomoCounts();
out <<"T: " << *tl <<"U: " << *ul <<"H: " << *homol;
 zap(ul);zap(tl); zap(homol);
}
else out <<"null tdt table\n\n\n";
}
catch (BasicException& be){be.addMessage("\ncalled from Chi2TDTMeasure::print(ostream& out)"); throw;};
		};

/*_____________________________________________________________*/




};

#endif
