#ifndef __G2Measure_cpp__
#define __G2Measure_cpp__




/*_____________________________________________________________*/
/*
template <class T> void print ( BIOS::G2Measure<T> *t )
{
	cout << *t << endl;
}


/*_____________________________________________________________*/


namespace BIOS
{

template <class T> 	G2Measure<T>::G2Measure ( GeneticCounts<T>* tuCounts, double minFreq, int testMode, GeneticCounts<T>** partialTuCountsTraning, GeneticCounts<T>** partialTuCountsTest, bool useDistances, bool lengthDistance ) :GroupBasedTDTMeasure<T> ( tuCounts, minFreq, testMode, partialTuCountsTraning, partialTuCountsTest, false, useDistances, lengthDistance )
	{
		try
		{
			this->totalMultipleTest=0;
			if ( this->testMode==-1 && this->tdtTable!=NULL && this->tdtTable->partition!=NULL ) this->totalMultipleTest=std::pow ( 2, ( double ) this->tdtTable->partition->size()-1 )-1;//Bonferroni
			this->setAll();
//cout <<"g2 is: " <<*this <<"\n";
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from G2Measure::G2Measure(GeneticCounts<T>* tuCounts, double minFreq, bool left)" ); throw;};
	};

	/*_____________________________________________________________*/

template <class T> 	TDTtable<T>* G2Measure<T>::set ( GeneticCounts<T>* aTUCounts )
	{
// It creates and return a new TDTtable<T> with only two columns, one for each group in 2G algorithm
// T will be HaplotypeTUCountsVector, which inherits from HaplotypeTUCountsList, or HaplotypeCaseControlCountsList
// so both T inherits from HaplotypeCountsList
		try
		{
			TDTtable<T>* result=NULL;
			if ( aTUCounts==NULL ) return NULL;
			//PartitionHaplotypeTUCountsVector* p=new PartitionHaplotypeTUCountsVector();
			Container<vector<T*>, T*> * p=new Container<vector<T*>, T*>();


			TDTtable<T>*  basicTable=new TDTtable<T>((aTUCounts->getHaplotypeCountsVector()), NULL, 0, this->minFreq);

			double totalFirst=basicTable->getTotalFirstRow(), totalSecond=basicTable->getTotalSecondRow();
   zap(basicTable);

			p->insertElement ( new T() );
			p->insertElement ( new T() );



fillPartition(p, aTUCounts->getHaplotypeCountsVector(), totalFirst, totalSecond);
//cout <<"remove p\n";
//cout << "totalelement in first:" << p->getElement(0)->size() <<"\n";
//cout << "totalelement in second:" << p->getElement(1)->size() <<"\n";
//zap( p->getElement(0));
//zap( p->getElement(1));
//			zap ( p );
//cout <<"end rem\n";
//return NULL;

			if ( p->getElement ( 0 )->size() >0 && p->getElement ( 1 )->size() >0 )
				result=new TDTtable<T> ( p );
//else cout <<"noth\n";
//cout << "here af\n" ;
			zap ( p );
//cout << "there\n";
			return result;
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from G2Measure::set()" ); throw;};
	}

	/*_____________________________________________________________*/

template <> 	void G2Measure<HaplotypeTUCountsVector>::fillPartition (Container<vector<HaplotypeTUCountsVector*>, HaplotypeTUCountsVector*> * p, HaplotypeTUCountsVector* hapCountsVector, double totalFirst, double totalSecond )
	{
			HaplotypeTUCounts* h;
			for (HaplotypeTUCountsVector::iterator it=hapCountsVector->begin(); it!=hapCountsVector->end();it++ )
			{
// for each haplotypeTUCounts
				h=hapCountsVector->getElement ( it );
    if (h!=NULL && !h->getHaplotype()->hasAMissingPosition())
				if ( ( ( h->getFirstFrequency()+h->getSecondFrequency() ) ) >=this->minFreq )
				{
//cout << "h is:" << *h <<"\n";
					if ( (h->getFirstFrequency()/(double)totalFirst)>(h->getSecondFrequency()/(double)totalSecond )) {p->getElement ( 0 )->insertHardElement ( h );}
					if ( (h->getFirstFrequency()/(double)totalFirst)<(h->getSecondFrequency()/(double)totalSecond) ) {p->getElement ( 1 )->insertHardElement ( h );}
					//if ( h->frequencyT==h->frequencyU ) p->getElement ( rand() %2 )->insertHardElement ( h );
				}
			}
}
	/*_____________________________________________________________*/

template <> 	void G2Measure<HaplotypeCaseControlCountsVector>::fillPartition (Container<vector<HaplotypeCaseControlCountsVector*>, HaplotypeCaseControlCountsVector*> * p, HaplotypeCaseControlCountsVector* hapCountsVector, double totalFirst, double totalSecond )
	{
			HaplotypeCaseControlCounts* h;
			for (HaplotypeCaseControlCountsVector::iterator it=hapCountsVector->begin(); it!=hapCountsVector->end();it++ )
			{
// for each haplotypeTUCounts
				h=hapCountsVector->getElement ( it );
    if (h!=NULL && !h->getHaplotype()->hasAMissingPosition())
				if ( ( ( h->getFirstFrequency()+h->getSecondFrequency() ) ) >=this->minFreq )
				{
//cout << "h is:" << *h <<"\n";
					if ( (h->getFirstFrequency()/(double)totalFirst)>(h->getSecondFrequency()/(double)totalSecond )) {p->getElement ( 0 )->insertHardElement ( h );}
					if ( (h->getFirstFrequency()/(double)totalFirst)<(h->getSecondFrequency()/(double)totalSecond) ) {p->getElement ( 1 )->insertHardElement ( h );}
					//if ( h->frequencyT==h->frequencyU ) p->getElement ( rand() %2 )->insertHardElement ( h );
				}
			}
}
	/*_____________________________________________________________*/

template <class T> 	G2Measure<T>::G2Measure ( double minFreq, int testMode, bool useDistances, bool lengthDistance ) :GroupBasedTDTMeasure<T> ( minFreq, testMode, false, useDistances, lengthDistance )
	{
		this->totalMultipleTest=0;
	}


	/*_____________________________________________________________*/

template <class T> 	G2Measure<T>::G2Measure ( G2Measure& other ) :GroupBasedTDTMeasure<T> ( other )
	{
		this->totalMultipleTest=other.totalMultipleTest;
	}

	
	/*_________________________________________________________________*/

template <class T> 	G2Measure<T>* G2Measure<T>::getNewMeasure ( GenericCounts* tuCounts, GenericCounts** training, GenericCounts** test )
	{
		try
		{
			return new G2Measure ( (GeneticCounts<T>*)tuCounts, this->minFreq, this->testMode, (GeneticCounts<T>**)training, (GeneticCounts<T>**)test, this->useDistances, this->lengthDistance );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from G2Measure* G2Measure::getNewMeasure(TUCounts* tuCounts, TUCounts** training, TUCounts** test)" ); throw;};
	}

	/*____________________________________________________________________________*/


template <class T> 	G2Measure<T>::~G2Measure()
	{
	};

	/*____________________________________________________________________________*/


template <class T> 	G2Measure<T>*	G2Measure<T>::clone()
	{
		return new G2Measure ( *this );
	};

	/*____________________________________________________________________________*/

template <class T> 	string G2Measure<T>::getName()
	{
		string result=string ( "mTDT2G" );
		if ( this->testMode==0 ) result=result+string ( "_noCorrection" );
		if ( this->testMode==-1 ) result=result+string ( "_Bonferroni" );
		if ( this->testMode>=2 ) result=result+string ( "_cv" ) +tos ( this->testMode );
		if ( this->testMode==1 ) result=result+string ( "_holdout" );
		if ( this->useDistances ) 
  if (this->lengthDistance) result=result+string ( "_useLengthDistances" );
  else result=result+string ( "_useBiosDistances" );
		if ( this->minFreq!=0 ) result=result+string ( "_minFreq" ) +tos ( this->minFreq );
//if (permutations) result=result+string("_")+tos(tuCounts->getTotalPermutations())+string("permutations");
		return result;
	}
	/*_________________________________________________________________*/

template <class T> 	stringList*  G2Measure<T>::getHeadFile()
	{
		stringList *result=new stringList();
		result->insertElement ( string ( "FirstSNP" ) );
		result->insertElement ( string ( "pVal " ) );
		result->insertElement ( string ( "TotalUsedDifferentHaplotypesInG1 // " ) );
		result->insertElement ( string ( "T/U G1 // " ) );
		result->insertElement ( string ( "TotalUsedDifferenteHaplotypesInG2 //" ) );
		result->insertElement ( string ( "T/U G2" ) );
		return result;
	};

	/*_____________________________________________________________*/

	
template <class T> 		double G2Measure<T>::getOR()
	  {
	  try
	{
double result=0; 
if (this->partialTdtTables==NULL  || this->partialTdtTables->size()==0) return this->tdtTable->getValue ( 0,0 )/(double)this->tdtTable->getValue(1,0);
for (typename Vector<TDTtable<T>*>::Class::iterator it=this->partialTdtTables->begin(); it<this->partialTdtTables->end(); it++)
{
if (this->partialTdtTables->getElement(it)!=NULL)
result=result+this->partialTdtTables->getElement(it)->getValue(0,0)/(double)this->partialTdtTables->getElement(it)->getValue(1,0);
}
return result;
}
	catch (BasicException& be) {be.addMessage ("\ncalled from GroupBasedTDTMeasure::getPVal()"); throw;};

	  }


	/*____________________________________________________________________________________________*/

template <class T> 	bool G2Measure<T>::getOneSide()
	{
		return false;
	}

/*_____________________________________________________________________________________________________________*/


template <class T> 	void G2Measure<T>::parentalPrinting ( ostream& out, GeneticCounts<T>* aTuCounts)
	{
try
{
out << aTuCounts->getPositions() [0] <<"\t";
}
	catch ( BasicException& be ) {be.addMessage ( "\ncalled from template <class T> 	void G2Measure<T>::parentalPrinting ( ostream& out, GeneticCounts<T>* aTuCounts)" ); throw;};
}

/*_____________________________________________________________________________________________________________*/


template <> 	void G2Measure<HaplotypeTUCountsVector>::parentalPrinting ( ostream& out, GeneticCounts<HaplotypeTUCountsVector>* aTuCounts)
	{
try
{
out << aTuCounts->getParentalGenotypes()->getPositions() [aTuCounts->getPositions() [0]] <<"\t";
}
	catch ( BasicException& be ) {be.addMessage ( "\ncalled from template <class T> 	void G2Measure<T>::parentalPrinting ( ostream& out, GeneticCounts<T>* aTuCounts)" ); throw;};
}
	/*_____________________________________________________________________________________________________________*/


template <class T> 	void G2Measure<T>::onePrint ( ostream& out, GeneticCounts<T>* aTuCounts, TDTtable<T>* aTDTtable, int subsample, int position )
	{
try
{
//cout <<*aTDTtable <<"\n";
  if (aTuCounts==NULL)
  out << "no counts";
  else
  {
  parentalPrinting(out, aTuCounts); 
		if ( aTDTtable!=NULL )
		{
			for ( int i=1; i<3; i++ )
			{
				aTDTtable->partition->getElement ( i-1 )->setDelimiters ( '\0', '\0' );
//if (i==2) out <<"\n";
   out << this->getPVal(position, subsample) << "\t";
				out << "G" << i <<":\t" << *aTDTtable->partition->getElement ( i-1 );
				out <<"\tT:\t" << aTDTtable->getValue ( 0,i-1 ) << "\tU: \t" << aTDTtable->getValue ( 1,i-1 );
				if ( i==1 ) out <<"\t";
				aTDTtable->partition->getElement ( i-1 )->setDelimiters ( '[', ']' );
			}
		}
		else out <<"nullTable";
  }

	}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void G2Measure<T>::onePrint ( ostream& out, GeneticCounts<T>* aTuCounts, TDTtable<T>* aTDTtable, int subsample, int position )" ); throw;};
//template <class T> TDTtable<T> * BIOS::G2Measure<T>::set(GeneticCounts< T > * aTUCounts)
	
};

}

#endif
