#ifndef __G2TreeMeasure_cpp__
#define __G2TreeMeasure_cpp__




/*_____________________________________________________________*/
/*
void print ( BIOS::G2TreeMeasure *t )
{
	cout << *t << endl;
}


/*_____________________________________________________________*/


namespace BIOS
{

	template<class T>	G2TreeMeasure<T>::G2TreeMeasure ( GeneticCounts<T>* tuCounts, double s, double minFreq, int testMode, GeneticCounts<T>** partialTuCountsTraning, GeneticCounts<T>** partialTuCountsTest, bool useDistances, bool lengthDistance ) :G2Measure<T> ( tuCounts, minFreq, testMode, partialTuCountsTraning, partialTuCountsTest, useDistances, lengthDistance )
	{
		try
		{
			//cout << "next G2tree constructor \n";
			this->s=s;
			if ( s<2 )
				throw BadFormat ( "G2TreeMeasure::G2TreeMeasure ( TUCounts* tuCounts, double s, double minFreq, int testMode, TUCounts** partialTuCountsTraning, TUCounts** partialTuCountsTest, bool useDistances )" ); // Beta distribution may be sparsed
			zap ( this->tdtTable );
			zap ( this->partialTrainingTdtTables );
			zap ( this->partialTdtTables );
			this->setAll();
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from G2TreeMeasure::G2TreeMeasure(TUCounts* tuCounts, double minFreq, bool left)" ); throw;};
	};

	/*_____________________________________________________________*/



	template<class T>		double G2TreeMeasure<T>::getTotalCounts (	HaplotypeVector * g, GeneticCounts<T>* aTUCounts, intSet* hapPos )
	{
		double totalCounts=0;
		HaplotypeCounts* h=NULL;
		Haplotype *hap=NULL;
		for ( typename T::iterator it=aTUCounts->haplotypeCountsVector->begin(); it!=aTUCounts->haplotypeCountsVector->end();it++ )
		{
			h= aTUCounts->haplotypeCountsVector->getElement ( it );
			hap=h->getHaplotype();
			for ( intSet::iterator it=hapPos->begin(); it!=hapPos->end(); it++ )
				if ( *g->getElement ( *it ) ==*hap ) {totalCounts=totalCounts+h->getFirstFrequency() +h->getSecondFrequency(); break;}
		}
		return totalCounts;
	}

	/*_____________________________________________________________*/

	template<class T>		TDTtable<T>* G2TreeMeasure<T>::set ( GeneticCounts<T>* aTUCounts )
	{
// It creates and return a new TDTtable with only two columns, one for each group in 2GTree algorithm
		try
		{
			int position=0;
			if ( this->lengthDistance ) position=-1;
			Haplotype* hap=NULL;
			TDTtable<T>* result=NULL;
			if ( aTUCounts==NULL ) return NULL;
			double sumT1=0, sumT2=0, sumU1=0, sumU2=0, distanceG1, distanceG2;
			intSet* minPosT, *minPosU;
			FreqAndKeyVector* fk=new FreqAndKeyVector();
			FreqAndKey* element;
			int pos=0;
			HaplotypeCounts* h;
// it first create a vector fk with the haploypes in the data set ordered by frequencies
			for ( typename T::iterator it=aTUCounts->haplotypeCountsVector->begin(); it!=aTUCounts->haplotypeCountsVector->end();it++ )
			{
				h= aTUCounts->haplotypeCountsVector->getElement ( it );
				if ( h->getFirstFrequency() +h->getSecondFrequency() >0 )
				{
					element=new FreqAndKey ( std::pow ( h->getFirstFrequency()-h->getSecondFrequency(),2 ) / ( double ) ( h->getFirstFrequency() +h->getSecondFrequency() ), pos );
					fk->insertElement ( element );
				}
				pos++;
			}
//cout << "end pos \n"; //is:" << (void*)fk->getLast();
			fk->sort ( false );

			// now it creates p, a vector with the high and low risk haplotypes (g1 and g2 respectively).

			TDTtable<T>*  basicTable=new TDTtable<T> ( (aTUCounts->getHaplotypeCountsVector() ), NULL, 0, this->minFreq );
			double totalFirst=basicTable->getTotalFirstRow(), totalSecond=basicTable->getTotalSecondRow();
			zap ( basicTable );

			Container<vector<T*>, T*> * p=new Container<vector<T*>, T*>();
			p->insertElement ( new T() );
			p->insertElement ( new T() );
			HaplotypeVector * g1=new HaplotypeVector(), *g2=new HaplotypeVector();
			double tFreq, uFreq, totalHaps1, totalHaps2;
			for ( int i=0; i<fk->size(); i++ )
			{
				h=aTUCounts->haplotypeCountsVector->getElement ( fk->getElement ( i )->second() );
				if ( h!=NULL && !h->getHaplotype()->hasAMissingPosition() )
				{
					hap=h->getHaplotype()->clone();
					tFreq=h->getFirstFrequency() +s/2; // Beta (s/2,s/2), by default is s=2 so Beta(1,1), a uniform distribution on [0,1]
					uFreq=h->getSecondFrequency() +s/2;
					if ( g1->size() >0 && g2->size() >0 ) // in case there are at least one haplotype in each group already
					{
						minPosT=g1->getPositionsWithMinDistance ( hap,  position, false );
						distanceG1=hap->getDistance ( g1->getElement ( minPosT->getElement ( 0 ) ), position, false );
						minPosU=g2->getPositionsWithMinDistance ( hap, position, false );
						distanceG2=hap->getDistance ( g2->getElement ( minPosU->getElement ( 0 ) ), position, false );
						if ( distanceG1<distanceG2 )
						{
							tFreq=tFreq+s-s/4-s/2;//prior beta is Beta(s-0.5,0.5), by default Beta(1.5,0.5)
							uFreq=uFreq+s/4-s/2;
						}
						if ( distanceG1>distanceG2 )
						{
							uFreq=uFreq+s-(s/(double)4)-s/2; //prior beta is Beta(0.5,s-0.5), by default Beta(0.5,1.5)
							tFreq=tFreq+(s/(double)4)-s/2;
						}
						if ( distanceG1==distanceG2 )
						{
							totalHaps1=getTotalCounts ( g1, aTUCounts, minPosT );
							totalHaps2=getTotalCounts ( g2, aTUCounts, minPosU );
							tFreq=tFreq-s/2+s/4+totalHaps1 / ( double ) ( totalHaps1 + totalHaps2 );//prior beta is Beta(0.5+p1,0.5+p2), being p1 and p2 the relative frequencies of haplotypes in g1 and g2 with the shortest distance to the current haplotype
							uFreq=uFreq-s/2+s/4+totalHaps2 / ( double ) ( totalHaps1 + totalHaps2 );
						}
						zap ( minPosT );
						zap ( minPosU );
					}
					if ( ( ( h->getFirstFrequency() +h->getSecondFrequency() ) ) >=this->minFreq )
					{
						if ( ( tFreq/ ( double ) totalFirst ) > ( uFreq/ ( double ) totalSecond ) ) {p->getElement ( 0 )->insertHardElement ( aTUCounts->haplotypeCountsVector->getElement ( fk->getElement ( i )->second() ) );g1->insertElement ( hap ); }
						else
							if ( ( tFreq/ ( double ) totalFirst ) < ( uFreq/ ( double ) totalSecond ) ) {p->getElement ( 1 )->insertHardElement ( aTUCounts->haplotypeCountsVector->getElement ( fk->getElement ( i )->second() ) );g2->insertElement ( hap ); }
							else zap ( hap ); //p->getElement ( rand() %2 )->insertHardElement ( h );
					}
					else zap ( hap );
				}
			}
			zap ( fk );
			zap ( g1 );
			zap ( g2 );
			if ( p->getElement ( 0 )->size() >0 && p->getElement ( 1 )->size() >0 )
				result=new TDTtable<T> (p );
			zap ( p );
			return result;
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from G2TreeMeasure::set()" ); throw;};
	}

	/*_____________________________________________________________*/

	template<class T>		G2TreeMeasure<T>::G2TreeMeasure ( double s, double minFreq, int testMode, bool useDistances, bool lengthDistance ) :G2Measure<T> ( minFreq, testMode, useDistances, lengthDistance )
	{
		this->s=s;
	}


	/*_____________________________________________________________*/

	template<class T>	G2TreeMeasure<T>::G2TreeMeasure ( G2TreeMeasure<T>& other ) :G2Measure<T> ( other )
	{
		s=other.s;
	}


	/*_________________________________________________________________*/

	template<class T>	G2TreeMeasure<T>* G2TreeMeasure<T>::getNewMeasure ( GenericCounts* tuCounts, GenericCounts** training, GenericCounts** test )
	{
		try
		{
			return new G2TreeMeasure ( ( GeneticCounts<T>* ) tuCounts, this->s, this->minFreq, this->testMode, ( GeneticCounts<T>** ) training, ( GeneticCounts<T>** ) test, this->useDistances, this->lengthDistance );
		}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from G2TreeMeasure* G2TreeMeasure::getNewMeasure(TUCounts* tuCounts, TUCounts** training, TUCounts** test)" ); throw;};
	}

	/*_________________________________________________________________*/
	/*
	  G2TreeMeasure* G2TreeMeasure::inferMeasure(TUCounts* tuCounts)
	{
	return new G2TreeMeasure(tuCounts, minFreq);
	}
	/*____________________________________________________________________________*/


	template<class T>		G2TreeMeasure<T>::~G2TreeMeasure()
	{
	};

	/*____________________________________________________________________________*/


	template<class T>		G2TreeMeasure<T>*	G2TreeMeasure<T>::clone()
	{
		return new G2TreeMeasure<T> ( *this );
	};

	/*____________________________________________________________________________*/

	template<class T>		string G2TreeMeasure<T>::getName()
	{
		string result=string ( "mTDT2GTree" );
		if ( this->testMode==0 ) result=result+string ( "_noCorrection" );
		if ( this->testMode==-1 ) result=result+string ( "_Bonferroni" );
		if ( this->testMode>=2 ) result=result+string ( "_cv" ) +tos ( this->testMode );
		if ( this->testMode==1 ) result=result+string ( "_holdout" );
		if ( this->useDistances )
			if ( this->lengthDistance ) result=result+string ( "_useLengthDistances" );
			else result=result+string ( "_useBiosDistances" );
		if ( this->s!=2 ) result=result+string ( "_precision" ) +tos ( this->s );
		if ( this->minFreq!=0 ) result=result+string ( "_minFreq" ) +tos ( this->minFreq );
//if (permutations) result=result+string("_")+tos(tuCounts->getTotalPermutations())+string("permutations");
		return result;
	}
	/*_________________________________________________________________*/
	/*
		stringList*  G2TreeMeasure::getHeadFile()
		{
			stringList *result=new stringList();
			result->insertElement ( string ( "FirstSNP" ) );
			result->insertElement ( string ( "pVal " ) );
			result->insertElement ( string ( "TotalUsedDifferentHaplotypesInG1 // " ) );
			result->insertElement ( string ( "T/U G1 // " ) );
			result->insertElement ( string ( "TotalUsedDifferenteHaplotypesInG2 //" ) );
			result->insertElement ( string ( "T/U G2" ) );
			return result;
		};

		/*_____________________________________________________________*/

	/*
		double G2TreeMeasure::getOR()
		{
			try
			{
				double result=0;
				if ( partialTdtTables==NULL  || partialTdtTables->size() ==0 ) return tdtTable->getValue ( 0,0 ) / ( double ) tdtTable->getValue ( 1,0 );
				for ( TDTtableVector::iterator it=partialTdtTables->begin(); it<partialTdtTables->end(); it++ )
				{
					if ( partialTdtTables->getElement ( it ) !=NULL )
						result=result+partialTdtTables->getElement ( it )->getValue ( 0,0 ) / ( double ) partialTdtTables->getElement ( it )->getValue ( 1,0 );
				}
				return result;
			}
			catch ( BasicException& be ) {be.addMessage ( "\ncalled from GroupBasedTDTMeasure::getPVal()" ); throw;};

		}


		/*____________________________________________________________________________________________*/
	/*
		bool G2TreeMeasure::getOneSide()
		{
			return false;
		}
		/*_____________________________________________________________________________________________________________*/

	/*
		void G2TreeMeasure::onePrint ( ostream& out, TUCounts* aTuCounts, TDTtable* aTDTtable )
		{
			if ( aTuCounts==NULL || aTuCounts->getParentalGenotypes() ==NULL )
				out << "no counts";
			else
			{
				out << aTuCounts->getParentalGenotypes()->getPositions() [aTuCounts->getPositions() [0]] <<"\t";
				if ( aTDTtable!=NULL )
				{
					for ( int i=1; i<3; i++ )
					{
						aTDTtable->partition->getElement ( i-1 )->setDelimiters ( '\0', '\0' );
	//if (i==2) out <<"\n";
						out << getPVal() << "\t";
						out << "G" << i <<":\t" << *aTDTtable->partition->getElement ( i-1 );
						out <<"\tT:\t" << aTDTtable->getValue ( 0,i-1 ) << "\tU: \t" << aTDTtable->getValue ( 1,i-1 );
						if ( i==1 ) out <<"\t";
						aTDTtable->partition->getElement ( i-1 )->setDelimiters ( '[', ']' );
					}
				}
				else out <<"nullTable";
			}
		};
	*/
}
#endif
