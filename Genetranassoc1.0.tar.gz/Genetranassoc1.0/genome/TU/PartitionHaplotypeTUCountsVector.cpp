
#ifndef __PartitionHaplotypeTUCountsVector_cpp__
#define __PartitionHaplotypeTUCountsVector_cpp__





void print (BIOS::PartitionHaplotypeTUCountsVector *p)
{
  cout << *p << endl;
}


namespace BIOS
{




  /*_____________________________________________________*/

  PartitionHaplotypeTUCountsVector::PartitionHaplotypeTUCountsVector()
  {
    //split_marker = -1;
  };

  /*_____________________________________________________*/

  PartitionHaplotypeTUCountsVector::PartitionHaplotypeTUCountsVector(PartitionHaplotypeTUCountsVector& other): VectorOfHaplotypeTUCountsVectors(other)
  {
splitMarkers=other.splitMarkers;
    //split_marker = -1;
  };

  /*_____________________________________________________*/


  PartitionHaplotypeTUCountsVector::~PartitionHaplotypeTUCountsVector()
  {
    //for (int i=0; i< size(); i++)
     // delete (*this) [i];

  };

  /*________________________________________________________________________________________*/

  PartitionHaplotypeTUCountsVector* PartitionHaplotypeTUCountsVector::clone()
  {
    return new PartitionHaplotypeTUCountsVector (*this);
  }

 /*_____________________________________________________*/


/*
  void PartitionHaplotypeTUCountsVector::free()
  {
    for (int i=0; i< size(); i++)
      (*this) [i]->free();

  };

  /*_____________________________________________________*/
/*
  template <>
  void VectorOfHaplotypeTUCountsVectors::removeObjects (VectorOfHaplotypeTUCountsVectors::iterator it, VectorOfHaplotypeTUCountsVectors::iterator it2)
  {
    this->erase (it, it2);
  };

  /*_____________________________________________________*/

  double PartitionHaplotypeTUCountsVector::getZstatistic (double proportion)
  {

    // We are interested only in
    // subtrees in which the proportion of disease-associated
    // haplotypes is greater than expected, zi > 0 (i.e., we assume
    // the mutation to increase the risk of the disease). (From 2006.Sevon)


    double z=0;
    double z_i=0;

    // For each haplotype set, Calculate z statistic and p value for the set
    for ( int i=0; i< size(); i++)
    {
      HaplotypeTUCountsVector * hv = (*this) [i];
      z_i = hv->getZstatistic (proportion);
      if ( z_i > 0)
        z += z_i;
    }

    return z;

  };
  /*_____________________________________________________*/

  void PartitionHaplotypeTUCountsVector::insertSubset (HaplotypeTUCountsVector *hv, int splitMarker)
  {
    splitMarkers.push_back (splitMarker);
    push_back (hv);
  }

  /*_____________________________________________________*/

  void PartitionHaplotypeTUCountsVector::insertSubsetCopy (HaplotypeTUCountsVector *hv, int splitMarker)
  {

//     HaplotypeTUCountsVector *v_copy = new HaplotypeTUCountsVector;
//     for ( int h = 0; h < hv->size(); h++){
//       //v_copy->push_back ( (*hv) [h] );
// 		HaplotypeTUCounts * original = (*hv)[h];
// 		v_copy->push_back ( original->clone() );
// 	 }
		HaplotypeTUCountsVector *v_copy = hv->clone();
		

    insertSubset (v_copy, splitMarker);
  }
  /*
  	TDTtable * PartitionHaplotypeTUCountsVector::createTable()
  	{
  		double t_freq, u_freq;
  		TDTtable * t = new TDTtable( size() );

  		// Fill each column
  		for (int i=0; i < size(); i++){
  			t_freq = (*this)[i]->getTransmittedFreqSum();
  			u_freq =  (*this)[i]->getFreqSum() - t_freq;
  			t->setValue(0,i, t_freq);
  			t->setValue(1,i, u_freq);
  		}

  		return t;
  	};
  */




};

#endif
