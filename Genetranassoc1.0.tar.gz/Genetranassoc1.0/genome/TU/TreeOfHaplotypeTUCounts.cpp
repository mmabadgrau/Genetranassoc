

#ifndef __TreeOfHaplotypeTUCounts_cpp__
#define __TreeOfHaplotypeTUCounts_cpp__

//using namespace UTILS;


namespace BIOS
{

  
      /*______________________________________________________________________________________*/

 
template<>    string TreeOfHaplotypeTUCounts::getClassName()
     {
return string("TreeOfHaplotypeTUCounts");
     };

 
template<>   float TreeOfHaplotypeTUCounts::getTotalFrequencyT()
     {
		 	PNode n = getRoot();
			HaplotypeTUCounts *h = *n;
			return h->frequencyT;
// 			return 0;
     };	  

template<>   float TreeOfHaplotypeTUCounts::getTotalFrequencyU()
     {
		 	PNode n = getRoot();
			HaplotypeTUCounts *h = *n;
			return h->frequencyU;
// 			return 0;
     };	  	  
	  
// 	  template<> void TreeOfHaplotypeTUCounts::updateTreeDTScore()
//      {
// 		 updateTreeDTScore(getRoot());
// 	  }
	  

// 			vector<double>* out = new vector<double>;
// 			
// 			// scoretable: Scores for the current node [ Z_k(S) = Sum(z_i) ]
// 			// max scores for the children of current node
// 			double max_scoretable[MAX_SUBTREES], scoretable[MAX_SUBTREES];
// 			int i;			
// 			
// 			return out;
// 
// // 			return 0;
//      };	
	  
	  

/*______________________________________________________*/

// ostream& operator<<(ostream& out, TreeOfHaplotypeTUCounts& p)
// {
// 	for (TreeOfHaplotypeTUCounts::iterator it=p.begin(); it!=p.end(); it++)
// 	  out << *p.getElement(it);
// 
// 	if (p.nodes!=NULL) 
// 		for (SetOfHaplotypeTUCounts::iterator it=p.nodes->begin(); it!=p.nodes->end(); it++)
// 			out << *p.nodes->getElement(it);
// 
// 	return out;
// }

/*______________________________________________________*/



};
;  // Fin del Namespace

#endif

/* Fin Fichero: TreeOfHaplotypeTUCounts.h */
