/* File: MultimarkerMeasure.h */


#ifndef __CaseControlCounts_cpp__
#define __CaseControlCounts_cpp__





//using namespace stats;

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

CaseControlCounts* CaseControlCounts::clone()
{
return new CaseControlCounts(*this);
} 


/*_________________________________________________________________*/

CaseControlCounts::CaseControlCounts(int*pos, int length, HapExtractionConfiguration* hapExtractionConfiguration, HaplotypeCaseControlCountsVector* haplotypeCountsVector, int totalPermutations, GenotypeList*caseGenotypes, GenotypeList* controlGenotypes): GeneticCountsOfCaseControls(pos, length, hapExtractionConfiguration, haplotypeCountsVector, totalPermutations)
{
totalHaps=0;
this->caseGenotypes=caseGenotypes;
this->controlGenotypes=controlGenotypes;
//this->haplotypeCaseControlCountsVector=haplotypeCaseControlCountsVector;
}

/*_________________________________________________________________*/

CaseControlCounts::CaseControlCounts(CaseControlCounts& tu):GeneticCountsOfCaseControls((GeneticCountsOfCaseControls&)tu)
{
caseGenotypes=tu.caseGenotypes->clone();
controlGenotypes=tu.controlGenotypes->clone();
}
 


/*_________________________________________________________________*/

CaseControlCounts::~CaseControlCounts()
{
zap(caseGenotypes);
zap(controlGenotypes);
}

/*_________________________________________________________________*/

CaseControlCounts::CaseControlCounts():GeneticCountsOfCaseControls()
{
caseGenotypes=NULL;
controlGenotypes=NULL;
totalHaps=0;
}

			/*_________________________________________________________________*/

int CaseControlCounts::size()
{
if (totalHaps<0) throw BadFormat("int CaseControlCounts::size()");
if (totalHaps>0) return totalHaps;

for (HaplotypeCaseControlCountsList::iterator it=((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->begin(); it< ((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->end(); it++)
totalHaps=totalHaps+(int)(((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->getElement(it)->frequencyCases)+(int)(((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->getElement(it)->frequencyControls);
return totalHaps;
}


/*_________________________________________________________________*/

void CaseControlCounts::setPermutations()
{
throw NonImplemented("CaseControlCounts::setPermutations()");
}

/*_________________________________________________________________*/

GenotypeList* CaseControlCounts::getCaseGenotypes()
{
return caseGenotypes;
}


/*_________________________________________________________________*/

GenotypeList* CaseControlCounts::getControlGenotypes()
{
return controlGenotypes;
}




				/*_________________________________________________________________*/
	/*
	HaplotypeCaseControlCountsVector::iterator CaseControlCounts::findElement(Haplotype * h)
{
for (HaplotypeCaseControlCountsList::iterator it=((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->begin(); it!=((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->end(); it++)
if (h==((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->getElement(it)->getHaplotype())
return it;
return ((HaplotypeCaseControlCountsList*)haplotypeCountsVector)->end();
	} 
*/



};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */

//stringList * BIOS::CaseControlCounts::getTDTFreqsResults(SNPPos snpPos)
//{
//}






