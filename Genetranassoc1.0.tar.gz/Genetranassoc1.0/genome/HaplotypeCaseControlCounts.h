#ifndef __HaplotypeCaseControlCounts_h__
#define __HaplotypeCaseControlCounts_h__

namespace BIOS
{

	/**
	HaplotypeCaseControlCounts: an haplotype and its transmitted/untransmitted frequencies in a given sample 
**/
	class HaplotypeCaseControlCounts;
	typedef Set<HaplotypeCaseControlCounts*>::Class SetOfHaplotypeCaseControlCounts;



	class HaplotypeCaseControlCounts: public HaplotypeCounts
	{
		

			
		public:



			float frequencyCases;


			float frequencyControls;


			/**
			* Constructor
			*/
			HaplotypeCaseControlCounts ( int size=0 );

		
			HaplotypeCaseControlCounts ( Haplotype* haplotype, float frequencyCases, float frequencyControls );

			HaplotypeCaseControlCounts ( HaplotypeCaseControlCounts& other );

			virtual ~HaplotypeCaseControlCounts();

		void add(int cases, int controls);


			/**
			*	Compares two haplotypes, inluding all properties
			*	@return true if haplotypes are equal
			*/
			virtual bool operator== ( HaplotypeCaseControlCounts & h );

			/**
			*	Compares two haplotypes, inluding all properties
			*	@return true if haplotypes are different
			*/
		//	virtual bool operator!= ( HaplotypeCaseControlCounts & h );


			void sumProps(HaplotypeCaseControlCounts * h);
			


			virtual HaplotypeCaseControlCounts* fromString ( string s ) {throw NonImplemented ( "HaplotypeCaseControlCounts::fromString(string s)" );};

			virtual HaplotypeCaseControlCounts* clone() {return new HaplotypeCaseControlCounts ( *this );};

virtual double getFirstFrequency();

virtual double getSecondFrequency();

virtual double getThirdFrequency();
			/**
			* Prints the HaplotypeCaseControlCounts in the following manner: [ a0 a1 ... an ][frequency][T/U]
			* @param output Output stream
			* @param h Vector to print
			*/
			friend ostream& operator<< ( ostream& output,  HaplotypeCaseControlCounts& h )
			{
h.print(output);
			}

virtual void print(ostream& output);
			/*
						static void print(HaplotypeCaseControlCounts *h){
							for(int i=0; i< h->size()-1; i++)
								printf("%i ", (*h)[i]);
						}
				*/
		//	virtual void print();


	};



};

#endif
