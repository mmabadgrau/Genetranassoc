/* File: MultimarkerMeasure.h */


#ifndef __GeneticCounts_cpp__
#define __GeneticCounts_cpp__





//using namespace stats;

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/



///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */
/*
GeneticCounts* GeneticCounts::clone()
{
return new GeneticCounts(*this);
} 


/*_________________________________________________________________*/

template<class T> GeneticCounts<T>::GeneticCounts(int* pos, int length, HapExtractionConfiguration* hapExtractionConfiguration, T* haplotypeCountsVector, int totalPermutations): GenericCounts(totalPermutations)
{
this->haplotypeCountsVector=haplotypeCountsVector;
this->hapExtractionConfiguration=hapExtractionConfiguration;
this->length=length;
if (pos!=NULL)
{
this->pos=new int[length];
for (int i=0; i<length; i++)
 this->pos[i]=pos[i];
}
else this->pos=NULL;
}

/*_________________________________________________________________*/

template<class T> GeneticCounts<T>::GeneticCounts(GeneticCounts<T>& tu): GenericCounts((GenericCounts&) tu)
{
pos=NULL;
if (tu.pos!=NULL)
{
pos=new int[tu.getTotalPos()];
for (int i=0; i<tu.getTotalPos(); i++)
 pos[i]=tu.pos[i];
}
length=tu.length;
this->hapExtractionConfiguration=tu.hapExtractionConfiguration;
}

 				/*_________________________________________________________________*/
	
template<class T> 	typename T::iterator GeneticCounts<T>::findElement(Haplotype * h)
{
for (typename T::iterator it=haplotypeCountsVector->begin(); it!=haplotypeCountsVector->end(); it++)
if (*h==*haplotypeCountsVector->getElement(it)->getHaplotype())
return it;
return haplotypeCountsVector->end();
	} 



/*_________________________________________________________________*/

template<class T> GeneticCounts<T>::~GeneticCounts ()
{
empty();
}

/*_________________________________________________________________*/

template<class T> void GeneticCounts<T>::empty ()
{
zaparr(pos);


}


	/*_________________________________________________________________*/

template<class T>  T* GeneticCounts<T>::getHaplotypeCountsVector()
{
return haplotypeCountsVector;
}

/*_________________________________________________________________*/

template<class T> GeneticCounts<T>::GeneticCounts(): GenericCounts()
{
length=0;
hapExtractionConfiguration=NULL;
pos=NULL;
}

/*_________________________________________________________________*/

template<class T> void GeneticCounts<T>::print(ostream& out)
       {
try
{
          out <<"size is:" << getTotalPos() <<"\n";
for (int i=0; i<getTotalPos();i++)
out <<"pos at " << i << ": " << pos[i] <<"\n";

out <<*getHapExtractionConfiguration() <<"\n";
}
		catch ( BasicException& be ) {be.addMessage ( "\ncalled from void GeneticCounts<T>::print(ostream& out)" ); throw;};
};



/*_________________________________________________________________*/

template<class T> HapExtractionConfiguration* GeneticCounts<T>::getHapExtractionConfiguration()
{
return hapExtractionConfiguration;
}

  /*_________________________________________________________________*/

template<class T> int GeneticCounts<T>::getTotalPos()
  {
  return length;
  }

  /*_________________________________________________________________*/

template<class T> int* GeneticCounts<T>::getPositions()
  {
  return pos;
  }




};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */

//stringList * BIOS::GeneticCounts::getTDTFreqsResults(SNPPos snpPos)
//{
//}






