#ifndef GenomeMLTest_h//
#define GenomeMLTest_h//



namespace BIOS {




//class InputTUI;

class HapExtractionConfiguration;
////////////////////////////

class GenomeMLTest: public GenericMLTest 
{

/** This class is used as a generalization of any sample (ML Sample, genetic samples, etc.) so that they all can be divided in order to use tests, classifier or any other measure using different testting comfigurations (cross-validation, holdout, training).
*/



protected:



int totalPermutations;

 HapExtractionConfiguration* hapExtractionConfiguration;

virtual int getRealNumberOfAtts();


public:

//GenomeMLTest(char* fileSample, TestModeClass *testMod);
GenomeMLTest(char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int jointRows);
~GenomeMLTest();
virtual GenericCounts* getCounts(GenericSample* ts, int* pos, int size);
virtual GenericSample* getSample(char* file, int* iniPos, int size);
};

} // end namespace
#endif

