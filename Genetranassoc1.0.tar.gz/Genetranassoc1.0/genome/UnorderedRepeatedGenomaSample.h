
/* File: UnorderedRepeatedGenomaSample.h */


#ifndef __UnorderedRepeatedGenomaSample_h__
#define __UnorderedRepeatedGenomaSample_h__


#include "UnorderedRepeatedGenotypeSample.h"
//#include "PhenotypeSample.cpp"
     
        



namespace BIOS {


         class UnorderedRepeatedGenomaSample: public  UnorderedRepeatedGenotypeSample, public PhenotypeSample

 {
	 
       //  public:


    /** @name Implementation of class UnorderedRepeatedGenomaSample
        @memo Private part.
    */




  private:

 

/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* Head */


/////////////////////////



      /* PUBLIC FUNCTIONS (INTERFACE) */

      public:



 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

		UnorderedRepeatedGenomaSample(char* filenamebool,  bool ExistPhen=true);

		void PrintOrderedRepeatedGenoma (char* filename, bool PrintPhenotypes=true);



};  // End of class UnorderedRepeatedGenomaSample



};  // Fin del Namespace

#endif

/* Fin Fichero: UnorderedRepeatedGenomaSample.h */
