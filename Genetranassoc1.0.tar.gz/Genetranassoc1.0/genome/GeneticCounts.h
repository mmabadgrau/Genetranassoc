/* File: PhylogeneticDistance.h */

#ifndef __GeneticCounts_h__
#define __GeneticCounts_h__

//using namespace stats;

namespace BIOS {


/************************/
/* SNP'S MultimarkerMeasure DEFINITION */
/************************/


/**
        @memo Haplotype counts for a given window in a genetic sample

	@doc
        Definition:

       Class used mainly to compute multimarker TU measures or their generalization to case/control samples. In order to similarity measures to can be applied, haplotype counters (or freqs if EM-freq is used) for each couple must be independently kept 

       With this purpose, the data structures required is:
 
       Container<vector, ParentalHaplotypes> *parentalHaps   

        @author Maria M. Abad
	@version 1.0
*/


class HapExtractionConfiguration;

//class HaplotypeCountsVector;

//class GenericHaplotypeCountsVector;


 
template <class T> class	GeneticCounts: public GenericCounts {
// T will be HaplotypeTUCountsVector or HaplotypeCaseControlCountsVector

//class	GeneticCounts: public GenericCounts {


public:

T* haplotypeCountsVector;

protected:

HapExtractionConfiguration* hapExtractionConfiguration;//how haps were extracted from genotytpes
//GeneticCounts** permutations;



int* pos; // used positions (NULL if all positions from parentalGenotypes are used)
int length;


//HaplotypeCountsVector* haplotypeCountsVector; 

/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

private:


//void set(SNPPos Pos[], SNPPos totalPos, TrioSample * samp, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations);  



      public:

GeneticCounts();

//	GeneticCounts(SNPPos Pos[], SNPPos totalPos, TrioSample * samp, AlleleOrderType alleleOrderType=LeftRight, PhaseAlg=weighted, EMDistributions emDistributions=UTDistributions, EMRestriction emRestriction=triosBasedRestriction, int totalPermutations=100);

GeneticCounts(int*pos, int length, HapExtractionConfiguration* hapExtractionConfiguration, T* haplotypeCountsVector, int totalPermutations);

//GeneticCounts(char* filename, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations);
	
 GeneticCounts(GeneticCounts& source);
 
virtual int getTotalPos();

int* getPositions();
 
 //GeneticCounts(char*filename);

 //virtual GeneticCounts* clone();

virtual ~GeneticCounts();

virtual void empty();

HapExtractionConfiguration* getHapExtractionConfiguration();

typename T::iterator findElement(Haplotype * h);

//virtual void setPermutations();

   T* getHaplotypeCountsVector();

void print(ostream&);

};  // End of class GeneticCounts








};  // End of Namespace

#endif

/* End of file: MultimarkerMeasure.h */




