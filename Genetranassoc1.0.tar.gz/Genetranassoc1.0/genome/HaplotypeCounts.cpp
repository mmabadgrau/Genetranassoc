#ifndef __HaplotypeCounts_cpp__
#define __HaplotypeCounts_cpp__

void print(BIOS::HaplotypeCounts *h){
	cout << *h << endl;
}

void print2(BIOS::HaplotypeCounts *h){
	cout << "hola" << endl;
}

namespace BIOS {

	HaplotypeCounts::HaplotypeCounts(int size)
	{
		if (size==0) haplotype=NULL;
		else haplotype=new Haplotype(size);
	};
	

	/*_________________________________________________________________*/
	

			HaplotypeCounts::HaplotypeCounts(Haplotype* haplotype)
			{
			this->haplotype=haplotype->clone();
			}
			
				/*_________________________________________________________________*/
	
			HaplotypeCounts::HaplotypeCounts(HaplotypeCounts& other)
			{
			  if ( other.haplotype != NULL)
					this->haplotype=other.haplotype->clone();
			  else
				 	haplotype = NULL;
			}
	
	/*_________________________________________________________________*/

	HaplotypeCounts::~HaplotypeCounts()
	{
//		cout << "calling destructor HaplotypeCounts..." << endl;
		zap(haplotype);
	}



			/*_________________________________________________________________*/
	
	bool HaplotypeCounts::hasSameAllelesAs(HaplotypeCounts *h)
	{
 if (haplotype==NULL || h->haplotype==NULL) throw NullValue("HaplotypeCounts::hasSameAllelesAs(HaplotypeCounts *h)");
		return *(this->haplotype) == *(h->haplotype);
	}

			/*_________________________________________________________________*/
	
	bool HaplotypeCounts::operator==(HaplotypeCounts & h){
		//cout << " comparing HaplotypeCounts ..." << endl;

		if (haplotype==NULL && h.haplotype==NULL) return true;
  if ((haplotype==NULL && h.haplotype!=NULL) || (haplotype==NULL && h.haplotype!=NULL))
   return false;
 //throw BadFormat("	bool HaplotypeCounts::operator==(HaplotypeCounts & h)");
		return * this->haplotype == * h.haplotype;
	}

			/*_________________________________________________________________*/
	
	bool HaplotypeCounts::operator!=(HaplotypeCounts & h)
	{
		//cout << "Calling differents HaplotypeCounts..." << endl;
		return ! (*this == h);
	}



			/*_________________________________________________________________*/
	

	HaplotypeCounts * HaplotypeCounts::filter(int *pos, int length)
	{
		int lastPos = this->size() - 1;

		// Check all positions are valid
		for(int i=0; i<length; i++)
			if ( pos[i] < 0 || pos[i] > lastPos){
				//cerr << "Invalid HaplotypeCounts::newHaplotypeFromPositions" << endl;
				throw OutOfBounds(size(), pos[i], "HaplotypeCounts::filter (int *pos, int length)");
				return NULL;
			}			

		// create new haplotype
		HaplotypeCounts * h = this->clone();
		


		// Copy alleles values
		for (int i=0; i<length; i++)
			h->haplotype->setAllele( (*this)[ pos[i] ], i);

		return h;

	}

				/*_________________________________________________________________*/
	
Haplotype* HaplotypeCounts::getHaplotype()
	{
		return haplotype;
	}

			/*_________________________________________________________________*/
	
	base& HaplotypeCounts::operator[] (int position) 
	{
		//base& ini=(*this->haplotype->alleleArray);
		//return (base&)ini;
		return (*(this->haplotype->alleleArray+position));
	} 

			/*_________________________________________________________________*/
	
	int HaplotypeCounts::size()
	{ 
	  	if ( haplotype != NULL)
			return haplotype->size();
		else
		  	return 0;
	};

			/*_________________________________________________________________*/
	
	int HaplotypeCounts::getCommonPositions(HaplotypeCounts* hap, intList* positions) 
	{
		if (hap->size()!=this->size()) throw OutOfBounds(hap->size(), this->size(), "2. HaplotypeCounts::getCommonPositions"); 
		int commonPositions=0;
		for (intList::iterator it=positions->begin(); it!=positions->end(); it++)
		if (*it>=this->size() || *it<0) throw OutOfBounds(*it, this->size(), "2. HaplotypeCounts::getCommonPositions"); 
		//else if (this->getElement(*it)!= hap->getElement(*it)) return commonPositions; 
		else 
		if ((*this)[*it]!= (*hap)[*it]) return commonPositions; 
		else commonPositions++;
		return commonPositions;
	}
	

				/*_________________________________________________________________*/
	
void HaplotypeCounts::print(ostream& output)
{
			//	output << "[";
				//cout <<"size is " << h.size() << "\n";
				output << *haplotype;





			//	return output;
			}

				/*_________________________________________________________________*/
/*	
void HaplotypeCounts::print()
	{
		cout << *this <<endl; 
	};
*/

			Haplotype* haplotype;

};

#endif
