#ifndef __SNPAfter_h__
#define __SNPAfter_h__

//#include <string.h>
//#include <cstdio>




//using namespace UTILS;


namespace BIOS {




/* _____________________________________________________*/

SNPPos GetTotalSNPs(char* filepos);
} // end namespace

#endif

/* End of file: SNPAfter.h */
