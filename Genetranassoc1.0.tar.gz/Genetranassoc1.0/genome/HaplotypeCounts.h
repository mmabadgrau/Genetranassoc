#ifndef __HaplotypeCounts_h__
#define __HaplotypeCounts_h__

namespace BIOS
{

	/**
	HaplotypeCounts: an haplotype and its transmitted/untransmitted frequencies in a given sample 
**/
	class HaplotypeCounts;
	typedef Set<HaplotypeCounts*>::Class SetOfHaplotypeCounts;
typedef Vector<HaplotypeCounts*>::Class HaplotypeCountsList;
typedef Vector<HaplotypeCounts*>::Class HaplotypeCountsVector;

	class HaplotypeCounts
	{
		private:



		public:

			Haplotype* haplotype;

			/**
			* Constructor
			*/
			HaplotypeCounts ( int size=0 );

		
			HaplotypeCounts ( HaplotypeCounts& other );

HaplotypeCounts ( Haplotype* haplotype);

			virtual ~HaplotypeCounts();

			Haplotype* getHaplotype();

			virtual HaplotypeCounts * filter(int *pos, int length);

			int getCommonPositions ( HaplotypeCounts* hap, intList* positions );

			base & operator[] ( int position ) ;

			int size();

		
			/**
			*	Compares two haplotypes. Only compares alleles, not frecuencies and other properties.
			*	@return true if both have the same alleles. false otherwise
			*/
			bool hasSameAllelesAs ( HaplotypeCounts * h );

			/**
			*	Compares two haplotypes, inluding all properties
			*	@return true if haplotypes are equal
			*/
			virtual bool operator== ( HaplotypeCounts & h );

			/**
			*	Compares two haplotypes, inluding all properties
			*	@return true if haplotypes are different
			*/
			virtual bool operator!= ( HaplotypeCounts & h );


			
			

			virtual HaplotypeCounts* fromString ( string s ) {throw NonImplemented ( "HaplotypeCounts::fromString(string s)" );};

			virtual HaplotypeCounts* clone()=0;// {return new HaplotypeCounts ( *this );};

			/**
			* Prints the HaplotypeCounts in the following manner: [ a0 a1 ... an ][frequency][T/U]
			* @param output Output stream
			* @param h Vector to print
			*/
			friend ostream& operator<< ( ostream& output,  HaplotypeCounts& h )
			{
h.print(output);
return output;
}


			/*
						static void print(HaplotypeCounts *h){
							for(int i=0; i< h->size()-1; i++)
								printf("%i ", (*h)[i]);
						}
				*/
			virtual void print(ostream& output);

virtual double getFirstFrequency()=0;

virtual double getSecondFrequency()=0;

virtual double getThirdFrequency()=0;
	};



};

#endif
