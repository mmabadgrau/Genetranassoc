#ifndef GenomeMLTest_cpp//
#define GenomeMLTest_cpp//






//using namespace UTILS;

namespace BIOS {

GenomeMLTest::GenomeMLTest(char* fileSample, TestModeClass *internalTestMod, TestModeClass *externalTestMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, int jointRows):GenericMLTest(fileSample, internalTestMod, externalTestMod, 3)// 3 is to say that information in each sample file has to be split together in trios (trio samples)
{
try
{
this->totalPermutations=totalPermutations;
    this->hapExtractionConfiguration=hapExtractionConfiguration;
}
catch (BasicException& be){be.addMessage("\ncalled from GenomeMLTest::GenomeMLTest(char* fileSample, TestModeClass *testMod, int totalPermutations, int jointRows):GenericMLTest(fileSample, testMod, 3)"); throw;};
}
/*___________________________________________________________ */

int GenomeMLTest::getRealNumberOfAtts()
{
return (totalAtts-7)/2;
} 
/*___________________________________________________________ */

GenomeMLTest::~GenomeMLTest()
{
}
/*___________________________________________________________ */

  GenericSample*  GenomeMLTest::getSample (char* file, int*pos, int length)
  {
    try
    {
//cout << "getting sample from file " << file <<"\n";
      GenomaSample* ts=new GenomaSample (file, NULL, 0, everybody, hapExtractionConfiguration->alleleOrderType);
      GenomaSample* result=ts->filter (pos, length);// it only works for left/right so far
     zap (ts);
     return  result;
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from GenericSample*  TUMLTest::getSample(char* file, int* pos, int size) "); throw;};
  }

  /*___________________________________________________________ */

  GenericCounts*  GenomeMLTest::getCounts (GenericSample* ts, int* pos, int size)
  {
    try
    {
      CaseControlCounts* results= ( (GenomaSample*) ts)->getCaseControlHaplotypeCounts (hapExtractionConfiguration, totalPermutations, pos, size);
      

      
      //cout <<"WWWW\n00000: \n" << *new TDTtable(((TUCounts*)results)->haplotypeTUCountsVector, NULL, 0, 0);
      /*
      cout <<"before remove\n";
      for(int x = 0; x < 120000; x++)
          for(int y = 0; y < 20000; y++);
          zap(results);
          cout <<"after remov:\n";
          for(int x = 0; x < 120000; x++)
          for(int y = 0; y < 20000; y++);
          exit(0);
          */
      return results;
    }
    catch (BasicException& be) {be.addMessage ("\ncalled from  GenericCounts*  TUMLTest::getCounts(char* file, int* pos, int size)"); throw;};
  }

} // end namespace
#endif
