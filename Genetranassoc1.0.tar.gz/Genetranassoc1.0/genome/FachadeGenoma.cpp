#ifndef __FachadeGenomaC_h__ 
#define __FachadeGenomaC_h__ 





#include "../commonc++/Fachade.h"

#include "../ML/FachadeML.h"

#include "FachadeGenoma.h"





#include "../commonc++/Fachade.cpp"
#include "../ML/FachadeML.cpp"


#include "SNP.cpp"
#include "SNPAfter.cpp"
#include "VirtualPositions.cpp"
#include "Positions.cpp"
#include "Haplotype.cpp"
#include "LongHaplotype.cpp"
#include "Diplotype.cpp"
#include "Genotype.cpp"
#include "Phenotype.cpp"
#include "PairGenotype.cpp"
#include "GenotypeSample.cpp"
#include "GenotypeCounters.cpp"
#include "GenotypeArray.cpp"
#include "PhenotypeSample.cpp"
//#include "CoupleSNPGenotype.cpp"
//#include "PairSNPGenotype.cpp"
#include "Genoma.cpp"
#include "GenomaSample.cpp"
#include "CoupleGenotype.cpp"
#include "MonolociMeasure.cpp"
#include "MultiallelicPairwiseMeasure.cpp"
#include "PairwiseMeasuresResults.cpp"
#include "RandomizationDistribution.cpp"
#include "ImportFormat.cpp"
#include "PairwiseCI.cpp"
#include "Block.cpp"
#include "BlockList.cpp"
#include "SNPAfter.cpp"
#include "blockCI.cpp"
#include "GenomeMLTest.cpp"
//#include "HaplotypesForEachIndividual.cpp"
#include "HapCounters.cpp"
//#include "InferredHaplotypes.cpp"
#include "GeneticCounts.cpp"
#include "CaseControlCounts.cpp"
#include "HaplotypeCounts.cpp"
//#include "GenericHaplotypeCountsVector.cpp"
#include "HaplotypeCaseControlCounts.cpp"
//#include "HaplotypeCaseControlCountsVector.cpp"
#include "TU/FachadeTU.cpp"

#include "CommandLineParser.cpp"
#include "CommandLineParserWindows.cpp"
#include "CommandLineParserGWAS.cpp"
#include "ResultsTable.cpp"
#include "GWAS.cpp"
#endif
